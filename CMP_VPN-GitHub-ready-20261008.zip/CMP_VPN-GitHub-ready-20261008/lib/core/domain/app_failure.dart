import '../l10n/myanmar_messages.dart';

class AppFailure implements Exception {
  const AppFailure(this.message);
  final String message;
  @override
  String toString() => message;
}

String safeError(Object error) => error is AppFailure
    ? safeMessage(error.message)
    : 'The operation could not be completed. Try again. Changes were not saved.';

String safeMessage(String message) {
  if (myanmarMessages.containsKey(message)) return message;
  final http = RegExp(
    r'^Subscription server returned HTTP (\d{3})\.',
  ).firstMatch(message);
  if (http != null) {
    return 'Subscription server returned HTTP ${http[1]}. Existing profiles were kept.';
  }
  return 'The operation failed. Check settings and try again.';
}
