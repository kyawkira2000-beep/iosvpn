import 'myanmar_messages.dart';

// Only application-owned messages go through this function. Profile names,
// credentials, URLs and protocol values are never translated.
String myMessage(String message) {
  final translated = myanmarMessages[message];
  if (translated != null) return translated;
  if (RegExp(r'[\u1000-\u109f]').hasMatch(message)) return message;
  final retry = RegExp(
    r'^Connection lost\. Retry (\d+)/(\d+) in (\d+)s\.',
  ).firstMatch(message);
  if (retry != null) {
    return 'ချိတ်ဆက်မှု ပြတ်သွားပါပြီ။ ${retry[3]} စက္ကန့်အကြာတွင် ${retry[2]} ကြိမ်အနက် ${retry[1]} ကြိမ်မြောက် ပြန်ချိတ်ပါမယ်။ ပြန်ချိတ်နေစဉ် ပုံမှန်အင်တာနက်ကို အသုံးပြုမိနိုင်ပါတယ်။';
  }
  final http = RegExp(
    r'^Subscription server returned HTTP (\d+)\.',
  ).firstMatch(message);
  if (http != null) {
    return 'ဆာဗာစာရင်းရယူရာတွင် HTTP ${http[1]} ပြန်ပေးပါတယ်။ ရှိပြီးသားဆာဗာတွေကို ထိန်းထားပါတယ်။';
  }
  if (message.startsWith('Windows DNS protection could not be verified')) {
    return 'Windows DNS ကာကွယ်မှုကို စစ်ဆေးအတည်ပြုမရပါ။ ကွန်ရက်ဆက်တင်တွေကို စစ်ပြီး ပြန်ချိတ်ပါ။';
  }
  return 'လုပ်ဆောင်မှု မအောင်မြင်ပါ။ ဆက်တင်တွေကို စစ်ပြီး ပြန်ကြိုးစားပါ။';
}

String myFieldLabel(String field) => myanmarMessages[field] ?? field;

String myEvent(String event) {
  final timestamp = RegExp(
    r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}  ',
  ).firstMatch(event);
  if (timestamp == null) return myMessage(event);
  return '${event.substring(0, timestamp.end)}${myMessage(event.substring(timestamp.end))}';
}
