import 'package:flutter/material.dart';
import 'myanmar.dart';
import 'myanmar_messages.dart';

/// Only application-owned text is translated. Never pass server names or keys.
String translateAppText(String text, String language) {
  final english = _english[text] ?? text;
  if (language == 'en') return english;
  if (english == 'Configs') return 'ဆာဗာများ';
  final exact = _extra[english] ?? myanmarMessages[english];
  if (exact != null) return exact;
  final timestamp = RegExp(
    r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}  ',
  ).firstMatch(text);
  if (timestamp != null) {
    return '${text.substring(0, timestamp.end)}${translateAppText(text.substring(timestamp.end), language)}';
  }
  if (english.startsWith('Connection lost. Retry ') ||
      english.startsWith('Subscription server returned HTTP ') ||
      english.startsWith('Windows DNS protection could not be verified')) {
    return myMessage(english);
  }
  return text;
}

final _english = <String, String>{
  for (final entry in myanmarMessages.entries) entry.value: entry.key,
  for (final entry in _extra.entries) entry.value: entry.key,
  // Preserve the user-facing product name instead of its old internal name.
  'CMP VPN': 'CMP VPN',
};

extension AppStrings on BuildContext {
  String tr(String text) =>
      translateAppText(text, Localizations.localeOf(this).languageCode);
}

/// A reactive label for app copy. Raw user-supplied content uses Flutter Text.
class AppText extends StatelessWidget {
  const AppText(
    this.data, {
    super.key,
    this.style,
    this.textAlign,
    this.maxLines,
    this.overflow,
    this.softWrap,
  });
  final String data;
  final TextStyle? style;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;
  final bool? softWrap;
  @override
  Widget build(BuildContext context) => Text(
    context.tr(data),
    style: style,
    textAlign: textAlign,
    maxLines: maxLines,
    overflow: overflow,
    softWrap: softWrap,
  );
}

const _extra = <String, String>{
  'Disconnecting iOS VPN…': 'iOS VPN ကို ဖြုတ်နေသည်…',
  'Starting iOS VPN…': 'iOS VPN ကို စတင်နေသည်…',
  'Changing iOS VPN connection…': 'iOS VPN ချိတ်ဆက်မှုကို ပြောင်းနေသည်…',
  'HTTPS through VPN verified.': 'VPN မှတစ်ဆင့် ချိတ်ဆက်မှု စစ်ဆေးပြီးပါပြီ။',
  'VPN connection changed.': 'VPN ချိတ်ဆက်မှု ပြောင်းလဲသွားပါပြီ။',
  'iOS HTTPS through the VPN failed. Check the server and try again.':
      'iOS VPN ချိတ်ဆက်မှု မအောင်မြင်ပါ။ ဆာဗာကို စစ်ပြီး ပြန်ကြိုးစားပါ။',
  'iOS requires a direct VLESS profile and its own packet tunnel.':
      'iOS တွင် တိုက်ရိုက်ချိတ်ဆက်နိုင်သော VLESS profile လိုအပ်ပါသည်။',
  'Could not start iOS VPN. Check VPN permission and signing.':
      'iOS VPN ကို မစတင်နိုင်ပါ။ VPN ခွင့်ပြုချက်နှင့် app signing ကို စစ်ဆေးပါ။',
  'Device identity': 'စက်၏ အတည်ပြုလက်ဗွေ',
  'Import the managed invitation from your administrator. Ordinary VLESS keys cannot connect in this build.':
      'စီမံသူပေးသော managed ဖိတ်ကြားလင့်ခ်ကို ထည့်ပါ။ ဤဗားရှင်းတွင် ပုံမှန် VLESS key ဖြင့် မချိတ်နိုင်ပါ။',
  'Device approved': 'ဤစက်ကို ခွင့်ပြုထားသည်',
  'Administrator approval required': 'စီမံသူ၏ ခွင့်ပြုချက်လိုသည်',
  'Waiting for administrator approval': 'စီမံသူ ခွင့်ပြုရန် စောင့်ဆိုင်းနေသည်',
  'Checking device access…': 'သုံးခွင့် စစ်ဆေးနေသည်…',
  'Device request rejected. Contact your administrator.':
      'တောင်းဆိုမှု ပယ်ချထားသည်။ စီမံသူကို ဆက်သွယ်ပါ။',
  'Device access revoked. Contact your administrator.':
      'ဤစက်၏ သုံးခွင့် ရုပ်သိမ်းထားသည်။ စီမံသူကို ဆက်သွယ်ပါ။',
  'Your account is suspended. Contact your administrator.':
      'အကောင့်ကို ဆိုင်းငံ့ထားသည်။ စီမံသူကို ဆက်သွယ်ပါ။',
  'Read the VPN traffic notice before connecting.':
      'မချိတ်မီ VPN အသုံးပြုမှု မှတ်တမ်းအကြောင်း ဖတ်ပါ။',
  'Cannot securely reach the approval server. Check the address, certificate and network.':
      'ခွင့်ပြုချက်ဆာဗာကို လုံခြုံစွာ မချိတ်နိုင်ပါ။ လိပ်စာ၊ certificate နှင့် အင်တာနက် စစ်ပါ။',
  'Device access is not approved. Check access on the home screen.':
      'ဤစက်ကို သုံးခွင့်မပြုထားပါ။ ပင်မစာမျက်နှာတွင် သုံးခွင့် စစ်ပါ။',
  'VPN traffic notice': 'VPN အသုံးပြုမှု မှတ်တမ်းအကြောင်း',
  'I understand and agree': 'နားလည်ပြီး သဘောတူသည်',
  'Check access': 'သုံးခွင့် စစ်မည်',
  'Read notice': 'အသိပေးချက် ဖတ်မည်',
  'Home': 'ပင်မ',
  'Default': 'မူလ',
  'Preferences': 'ဆက်တင်များ',
  'CMP VPN logo': 'CMP VPN အမှတ်တံဆိပ်',
  'HTTPS check URL': 'HTTPS စစ်ဆေးမည့် URL',
  'URL that returns HTTP 204': 'HTTP 204 ပြန်ပေးသော URL',
  'Licenses': 'လိုင်စင်များ',
  'Save': 'သိမ်းမည်',
  'Auto-reconnect': 'အလိုအလျောက် ပြန်ချိတ်မည်',
  'Servers': 'ဆာဗာ',
  'Subscriptions': 'စာရင်း',
  'Settings': 'ဆက်တင်',
  'Free server': 'အခမဲ့ဆာဗာ',
  'Choose a server': 'ဆာဗာရွေးရန်',
  'Choose server': 'ဆာဗာရွေးပါ',
  'Add your key': 'ကိုယ်ပိုင် key ထည့်ရန်',
  'Enter your VLESS key.': 'ကိုယ်ပိုင် VLESS key ကို ထည့်ပါ။',
  'Select': 'ရွေးမည်',
  'Personal server': 'ကိုယ်ပိုင်ဆာဗာ',
  'From subscription': 'စာရင်းမှ ဆာဗာ',
  'Please wait': 'ခဏစောင့်ပါ',
  'Details': 'အသေးစိတ်',
  'Advanced': 'အဆင့်မြင့်',
  'Use System Proxy when off': 'ပိတ်လျှင် System Proxy သုံးမည်',
  'Restart as administrator': 'Admin အဖြစ် ပြန်ဖွင့်ရန်',
  'Could not restart as administrator.': 'Admin အဖြစ် ပြန်ဖွင့်မရပါ။',
  'Normal internet resumes when the VPN stops.':
      'VPN ပြတ်လျှင် ပုံမှန်အင်တာနက် ပြန်သုံးပါမယ်။',
  'Personal server settings are encrypted on this device.':
      'ကိုယ်ပိုင်ဆာဗာဆက်တင်များကို ဒီစက်ထဲတွင် ကုဒ်ဖြင့် သိမ်းထားပါတယ်။',
  'Could not open your server library. Reopen the app.':
      'ဆာဗာစာရင်း ဖွင့်မရပါ။ ပြန်ဖွင့်ကြည့်ပါ။',
  'Language': 'ဘာသာစကား',
  'Tap to connect': 'နှိပ်၍ ချိတ်ဆက်ပါ',
  'Connection verified': 'ချိတ်ဆက်မှု စစ်ဆေးပြီး',
  'Latency': 'တုံ့ပြန်ချိန်',
  'HTTPS check through VPN': 'VPN မှတစ်ဆင့် HTTPS စစ်ဆေးမှု',
  'Connecting securely…': 'ချိတ်ဆက်နေပါတယ်…',
  'Try again': 'ပြန်ကြိုးစားပါ',
  'Your connection, one tap away.': 'တစ်ချက်နှိပ်၍ ချိတ်ဆက်ပါ။',
  'Unknown': 'မသိရသေးပါ',
  'Unlimited (provider reported)':
      'ဝန်ဆောင်မှုပေးသူက အကန့်အသတ်မရှိဟု ဖော်ပြထားသည်',
  'Updated': 'မွမ်းမံချိန်',
  'Allowance': 'အသုံးပြုခွင့်',
  'Expires': 'သက်တမ်းကုန်ချိန်',
  'Unsupported profiles skipped': 'မပံ့ပိုးသောဆာဗာများကို ကျော်ထားသည်',
  'The operation could not be completed. Try again. Changes were not saved.':
      'လုပ်ဆောင်မှု မပြီးမြောက်ပါ။ ပြန်ကြိုးစားပါ။ ပြောင်းလဲမှုတွေ မသိမ်းထားပါ။',
  'The operation failed. Check settings and try again.':
      'လုပ်ဆောင်မှု မအောင်မြင်ပါ။ ဆက်တင်တွေကို စစ်ပြီး ပြန်ကြိုးစားပါ။',
  'Could not save language. Please try again.':
      'ဘာသာစကား သိမ်းမရပါ။ ပြန်ကြိုးစားပါ။',
};
