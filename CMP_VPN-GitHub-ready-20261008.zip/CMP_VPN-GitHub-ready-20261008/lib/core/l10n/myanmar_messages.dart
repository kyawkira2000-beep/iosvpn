/// Burmese presentation text. Native status/protocol strings remain stable.
const myanmarMessages = <String, String>{
  "CMP VPN": "CMP VPN",
  "CMP VPN logo": "CMP VPN အမှတ်တံဆိပ်",
  "CMP VPN · 0.4.0": "CMP VPN · 0.4.1",
  "Home": "ပင်မ",
  "Servers": "ဆာဗာများ",
  "Subscriptions": "ဆာဗာစာရင်းများ",
  "Settings": "ဆက်တင်များ",
  "On your terms.": "သင့်စိတ်ကြိုက် ချိတ်ဆက်ပါ။",
  "Your private connection": "သင့်အတွက် သီးသန့်ချိတ်ဆက်မှု",
  "A little more peace of mind.": "စိတ်အေးအေးနဲ့ ချိတ်ဆက်ပါ။",
  "Your servers. Your connection. One simple place.":
      "သင့်ဆာဗာနဲ့ ချိတ်ဆက်မှုတွေကို တစ်နေရာတည်းမှာ စီမံပါ။",
  "Windows · TUN VPN": "Windows · TUN ချိတ်ဆက်မှု",
  "Windows · System Proxy": "Windows · စနစ်ပရောက်စီ",
  "Android · Device VPN": "Android · စက်တစ်ခုလုံးအတွက် VPN",
  "IPv4/IPv6 TCP and UDP through your server. Local network remains local. Requires Administrator permission.":
      "IPv4/IPv6 TCP နဲ့ UDP ကို သင့်ဆာဗာမှတစ်ဆင့် ပို့ပေးပါတယ်။ အနီးဝန်းကျင်ကွန်ရက်ကို မူလအတိုင်း အသုံးပြုပါတယ်။ စီမံခန့်ခွဲသူ ခွင့်ပြုချက်လိုပါတယ်။",
  "Verified REALITY connection for apps using Windows proxy settings.":
      "Windows ပရောက်စီကို အသုံးပြုတဲ့ အက်ပ်တွေအတွက် စစ်ဆေးပြီး REALITY ချိတ်ဆက်မှုပါ။",
  "Android VPN integration is still pending.":
      "Android VPN ချိတ်ဆက်မှုကို ရေးဆွဲနေဆဲပါ။",
  "Disconnect and restore Windows network settings":
      "ချိတ်ဆက်မှုဖြုတ်ပြီး Windows ကွန်ရက်ဆက်တင်တွေကို မူလအတိုင်း ပြန်ထားရန်",
  "Connect to selected server": "ရွေးထားတဲ့ဆာဗာကို ချိတ်ဆက်ရန်",
  "Stopping…": "ဖြုတ်နေသည်…",
  "Disconnect": "ဖြုတ်မည်",
  "Connect": "ချိတ်မည်",
  "Disconnected": "မချိတ်ဆက်ရသေး",
  "Connecting": "ချိတ်ဆက်နေသည်",
  "Connected": "ချိတ်ဆက်ထားသည်",
  "Reconnecting": "ပြန်ချိတ်နေသည်",
  "Connection Failed": "ချိတ်ဆက်မှု မအောင်မြင်ပါ",
  "Your connection is verified": "ချိတ်ဆက်မှုကို စစ်ဆေးပြီးပါပြီ",
  "Establishing your connection": "ချိတ်ဆက်မှု တည်ဆောက်နေပါတယ်",
  "You’re not connected": "မချိတ်ဆက်ရသေးပါ",
  "No server selected": "ဆာဗာ မရွေးရသေးပါ",
  "Manage your connection profiles": "ချိတ်ဆက်မှုဆက်တင်တွေကို စီမံပါ",
  "Download": "လက်ခံနှုန်း",
  "Upload": "ပို့နှုန်း",
  "No TUN measurement": "တိုင်းတာချက် မရှိသေးပါ",
  "Duration": "ကြာချိန်",
  "Verified session": "စစ်ဆေးပြီး ချိတ်ဆက်မှု",
  "No active session": "လက်ရှိ ချိတ်ဆက်မှုမရှိပါ",
  "Session traffic": "ဒေတာစုစုပေါင်း",
  "Current tunnel · includes checks": "လက်ရှိချိတ်ဆက်မှုနှင့် စစ်ဆေးမှုဒေတာ",
  "Server latency: —  ·  Not measured": "တုံ့ပြန်ချိန် — · မတိုင်းတာရသေးပါ",
  "Connection logs": "ချိတ်ဆက်မှုမှတ်တမ်း",
  "TUN covers public TCP/UDP traffic. Local network routes remain local. This mode does not provide a persistent kill switch.":
      "TUN က အင်တာနက် TCP/UDP ဒေတာကို ဆာဗာမှတစ်ဆင့် ပို့ပေးပါတယ်။ အနီးဝန်းကျင်ကွန်ရက်လမ်းကြောင်းတွေ မပြောင်းပါ။ VPN ပြတ်သွားချိန် အင်တာနက်ကို အလိုအလျောက် ပိတ်ပေးတဲ့စနစ် မပါသေးပါ။",
  "System Proxy applies to apps that use Windows proxy settings. Other traffic is not covered.":
      "စနစ်ပရောက်စီက Windows ပရောက်စီဆက်တင်ကို အသုံးပြုတဲ့ အက်ပ်တွေသာ အကျုံးဝင်ပါတယ်။ အခြားဒေတာတွေ မပါဝင်ပါ။",
  "Device traffic will use the VPN after the native connection service is available.":
      "စက်အတွက် VPN ချိတ်ဆက်မှု အဆင်သင့်ဖြစ်မှ ဒေတာတွေကို VPN မှတစ်ဆင့် ပို့ပေးမှာပါ။",
  "Connection profiles": "ချိတ်ဆက်မှုဆက်တင်များ",
  "Your servers.": "သင့်ဆာဗာများ",
  "Import a connection and keep its credentials on your device.":
      "ချိတ်ဆက်မှုထည့်ပြီး လျှို့ဝှက်အချက်အလက်တွေကို သင့်စက်ထဲမှာ သိမ်းထားပါ။",
  "Import link": "လင့်ခ်ထည့်မည်",
  "Manual entry": "ကိုယ်တိုင်ဖြည့်မည်",
  "QR image": "QR ပုံထည့်မည်",
  "QR images": "QR ပုံများ",
  "Scan QR": "QR ဖတ်မည်",
  "Retry secure storage": "သိမ်းဆည်းထားသည့်ဒေတာ ပြန်ဖွင့်မည်",
  "A home for your servers": "ဆာဗာတွေကို ဒီမှာ သိမ်းထားပါ",
  "Add a VLESS link, scan a QR code or enter your server details.":
      "VLESS လင့်ခ်ထည့်ပါ၊ QR ဖတ်ပါ သို့မဟုတ် ဆာဗာအချက်အလက်တွေ ကိုယ်တိုင်ဖြည့်ပါ။",
  "VPN connection support is still being built.":
      "ဆာဗာတစ်ခုရွေးပြီး ပင်မစာမျက်နှာမှ ချိတ်ဆက်နိုင်ပါတယ်။",
  "Remove server?": "ဆာဗာကို ဖယ်ရှားမလား။",
  "Remove this server from encrypted storage?":
      "လုံခြုံစွာသိမ်းထားတဲ့ ဒီဆာဗာကို ဖယ်ရှားမလား။",
  "Remove this server? A subscription refresh can add it again.":
      "ဒီဆာဗာကို ဖယ်ရှားမလား။ ဆာဗာစာရင်းပြန်မွမ်းမံရင် ပြန်ပါလာနိုင်ပါတယ်။",
  "Cancel": "မလုပ်တော့ပါ",
  "Remove": "ဖယ်ရှားမည်",
  "Copy secret connection link?": "လျှို့ဝှက်ချိတ်ဆက်မှုလင့်ခ်ကို ကူးမလား။",
  "This link contains your credentials. Other apps may read your clipboard. Share it only with people you trust.":
      "ဒီလင့်ခ်မှာ သင့်လျှို့ဝှက်အချက်အလက်တွေ ပါပါတယ်။ ကူးထားတဲ့စာကို အခြားအက်ပ်တွေ ဖတ်နိုင်ပါတယ်။ ယုံကြည်ရသူတွေကိုသာ မျှဝေပါ။",
  "Copy link": "လင့်ခ်ကူးမည်",
  "Export link to clipboard": "လင့်ခ်ကို ကူးယူမည်",
  "Manual profile": "ကိုယ်တိုင်ထည့်ထားသော ဆာဗာ",
  "Subscription profile": "စာရင်းမှထည့်ထားသော ဆာဗာ",
  "Selected": "ရွေးထားသည်",
  "Select server": "ဆာဗာရွေးမည်",
  "Add server manually": "ဆာဗာအချက်အလက် ကိုယ်တိုင်ဖြည့်ပါ",
  "Import VLESS link": "VLESS လင့်ခ်ထည့်ပါ",
  "Saved encrypted on this device. Importing does not connect the VPN.":
      "ဒီစက်ထဲမှာ ကုဒ်ဖြင့်လုံခြုံစွာ သိမ်းထားပါတယ်။ ထည့်လိုက်ရုံနဲ့ VPN မချိတ်ဆက်ပါ။",
  "VLESS link": "VLESS လင့်ခ်",
  "Security": "လုံခြုံရေးစနစ်",
  "TLS (connection testing later)": "TLS (ချိတ်ဆက်မှု မရသေးပါ)",
  "Transport": "ပို့ဆောင်မှုပုံစံ",
  "Name": "အမည်",
  "Server address": "ဆာဗာလိပ်စာ",
  "Port": "ပေါက်နံပါတ် (Port)",
  "Fingerprint": "လက်ဗွေအမှတ် (Fingerprint)",
  "Flow": "ဒေတာစီးဆင်းမှုပုံစံ (Flow)",
  "Public key": "အများသုံးသော့ (Public key)",
  "Short ID": "အတိုကောက်အမှတ် (Short ID)",
  "Extra parameters": "ထပ်ဆောင်းသတ်မှတ်ချက်များ",
  "Optional query fields such as path, host or serviceName":
      "လိုအပ်လျှင် path၊ host သို့မဟုတ် serviceName တို့ ထည့်နိုင်ပါတယ်",
  "Saving…": "သိမ်းနေသည်…",
  "Save server": "ဆာဗာသိမ်းမည်",
  "Scan QR code": "QR ကုဒ်ဖတ်ပါ",
  "Point the camera at one QR code, then press Scan. Images are decoded on this device.":
      "ကင်မရာကို QR ကုဒ်တစ်ခုဆီ ချိန်ပြီး ဖတ်မည်ကို နှိပ်ပါ။ ပုံကို ဒီစက်ပေါ်မှာပဲ ဖတ်ပါတယ်။",
  "Opening camera…": "ကင်မရာ ဖွင့်နေသည်…",
  "Reading…": "ဖတ်နေသည်…",
  "Camera access is unavailable. Check camera permissions or import a QR image.":
      "ကင်မရာ အသုံးပြုမရပါ။ ကင်မရာခွင့်ပြုချက် စစ်ပါ သို့မဟုတ် QR ပုံထည့်ပါ။",
  "Stay up to date": "နောက်ဆုံးစာရင်းကို ရယူပါ",
  "Subscriptions.": "ဆာဗာစာရင်းများ",
  "Download profiles directly from your provider. Secret links stay hidden.":
      "ဝန်ဆောင်မှုပေးသူထံမှ ဆာဗာစာရင်း တိုက်ရိုက်ရယူပါ။ လျှို့ဝှက်လင့်ခ်တွေကို ဖျောက်ထားပါတယ်။",
  "Add subscription": "ဆာဗာစာရင်းထည့်မည်",
  "No subscriptions yet": "ဆာဗာစာရင်း မရှိသေးပါ",
  "Add an HTTPS subscription URL to import and update its servers.":
      "ဆာဗာတွေ ထည့်သွင်းမွမ်းမံဖို့ HTTPS ဆာဗာစာရင်းလင့်ခ် ထည့်ပါ။",
  "Usage and expiry are shown only when supplied by the server.":
      "အသုံးပြုမှုပမာဏနဲ့ သက်တမ်းကို ဆာဗာမှပေးပို့မှသာ ပြသပါတယ်။",
  "Unknown": "မသိရသေးပါ",
  "Provider reports no limit": "ဝန်ဆောင်မှုပေးသူက အကန့်အသတ်မရှိဟု ဖော်ပြထားသည်",
  "Expired according to provider metadata":
      "ဝန်ဆောင်မှုပေးသူ၏ အချက်အလက်အရ သက်တမ်းကုန်နေပါပြီ",
  "Traffic allowance reached": "ဒေတာအသုံးပြုခွင့် ကုန်သွားပါပြီ",
  "Update": "မွမ်းမံမည်",
  "Delete subscription?": "ဆာဗာစာရင်းကို ဖျက်မလား။",
  "This removes the saved URL and its imported profiles. Your provider account is unchanged.":
      "သိမ်းထားတဲ့လင့်ခ်နဲ့ အဲဒီစာရင်းမှ ဆာဗာတွေကို ဖယ်ရှားပါမယ်။ ဝန်ဆောင်မှုပေးသူထံက သင့်အကောင့် မပြောင်းပါ။",
  "Delete": "ဖျက်မည်",
  "Download server profiles from this HTTPS URL. The URL may contain a secret token and will be stored encrypted.":
      "ဒီ HTTPS လင့်ခ်မှ ဆာဗာစာရင်း ရယူပါမယ်။ လင့်ခ်မှာ လျှို့ဝှက်ကုဒ် ပါနိုင်တဲ့အတွက် ကုဒ်ဖြင့်လုံခြုံစွာ သိမ်းထားပါမယ်။",
  "HTTPS subscription URL": "HTTPS ဆာဗာစာရင်းလင့်ခ်",
  "Hide URL": "လင့်ခ်ဖျောက်မည်",
  "Reveal URL": "လင့်ခ်ပြမည်",
  "Downloading…": "ရယူနေသည်…",
  "Download and save": "ရယူပြီး သိမ်းမည်",
  "Make it yours": "သင့်စိတ်ကြိုက် ပြင်ဆင်ပါ",
  "Settings.": "ဆက်တင်များ",
  "A quieter space, the way you like it.":
      "အသုံးပြုရ အဆင်ပြေစေဖို့ စိတ်ကြိုက်ရွေးချယ်ပါ။",
  "Appearance": "အပြင်အဆင်",
  "Choose how CMP VPN looks for this session.":
      "ယခုအသုံးပြုချိန်အတွက် CMP VPN အပြင်အဆင်ကို ရွေးပါ။",
  "System": "စက်အတိုင်း",
  "Light": "အလင်း",
  "Dark": "အမှောင်",
  "Connection": "ချိတ်ဆက်မှု",
  "Mode: Windows TUN VPN": "ပုံစံ — Windows TUN ချိတ်ဆက်မှု",
  "Mode: Windows System Proxy": "ပုံစံ — Windows စနစ်ပရောက်စီ",
  "Mode: Android Device VPN": "ပုံစံ — Android စက်တစ်ခုလုံးအတွက် VPN",
  "TUN routes public TCP/UDP traffic through your server, including apps without proxy support. Local network routes remain local. Administrator permission is required.":
      "TUN က ပရောက်စီမသုံးတဲ့ အက်ပ်တွေအပါအဝင် အင်တာနက် TCP/UDP ဒေတာကို သင့်ဆာဗာမှတစ်ဆင့် ပို့ပေးပါတယ်။ အနီးဝန်းကျင်ကွန်ရက်လမ်းကြောင်းတွေ မပြောင်းပါ။ စီမံခန့်ခွဲသူ ခွင့်ပြုချက်လိုပါတယ်။",
  "Android will ask for VPN permission when the connection service is ready.":
      "Android ချိတ်ဆက်မှု အဆင်သင့်ဖြစ်တဲ့အခါ VPN ခွင့်ပြုချက် တောင်းပါမယ်။",
  "TUN mode": "TUN ချိတ်ဆက်မှုပုံစံ",
  "Off uses Windows System Proxy instead.":
      "ပိတ်ထားလျှင် Windows စနစ်ပရောက်စီကို အသုံးပြုပါမယ်။",
  "Restart as administrator": "စီမံခန့်ခွဲသူအဖြစ် ပြန်ဖွင့်မည်",
  "Administrator restart was cancelled or unavailable.":
      "စီမံခန့်ခွဲသူအဖြစ် ပြန်ဖွင့်မှုကို ပယ်ဖျက်ထားသည် သို့မဟုတ် အသုံးပြုမရပါ။",
  "HTTPS connectivity check": "HTTPS ချိတ်ဆက်မှု စစ်ဆေးခြင်း",
  "Checks through your server every 20 seconds. Endpoint must return HTTP 204.":
      "သင့်ဆာဗာမှတစ်ဆင့် စက္ကန့် ၂၀ တိုင်း စစ်ဆေးပါတယ်။ စစ်ဆေးမည့်လိပ်စာက HTTP 204 ပြန်ပေးရပါမယ်။",
  "Connectivity endpoint": "ချိတ်ဆက်မှု စစ်ဆေးမည့်လိပ်စာ",
  "HTTPS URL": "HTTPS လိပ်စာ",
  "Use for this session": "ယခုအသုံးပြုချိန်အတွက် သတ်မှတ်မည်",
  "Automatic reconnection": "အလိုအလျောက် ပြန်ချိတ်ခြင်း",
  "This app session: retry a previously verified server up to 5 times. Disconnect cancels retries. Normal networking may resume between attempts.":
      "ယခုအသုံးပြုချိန်အတွင်း အရင်ချိတ်ဆက်အောင်မြင်ခဲ့တဲ့ ဆာဗာကို ၅ ကြိမ်အထိ ပြန်ကြိုးစားပါမယ်။ ဖြုတ်မည်ကို နှိပ်လျှင် ရပ်ပါမယ်။ ပြန်ချိတ်နေစဉ် ပုံမှန်အင်တာနက်ကို အသုံးပြုမိနိုင်ပါတယ်။",
  "Windows tray": "Windows အောက်ခြေရှိ အိုင်ကွန်",
  "Minimize to keep CMP VPN in the tray. Double-click the icon to reopen; right-click for connection controls. Close or Exit disconnects and quits.":
      "ဝင်းဒိုးကို ခေါက်ထားလျှင် CMP VPN ဆက်အလုပ်လုပ်ပါမယ်။ အိုင်ကွန်ကို နှစ်ချက်နှိပ်၍ ပြန်ဖွင့်ပါ၊ ညာကလစ်နှိပ်၍ ချိတ်ဆက်မှုကို စီမံပါ။ ပိတ်ခြင်း သို့မဟုတ် ထွက်ခြင်းက VPN ကို ဖြုတ်ပေးပါတယ်။",
  "Version 0.4.0 · Windows TUN and System Proxy":
      "ဗားရှင်း 0.4.1 · Windows TUN နှင့် စနစ်ပရောက်စီ",
  "Profiles are encrypted on this device. Windows uses the official Xray runtime and restores the previous proxy settings on disconnect. Connected requires a verified HTTPS check through the selected server. Android connection support is still pending.":
      "ဆာဗာဆက်တင်တွေကို ဒီစက်ထဲမှာ ကုဒ်ဖြင့်လုံခြုံစွာ သိမ်းထားပါတယ်။ Windows မှာ တရားဝင် Xray ကို အသုံးပြုပြီး ချိတ်ဆက်မှုဖြုတ်တဲ့အခါ ကွန်ရက်ဆက်တင်တွေကို ပြန်ထားပေးပါတယ်။ ဆာဗာမှတစ်ဆင့် HTTPS စစ်ဆေးမှု အောင်မြင်မှ ချိတ်ဆက်ထားသည်ဟု ပြပါတယ်။ Android ချိတ်ဆက်မှုကို ရေးဆွဲနေဆဲပါ။",
  "Open-source licenses": "မူရင်းဆော့ဖ်ဝဲ လိုင်စင်များ",
  "No connection events": "ချိတ်ဆက်မှုမှတ်တမ်း မရှိသေးပါ",
  "There has not been a VPN session. Connection events will appear here once the service is available.":
      "VPN ချိတ်ဆက်မှု မရှိသေးပါ။ ချိတ်ဆက်သည့်အခါ မှတ်တမ်းတွေကို ဒီနေရာမှာ ပြပေးပါမယ်။",
  "No network activity has been recorded.":
      "ကွန်ရက်လှုပ်ရှားမှု မှတ်တမ်း မရှိသေးပါ။",
  "Ready to connect.": "ချိတ်ဆက်ရန် အဆင်သင့်ပါ။",
  "Starting a verified connection…": "ချိတ်ဆက်မှု စတင်စစ်ဆေးနေပါတယ်…",
  "Connection requested.": "ချိတ်ဆက်ရန် စတင်လိုက်ပါပြီ။",
  "Disconnect requested.": "ချိတ်ဆက်မှုဖြုတ်ရန် တောင်းဆိုလိုက်ပါပြီ။",
  "Automatic reconnection cancelled.":
      "အလိုအလျောက် ပြန်ချိတ်ခြင်းကို ရပ်လိုက်ပါပြီ။",
  "Validating the REALITY configuration.":
      "REALITY ဆက်တင်တွေကို စစ်ဆေးနေပါတယ်။",
  "Validating the selected server and starting Xray.":
      "ရွေးထားတဲ့ဆာဗာကို စစ်ဆေးပြီး Xray စတင်နေပါတယ်။",
  "Checking HTTPS through the selected server.":
      "ရွေးထားတဲ့ဆာဗာမှတစ်ဆင့် HTTPS ကို စစ်ဆေးနေပါတယ်။",
  "Configuring TUN routes and protected DNS.":
      "TUN လမ်းကြောင်းတွေနဲ့ လုံခြုံတဲ့ DNS ကို ပြင်ဆင်နေပါတယ်။",
  "Windows TUN active. HTTPS verified without a proxy; IPv4/IPv6 routes and DNS protection installed.":
      "Windows TUN ချိတ်ဆက်ပြီးပါပြီ။ HTTPS စစ်ဆေးမှု အောင်မြင်ပြီး IPv4/IPv6 လမ်းကြောင်းတွေနဲ့ DNS ကာကွယ်မှု အဆင်သင့်ပါ။",
  "HTTPS verified through the selected server. Windows System Proxy is active.":
      "ဆာဗာမှတစ်ဆင့် HTTPS စစ်ဆေးမှု အောင်မြင်ပြီး Windows စနစ်ပရောက်စီ အလုပ်လုပ်နေပါပြီ။",
  "Disconnecting and restoring Windows network settings…":
      "ချိတ်ဆက်မှုဖြုတ်ပြီး Windows ကွန်ရက်ဆက်တင်တွေကို မူလအတိုင်း ပြန်ထားနေပါတယ်…",
  "Disconnected. Tunnel routes and DNS protection removed.":
      "ချိတ်ဆက်မှု ဖြုတ်ပြီးပါပြီ။ TUN လမ်းကြောင်းတွေနဲ့ DNS ကာကွယ်မှုကို ဖယ်ရှားပြီးပါပြီ။",
  "Disconnected. Previous Windows proxy settings restored.":
      "ချိတ်ဆက်မှု ဖြုတ်ပြီး မူလ Windows ပရောက်စီဆက်တင်တွေကို ပြန်ထားပြီးပါပြီ။",
  "Select a saved server first.": "သိမ်းထားတဲ့ဆာဗာတစ်ခုကို အရင်ရွေးပါ။",
  "Native Windows connection service is unavailable in this build.":
      "ဒီဗားရှင်းမှာ Windows ချိတ်ဆက်မှုစနစ်ကို အသုံးပြုမရပါ။",
  "Cannot read native connection state. Restart CMP VPN to recover proxy settings.":
      "ချိတ်ဆက်မှုအခြေအနေကို ဖတ်မရပါ။ ပရောက်စီဆက်တင်တွေ ပြန်ထားနိုင်ဖို့ CMP VPN ကို ပြန်ဖွင့်ပါ။",
  "Could not signal disconnect. Close CMP VPN to trigger the supervisor cleanup.":
      "ချိတ်ဆက်မှုဖြုတ်ရန် အမိန့်ပို့မရပါ။ ကွန်ရက်ဆက်တင်တွေ ပြန်ရှင်းပေးဖို့ CMP VPN ကို ပိတ်ပါ။",
  "Could not start the connection. A previous session may still be closing.":
      "ချိတ်ဆက်မှု စတင်မရပါ။ အရင်ချိတ်ဆက်မှုကို ဖြုတ်နေဆဲ ဖြစ်နိုင်ပါတယ်။",
  "Could not prepare TUN mode.": "TUN ချိတ်ဆက်မှု ပြင်ဆင်မရပါ။",
  "The provider reports this subscription expired or exhausted. Refresh it before connecting.":
      "ဝန်ဆောင်မှုပေးသူအရ သက်တမ်း သို့မဟုတ် ဒေတာအသုံးပြုခွင့် ကုန်နေပါတယ်။ မချိတ်ဆက်မီ စာရင်းကို မွမ်းမံပါ။",
  "Use an HTTPS endpoint without credentials or fragment that returns HTTP 204.":
      "လျှို့ဝှက်အချက်အလက်နဲ့ # အပိုင်းမပါဘဲ HTTP 204 ပြန်ပေးတဲ့ HTTPS လိပ်စာကို သုံးပါ။",
  "TUN mode requires Administrator permission. Use Restart as administrator in Settings.":
      "TUN အတွက် စီမံခန့်ခွဲသူခွင့်ပြုချက် လိုပါတယ်။ ဆက်တင်များမှ စီမံခန့်ခွဲသူအဖြစ် ပြန်ဖွင့်မည်ကို နှိပ်ပါ။",
  "TUN mode requires Administrator permission.":
      "TUN အတွက် စီမံခန့်ခွဲသူခွင့်ပြုချက် လိုပါတယ်။",
  "TUN mode requires Administrator permission and a prepared adapter.":
      "TUN အတွက် စီမံခန့်ခွဲသူခွင့်ပြုချက်နဲ့ အဆင်သင့်ကွန်ရက်အဒက်တာ လိုပါတယ်။",
  "Windows denied TUN network setup. Administrator permission is required.":
      "Windows က TUN ပြင်ဆင်ခြင်းကို ငြင်းပယ်ပါတယ်။ စီမံခန့်ခွဲသူခွင့်ပြုချက် လိုပါတယ်။",
  "Wait for the previous connection to close.":
      "အရင်ချိတ်ဆက်မှု ဖြုတ်ပြီးတဲ့အထိ စောင့်ပါ။",
  "Another session is closing, or the connection helper is unavailable.":
      "အရင်ချိတ်ဆက်မှုကို ဖြုတ်နေဆဲ သို့မဟုတ် ချိတ်ဆက်မှုအကူစနစ် အသုံးပြုမရပါ။",
  "Connection helper exited unexpectedly. Restart CMP VPN to recover proxy settings.":
      "ချိတ်ဆက်မှုအကူစနစ် ရုတ်တရက် ရပ်သွားပါတယ်။ ဆက်တင်တွေ ပြန်ထားဖို့ CMP VPN ကို ပြန်ဖွင့်ပါ။",
  "Another CMP VPN instance owns the connection.":
      "အခြားဖွင့်ထားတဲ့ CMP VPN ဝင်းဒိုးက ချိတ်ဆက်မှုကို အသုံးပြုနေပါတယ်။",
  "Cannot acquire connection ownership.":
      "ချိတ်ဆက်မှုကို ထိန်းချုပ်ခွင့် မရပါ။",
  "Connection is in use.": "ချိတ်ဆက်မှုကို အသုံးပြုနေဆဲပါ။",
  "Connection ownership changed during setup.":
      "ပြင်ဆင်နေစဉ် ချိတ်ဆက်မှုထိန်းချုပ်သူ ပြောင်းသွားပါတယ်။",
  "No physical route to the VPN server is available. Disconnect other VPNs and check the network.":
      "VPN ဆာဗာသို့ သွားမည့်ကွန်ရက်လမ်းကြောင်း မရှိပါ။ အခြား VPN များကို ဖြုတ်ပြီး ကွန်ရက်ကို စစ်ပါ။",
  "Cannot resolve the VPN server before creating the tunnel.":
      "VPN မစတင်မီ ဆာဗာလိပ်စာ ရှာမရပါ။ အင်တာနက်နဲ့ DNS ကို စစ်ပါ။",
  "The TUN adapter is not available.": "TUN ကွန်ရက်အဒက်တာ အသုံးပြုမရပါ။",
  "The TUN adapter stopped.": "TUN ကွန်ရက်အဒက်တာ ရပ်သွားပါတယ်။",
  "The tunnel adapter is not the expected Wintun device.":
      "ကွန်ရက်အဒက်တာက မျှော်မှန်းထားတဲ့ Wintun အဒက်တာ မဟုတ်ပါ။",
  "TUN network is not active.": "TUN ကွန်ရက် အလုပ်မလုပ်ပါ။",
  "Tunnel routing changed. Reconnect to rebuild the routes.":
      "TUN လမ်းကြောင်းတွေ ပြောင်းသွားပါတယ်။ ပြန်ချိတ်ဆက်ပါ။",
  "Windows is routing internet traffic outside TUN. Check other VPNs or static routes.":
      "Windows က အင်တာနက်ဒေတာကို TUN ပြင်ပမှ ပို့နေပါတယ်။ အခြား VPN နဲ့ ကွန်ရက်လမ်းကြောင်းဆက်တင်တွေကို စစ်ပါ။",
  "Cannot assign the tunnel IP address.": "TUN အတွက် IP လိပ်စာ သတ်မှတ်မရပါ။",
  "Cannot configure the tunnel interface.": "TUN ကွန်ရက်အဒက်တာကို ပြင်ဆင်မရပါ။",
  "Cannot configure tunnel DNS.": "TUN အတွက် DNS သတ်မှတ်မရပါ။",
  "Cannot install the tunnel routes.": "TUN ကွန်ရက်လမ်းကြောင်းတွေ ထည့်မရပါ။",
  "Cannot install tunnel DNS protection.": "TUN အတွက် DNS ကာကွယ်မှု ထည့်မရပါ။",
  "Cannot protect tunnel DNS with Windows Filtering Platform.":
      "Windows စစ်ထုတ်စနစ်ဖြင့် TUN DNS ကို ကာကွယ်မရပါ။",
  "Cannot read tunnel counters.": "TUN ဒေတာပမာဏကို ဖတ်မရပါ။",
  "Cannot verify DNS protection.": "DNS ကာကွယ်မှုကို စစ်ဆေးအတည်ပြုမရပါ။",
  "HTTPS certificate validation failed through the selected server.":
      "ရွေးထားတဲ့ဆာဗာမှတစ်ဆင့် HTTPS လုံခြုံရေးလက်မှတ်ကို စစ်ဆေးအတည်ပြုမရပါ။",
  "HTTPS through the selected server timed out. Check the server and network.":
      "ဆာဗာမှတစ်ဆင့် HTTPS ချိတ်ဆက်မှု စောင့်ချိန်ကုန်သွားပါတယ်။ ဆာဗာနဲ့ ကွန်ရက်ကို စစ်ပါ။",
  "HTTPS through the selected server failed. Check the client profile, server availability and network.":
      "ဆာဗာမှတစ်ဆင့် HTTPS ချိတ်ဆက်မရပါ။ ချိတ်ဆက်မှုဆက်တင်၊ ဆာဗာနဲ့ ကွန်ရက်ကို စစ်ပါ။",
  "Connectivity endpoint did not return HTTP 204 through the selected server.":
      "စစ်ဆေးမည့်လိပ်စာက ဆာဗာမှတစ်ဆင့် HTTP 204 ပြန်မပေးပါ။",
  "Cannot initialize the routed HTTPS check.":
      "ဆာဗာမှတစ်ဆင့် HTTPS စစ်ဆေးမှု စတင်မရပါ။",
  "Xray stopped unexpectedly. Previous proxy settings are being restored.":
      "Xray ရုတ်တရက် ရပ်သွားပါတယ်။ ကွန်ရက်ဆက်တင်တွေကို မူလအတိုင်း ပြန်ထားပေးနေပါတယ်။",
  "Xray exited while starting. Check local ports and profile compatibility.":
      "Xray စတင်စဉ် ရပ်သွားပါတယ်။ စက်ပေါ်ရှိ ပေါက်နံပါတ်တွေနဲ့ ဆာဗာဆက်တင်ကို စစ်ပါ။",
  "Xray rejected this configuration. Check REALITY fields and fingerprint.":
      "Xray က ဒီဆက်တင်ကို လက်မခံပါ။ REALITY အချက်အလက်နဲ့ လက်ဗွေအမှတ်ကို စစ်ပါ။",
  "Xray configuration validation timed out.":
      "Xray ဆက်တင်စစ်ဆေးမှု စောင့်ချိန်ကုန်သွားပါတယ်။",
  "Could not start the official Xray executable.":
      "တရားဝင် Xray ဖိုင်ကို စတင်မရပါ။",
  "Official Xray runtime is missing or its checksum changed. Reinstall the verified runtime.":
      "Xray ဖိုင် မရှိပါ သို့မဟုတ် စစ်ဆေးတန်ဖိုး ပြောင်းသွားပါတယ်။ စစ်ဆေးပြီး မူရင်းဖိုင်ကို ပြန်ထည့်ပါ။",
  "Cannot verify Xray integrity.": "Xray ဖိုင် မှန်ကန်မှုကို စစ်ဆေးမရပါ။",
  "A local proxy port is already in use. Try connecting again.":
      "စက်ပေါ်ရှိ ပရောက်စီပေါက်နံပါတ်ကို အသုံးပြုနေပြီးပါပြီ။ ပြန်ချိတ်ကြည့်ပါ။",
  "The selected Xray process does not own both local proxy listeners.":
      "ရွေးထားတဲ့ Xray က ပရောက်စီပေါက်နှစ်ခုလုံးကို ထိန်းချုပ်မထားပါ။",
  "Local proxy listener ownership was lost.":
      "စက်ပေါ်ရှိ ပရောက်စီပေါက်ကို ထိန်းချုပ်ခွင့် ဆုံးရှုံးသွားပါတယ်။",
  "Another application changed the proxy settings. Its changes were preserved.":
      "အခြားအက်ပ်က ပရောက်စီဆက်တင်တွေ ပြောင်းလိုက်ပါတယ်။ အဲဒီပြောင်းလဲမှုတွေကို ထိန်းသိမ်းထားပါတယ်။",
  "Another application changed proxy settings. Those settings were preserved; review Windows proxy settings.":
      "အခြားအက်ပ်၏ ပရောက်စီဆက်တင်တွေကို ထိန်းသိမ်းထားပါတယ်။ Windows ပရောက်စီဆက်တင်ကို ပြန်စစ်ပါ။",
  "Another application changed the proxy settings. Those settings were preserved; review Windows proxy settings before reconnecting.":
      "အခြားအက်ပ်၏ ပရောက်စီဆက်တင်တွေကို ထိန်းသိမ်းထားပါတယ်။ ပြန်မချိတ်မီ Windows ပရောက်စီဆက်တင်ကို စစ်ပါ။",
  "Proxy restoration failed. Restart CMP VPN for recovery before using the network.":
      "ပရောက်စီဆက်တင်တွေ ပြန်ထားမရပါ။ ကွန်ရက်မသုံးမီ CMP VPN ကို ပြန်ဖွင့်ပါ။",
  "Proxy settings changed during connection setup. Please retry.":
      "ချိတ်ဆက်မှု ပြင်ဆင်နေစဉ် ပရောက်စီဆက်တင် ပြောင်းသွားပါတယ်။ ပြန်ကြိုးစားပါ။",
  "Windows proxy settings could not be verified.":
      "Windows ပရောက်စီဆက်တင်ကို စစ်ဆေးအတည်ပြုမရပါ။",
  "Windows rejected the proxy settings change.":
      "Windows က ပရောက်စီဆက်တင်ပြောင်းခြင်းကို လက်မခံပါ။",
  "Cannot read Windows per-user proxy settings.":
      "Windows အသုံးပြုသူ၏ ပရောက်စီဆက်တင်ကို ဖတ်မရပါ။",
  "Machine-wide managed proxy policy is unsupported. No settings were changed.":
      "စက်တစ်ခုလုံးအတွက် စီမံထားသော ပရောက်စီမူဝါဒကို မပံ့ပိုးပါ။ ဆက်တင်တွေ မပြောင်းထားပါ။",
  "Disconnect the existing Windows dial-up/VPN connection first. Only the default LAN proxy scope is supported.":
      "ရှိပြီးသား Windows dial-up/VPN ကို အရင်ဖြုတ်ပါ။ မူလ LAN ပရောက်စီပုံစံကိုသာ ပံ့ပိုးပါတယ်။",
  "Native connection operation failed. Credentials were not logged.":
      "စက်ပေါ်ရှိ ချိတ်ဆက်မှုလုပ်ဆောင်ချက် မအောင်မြင်ပါ။ လျှို့ဝှက်အချက်အလက်တွေကို မှတ်တမ်းမတင်ထားပါ။",
  "Could not allocate local proxy ports.":
      "စက်ပေါ်တွင် ပရောက်စီပေါက်နံပါတ် ခွဲဝေမရပါ။",
  "The native TUN network plan is incomplete.":
      "TUN ကွန်ရက်ပြင်ဆင်ချက် မပြည့်စုံပါ။",
  "This profile contains parameters the installed runtime adapter does not support. They have not been discarded.":
      "ဒီဆာဗာဆက်တင်မှာ လက်ရှိဗားရှင်းက မပံ့ပိုးတဲ့ သတ်မှတ်ချက်တွေ ပါပါတယ်။ ၎င်းတို့ကို ဖယ်မထားပါ။",
  "This runtime currently connects VLESS REALITY over TCP/RAW. Other transports remain import-only.":
      "လက်ရှိဗားရှင်းမှာ VLESS REALITY ကို TCP/RAW ဖြင့်သာ ချိတ်ဆက်နိုင်ပါတယ်။ အခြားပုံစံတွေကို သိမ်းထားနိုင်သော်လည်း မချိတ်နိုင်သေးပါ။",
  "The operation could not be completed. Please retry. No changes were saved.":
      "လုပ်ဆောင်မှု မပြီးမြောက်ပါ။ ပြန်ကြိုးစားပါ။ ပြောင်းလဲမှုတွေ မသိမ်းထားပါ။",
  "Another app instance changed the library. Close and reopen CMP VPN before trying again.":
      "အခြားဝင်းဒိုးက သိမ်းထားတဲ့စာရင်းကို ပြောင်းလိုက်ပါတယ်။ CMP VPN ကို ပိတ်ပြီး ပြန်ဖွင့်ပါ။",
  "Could not save to secure storage. No changes were applied.":
      "လုံခြုံသောသိမ်းဆည်းစနစ်မှာ သိမ်းမရပါ။ ပြောင်းလဲမှုတွေ မလုပ်ထားပါ။",
  "Encrypted profile library exceeds 4 MB.":
      "လုံခြုံစွာသိမ်းထားတဲ့ ဆာဗာစာရင်းက 4 MB ထက် ကျော်နေပါတယ်။",
  "Limit reached: 1,000 profiles or 20 subscriptions.":
      "ဆာဗာ ၁,၀၀၀ ခု သို့မဟုတ် ဆာဗာစာရင်း ၂၀ ခု အကန့်အသတ် ပြည့်သွားပါပြီ။",
  "Secure storage could not be opened. Your existing data was not overwritten. Retry under the same OS account.":
      "လုံခြုံစွာသိမ်းထားတဲ့ဒေတာကို ဖွင့်မရပါ။ ရှိပြီးသားဒေတာကို မရေးထပ်ထားပါ။ မူလစက်အသုံးပြုသူအကောင့်ဖြင့် ပြန်ကြိုးစားပါ။",
  "Secure storage is not ready.": "လုံခြုံသောသိမ်းဆည်းစနစ် အဆင်သင့်မဖြစ်သေးပါ။",
  "Another library operation is still running.":
      "စာရင်းနှင့်ပတ်သက်တဲ့ အခြားလုပ်ဆောင်မှုတစ်ခု လုပ်နေဆဲပါ။",
  "Wait for secure storage to load or retry opening it.":
      "သိမ်းထားတဲ့ဒေတာ ဖွင့်ပြီးသည်အထိ စောင့်ပါ သို့မဟုတ် ပြန်ဖွင့်ကြည့်ပါ။",
  "This manual profile is already in your library.":
      "ဒီဆာဗာကို သင့်စာရင်းထဲမှာ သိမ်းထားပြီးပါပြီ။",
  "This server is no longer in the library.":
      "ဒီဆာဗာက သိမ်းထားတဲ့စာရင်းထဲမှာ မရှိတော့ပါ။",
  "Choose a subscription name of 1–80 characters.":
      "ဆာဗာစာရင်းအမည်ကို စာလုံး ၁ မှ ၈၀ အတွင်း ပေးပါ။",
  "This subscription is already saved.": "ဒီဆာဗာစာရင်းကို သိမ်းထားပြီးပါပြီ။",
  "You can save up to 20 subscriptions.":
      "ဆာဗာစာရင်း ၂၀ ခုအထိ သိမ်းနိုင်ပါတယ်။",
  "QR must contain one VLESS link or HTTPS subscription URL.":
      "QR ထဲမှာ VLESS လင့်ခ်တစ်ခု သို့မဟုတ် HTTPS ဆာဗာစာရင်းလင့်ခ် ပါရပါမယ်။",
  "Enter a valid port (1–65535).": "မှန်ကန်တဲ့ ပေါက်နံပါတ် (1–65535) ဖြည့်ပါ။",
  "Extra parameters must be URL query syntax, for example path=%2Fws.":
      "ထပ်ဆောင်းသတ်မှတ်ချက်တွေကို လင့်ခ်သတ်မှတ်ချက်ပုံစံဖြင့် ဖြည့်ပါ။ ဥပမာ path=%2Fws။",
  "Extra parameters cannot override the fields above.":
      "ထပ်ဆောင်းသတ်မှတ်ချက်တွေက အပေါ်ကအချက်အလက်တွေကို အစားထိုးမရပါ။",
  "No camera was found. Import a QR image instead.":
      "ကင်မရာ မတွေ့ပါ။ QR ပုံကို ထည့်သွင်းပါ။",
  "Camera image is too large. Import a smaller QR image.":
      "ကင်မရာပုံ အရွယ်အစားကြီးလွန်းပါတယ်။ ပိုသေးတဲ့ QR ပုံကို ထည့်ပါ။",
  "Choose a PNG or JPEG QR image.":
      "PNG သို့မဟုတ် JPEG အမျိုးအစား QR ပုံကို ရွေးပါ။",
  "Image dimensions are invalid or exceed 12 megapixels / 4096 pixels per side.":
      "ပုံအတိုင်းအတာ မမှန်ပါ သို့မဟုတ် 12 မီဂါပစ်ဇယ် / တစ်ဖက်လျှင် 4096 ပစ်ဇယ်ထက် ကျော်နေပါတယ်။",
  "No readable QR code found. Try a clear, uncropped image.":
      "ဖတ်နိုင်တဲ့ QR ကုဒ် မတွေ့ပါ။ ကြည်လင်ပြီး မဖြတ်ထားတဲ့ပုံနဲ့ ပြန်ကြိုးစားပါ။",
  "QR content exceeds 16 KB.": "QR ထဲက အချက်အလက်က 16 KB ထက် ကျော်နေပါတယ်။",
  "QR image exceeds 8 MB.": "QR ပုံက 8 MB ထက် ကျော်နေပါတယ်။",
  "The QR image could not be read.": "QR ပုံကို ဖတ်မရပါ။",
  "The QR image is invalid or unreadable.": "QR ပုံ မမှန်ပါ သို့မဟုတ် ဖတ်မရပါ။",
  "A client link must not contain server private keys or passwords.":
      "ချိတ်ဆက်မှုလင့်ခ်မှာ ဆာဗာ၏ ကိုယ်ပိုင်သော့ သို့မဟုတ် စကားဝှက် မပါရပါ။",
  "A connection parameter occurs more than once.":
      "ချိတ်ဆက်မှုသတ်မှတ်ချက်တစ်ခု ထပ်နေပါတယ်။",
  "A valid server address and port (1–65535) are required.":
      "မှန်ကန်တဲ့ ဆာဗာလိပ်စာနဲ့ ပေါက်နံပါတ် (1–65535) လိုပါတယ်။",
  "A valid UUID is required.": "မှန်ကန်တဲ့ UUID လိုပါတယ်။",
  "Advanced parameters require a matching native core.":
      "အဆင့်မြင့်သတ်မှတ်ချက်တွေအတွက် ကိုက်ညီတဲ့ ချိတ်ဆက်မှုအင်ဂျင် လိုပါတယ်။",
  "ALPN must be a comma-separated list without empty values.":
      "ALPN ကို ကော်မာဖြင့် ခွဲရေးပြီး တန်ဖိုးအလွတ် မပါစေရပါ။",
  "Connection parameter names contain invalid characters.":
      "ချိတ်ဆက်မှုသတ်မှတ်ချက်အမည်မှာ မမှန်ကန်တဲ့ စာလုံးတွေ ပါပါတယ်။",
  "Connection parameters contain control characters.":
      "ချိတ်ဆက်မှုသတ်မှတ်ချက်မှာ ခွင့်မပြုတဲ့ ထိန်းချုပ်စာလုံးတွေ ပါပါတယ်။",
  "Disabling certificate validation is not supported.":
      "လုံခြုံရေးလက်မှတ် စစ်ဆေးခြင်းကို ပိတ်မရပါ။",
  "Extra parameters are preserved; runtime support is not verified.":
      "ထပ်ဆောင်းသတ်မှတ်ချက်တွေကို သိမ်းထားပါတယ်။ ချိတ်ဆက်မှုအင်ဂျင်က ပံ့ပိုးခြင်းရှိမရှိ မစစ်ဆေးရသေးပါ။",
  "Only VLESS connection links are supported.":
      "VLESS ချိတ်ဆက်မှုလင့်ခ်ကိုသာ ပံ့ပိုးပါတယ်။",
  "Profile name is too long or contains control characters.":
      "ဆာဗာအမည် ရှည်လွန်းပါတယ် သို့မဟုတ် ခွင့်မပြုတဲ့ ထိန်းချုပ်စာလုံးတွေ ပါပါတယ်။",
  "REALITY is incompatible with this transport.":
      "REALITY က ဒီပို့ဆောင်မှုပုံစံနဲ့ မကိုက်ညီပါ။",
  "REALITY public key must contain 32 base64url-encoded bytes.":
      "REALITY အများသုံးသော့က base64url ဖြင့်ရေးထားသော 32 ဘိုက် ဖြစ်ရပါမယ်။",
  "REALITY requires SNI, fingerprint, public key and a short ID field (which may be empty).":
      "REALITY အတွက် SNI၊ လက်ဗွေအမှတ်၊ အများသုံးသော့နဲ့ Short ID အကွက် လိုပါတယ်။ Short ID တန်ဖိုးကို အလွတ်ထားနိုင်ပါတယ်။",
  "REALITY short ID must be even-length hexadecimal, up to 16 characters.":
      "REALITY Short ID က စာလုံးရေစုံပြီး အများဆုံး ၁၆ လုံးရှိတဲ့ hexadecimal တန်ဖိုး ဖြစ်ရပါမယ်။",
  "security must be reality or tls.":
      "လုံခြုံရေးစနစ်က reality သို့မဟုတ် tls ဖြစ်ရပါမယ်။",
  "Server address must be an IP address or ASCII hostname (use punycode for international domains).":
      "ဆာဗာလိပ်စာက IP သို့မဟုတ် ASCII ဒိုမိန်းအမည် ဖြစ်ရပါမယ်။ အခြားဘာသာစကားဒိုမိန်းအတွက် punycode သုံးပါ။",
  "SNI must be a hostname.": "SNI က ဒိုမိန်းအမည် ဖြစ်ရပါမယ်။",
  "The link contains invalid whitespace or percent encoding.":
      "လင့်ခ်ထဲမှာ မမှန်တဲ့ နေရာလွတ် သို့မဟုတ် ရာခိုင်နှုန်းကုဒ် ရေးသားမှု ပါပါတယ်။",
  "The VLESS link is malformed. Check its address, port and encoding.":
      "VLESS လင့်ခ်ပုံစံ မမှန်ပါ။ လိပ်စာ၊ ပေါက်နံပါတ်နဲ့ ကုဒ်ရေးသားမှုကို စစ်ပါ။",
  "This transport is not supported by the importer.":
      "ဒီပို့ဆောင်မှုပုံစံကို ထည့်သွင်းမရပါ။",
  "This transport needs native compatibility testing.":
      "ဒီပို့ဆောင်မှုပုံစံကို စက်ပေါ်မှာ ကိုက်ညီမှု စမ်းသပ်ဖို့ လိုပါတယ်။",
  "This version supports VLESS encryption=none only.":
      "ဒီဗားရှင်းက VLESS encryption=none ကိုသာ ပံ့ပိုးပါတယ်။",
  "TLS connection testing follows the REALITY baseline.":
      "TLS ချိတ်ဆက်မှုကို REALITY စမ်းသပ်မှုအပြီး ဆက်လုပ်ပါမယ်။",
  "Too many connection parameters.": "ချိတ်ဆက်မှုသတ်မှတ်ချက် များလွန်းပါတယ်။",
  "Transport paths belong in the path query parameter.":
      "ပို့ဆောင်မှုလမ်းကြောင်းကို path သတ်မှတ်ချက်ထဲမှာ ထည့်ပါ။",
  "Unsupported VLESS flow.": "ဒီ VLESS ဒေတာစီးဆင်းမှုပုံစံကို မပံ့ပိုးပါ။",
  "Vision flow requires TCP/RAW in this client.":
      "ဒီအက်ပ်မှာ Vision အတွက် TCP/RAW လိုပါတယ်။",
  "VLESS link exceeds 16 KB.": "VLESS လင့်ခ်က 16 KB ထက် ကျော်နေပါတယ်။",
  "Could not download the subscription. Check your network and URL.":
      "ဆာဗာစာရင်း ရယူမရပါ။ ကွန်ရက်နဲ့ လင့်ခ်ကို စစ်ပါ။",
  "Cross-origin subscription redirects are blocked to protect credentials.":
      "လျှို့ဝှက်အချက်အလက်တွေကို ကာကွယ်ဖို့ အခြားလိပ်စာသို့ လွှဲပို့ခြင်းကို ပိတ်ထားပါတယ်။",
  "Subscription access was denied. It may be disabled or expired.":
      "ဆာဗာစာရင်း အသုံးပြုခွင့် ငြင်းပယ်ခံရပါတယ်။ ပိတ်ထားခြင်း သို့မဟုတ် သက်တမ်းကုန်ခြင်း ဖြစ်နိုင်ပါတယ်။",
  "Subscription exceeds the 2 MB limit.":
      "ဆာဗာစာရင်းက 2 MB အကန့်အသတ်ထက် ကျော်နေပါတယ်။",
  "Subscription redirect limit exceeded or destination missing.":
      "လင့်ခ်လွှဲပို့မှု အကန့်အသတ်ကျော်နေပါတယ် သို့မဟုတ် လွှဲမည့်လိပ်စာ မရှိပါ။",
  "Subscription request timed out. Existing servers were kept.":
      "ဆာဗာစာရင်းရယူမှု စောင့်ချိန်ကုန်သွားပါတယ်။ ရှိပြီးသားဆာဗာတွေကို ထိန်းထားပါတယ်။",
  "The subscription TLS certificate could not be verified.":
      "ဆာဗာစာရင်း၏ TLS လုံခြုံရေးလက်မှတ်ကို စစ်ဆေးအတည်ပြုမရပါ။",
  "Too many redirects.": "လင့်ခ်လွှဲပို့မှု များလွန်းပါတယ်။",
  "Use a valid HTTPS subscription URL without user-info or a fragment.":
      "အသုံးပြုသူအချက်အလက်နဲ့ # အပိုင်းမပါတဲ့ မှန်ကန်သော HTTPS ဆာဗာစာရင်းလင့်ခ်ကို သုံးပါ။",
  "Decoded subscription exceeds 2 MB.":
      "ဖတ်ထုတ်ပြီး ဆာဗာစာရင်းက 2 MB ထက် ကျော်နေပါတယ်။",
  "JSON subscriptions are not supported. Use a standard VLESS link-list subscription.":
      "JSON ဆာဗာစာရင်းကို မပံ့ပိုးပါ။ ပုံမှန် VLESS လင့်ခ်စာရင်းကို သုံးပါ။",
  "No valid VLESS profiles were found. Existing servers were kept.":
      "မှန်ကန်တဲ့ VLESS ဆာဗာဆက်တင် မတွေ့ပါ။ ရှိပြီးသားဆာဗာတွေကို ထိန်းထားပါတယ်။",
  "Subscription encoding is invalid. Existing servers were kept.":
      "ဆာဗာစာရင်း၏ ကုဒ်ရေးသားမှုပုံစံ မမှန်ပါ။ ရှိပြီးသားဆာဗာတွေကို ထိန်းထားပါတယ်။",
  "Subscription has more than 500 profiles.":
      "ဆာဗာစာရင်းမှာ ဆာဗာ ၅၀၀ ထက် ကျော်နေပါတယ်။",
  "The subscription is not a VLESS list or base64 link list.":
      "ဒီဆာဗာစာရင်းက VLESS စာရင်း သို့မဟုတ် base64 လင့်ခ်စာရင်း မဟုတ်ပါ။",
  "Subscription no longer exists.": "ဒီဆာဗာစာရင်း မရှိတော့ပါ။",
  "Cannot create the Xray supervisor job.": "Xray ထိန်းချုပ်စနစ်ကို စတင်မရပါ။",
  "Cannot create Xray input pipe.":
      "Xray သို့ အချက်အလက်ပို့မည့်လမ်းကြောင်း ဖန်တီးမရပါ။",
  "Cannot send configuration to Xray.": "Xray သို့ ဆက်တင်တွေ ပို့မရပါ။",
  "Cannot supervise the Xray process safely.":
      "Xray လုပ်ဆောင်မှုကို လုံခြုံစွာ ထိန်းချုပ်မရပါ။",
  "Cannot decrypt proxy recovery journal. Use the original Windows account.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်းကို ဖွင့်မရပါ။ မူလ Windows အကောင့်ကို သုံးပါ။",
  "Cannot locate proxy recovery storage.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်းသိမ်းရာ နေရာကို ရှာမရပါ။",
  "Cannot persist proxy recovery snapshot. No proxy change was attempted.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်းကို သိမ်းမရပါ။ ပရောက်စီကို မပြောင်းထားပါ။",
  "Cannot read proxy recovery journal.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်းကို ဖတ်မရပါ။",
  "Could not encrypt proxy recovery snapshot.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်းကို လုံခြုံစွာ ကုဒ်သွင်းမရပါ။",
  "Existing recovery journal needs attention first.":
      "ရှိပြီးသား ပရောက်စီပြန်ထားမည့် မှတ်တမ်းကို အရင်စစ်ဆေးဖို့ လိုပါတယ်။",
  "Proxy recovery journal is corrupt.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်း ပျက်စီးနေပါတယ်။",
  "Proxy recovery journal is invalid. Manual recovery is required.":
      "ပရောက်စီပြန်ထားမည့် မှတ်တမ်း မမှန်ပါ။ Windows ပရောက်စီဆက်တင်ကို ကိုယ်တိုင်ပြန်စစ်ပြီး ပြင်ဆင်ပါ။",
  "Proxy state is safe, but recovery journal cleanup failed.":
      "ပရောက်စီအခြေအနေ အဆင်ပြေသော်လည်း ပြန်ထားမည့်မှတ်တမ်းကို ရှင်းမရပါ။",
  "Native proxy check failed. Existing settings were preserved.":
      "ပရောက်စီစစ်ဆေးမှု မအောင်မြင်ပါ။ ရှိပြီးသားဆက်တင်တွေကို ထိန်းထားပါတယ်။",
  "Cannot create a tunnel session identity.":
      "TUN ချိတ်ဆက်မှုအမှတ် ဖန်တီးမရပါ။",
  "Cannot create DNS filter identity.": "DNS စစ်ထုတ်မှုအမှတ် ဖန်တီးမရပါ။",
  "Cannot create DNS protection scope.": "DNS ကာကွယ်မည့် နယ်ပယ် သတ်မှတ်မရပါ။",
  "Cannot identify the encrypted tunnel process.":
      "ကုဒ်ဝှက်ချိတ်ဆက်မှု လုပ်ဆောင်ချက်ကို ခွဲခြားမရပါ။",
  "Cannot identify tunnel DNS scope.": "TUN DNS နယ်ပယ်ကို ခွဲခြားမရပါ။",
  "Cannot initialize networking.": "ကွန်ရက်စနစ် စတင်မရပါ။",
  "Cannot inspect the tunnel interface.": "TUN ကွန်ရက်အဒက်တာကို စစ်ဆေးမရပါ။",
  "Cannot read the physical adapter name.": "မူလကွန်ရက်အဒက်တာအမည်ကို ဖတ်မရပါ။",
  "Cannot configure HTTPS check timeouts.":
      "HTTPS စစ်ဆေးမှု စောင့်ချိန်ကို သတ်မှတ်မရပါ။",
  "Cannot secure the HTTPS check request.":
      "HTTPS စစ်ဆေးမှုကို လုံခြုံစွာ ပြင်ဆင်မရပါ။",
  "Connectivity check must be an HTTPS URL without credentials or fragment.":
      "စစ်ဆေးမည့်လိပ်စာက လျှို့ဝှက်အချက်အလက်နဲ့ # အပိုင်းမပါတဲ့ HTTPS လိပ်စာ ဖြစ်ရပါမယ်။",
  "Administrator restart was cancelled or denied.":
      "စီမံခန့်ခွဲသူအဖြစ် ပြန်ဖွင့်မှုကို ပယ်ဖျက်ထားသည် သို့မဟုတ် ခွင့်မပြုပါ။",
  "Disconnect before restarting as administrator.":
      "စီမံခန့်ခွဲသူအဖြစ် ပြန်မဖွင့်မီ ချိတ်ဆက်မှုကို ဖြုတ်ပါ။",
  "Cannot prepare the tunnel network.": "TUN ကွန်ရက် ပြင်ဆင်မရပါ။",
  "Invalid connection request.": "ချိတ်ဆက်ရန် တောင်းဆိုချက် မမှန်ပါ။",
  "Invalid local proxy ports.": "စက်ပေါ်ရှိ ပရောက်စီပေါက်နံပါတ်တွေ မမှန်ပါ။",
  "Invalid supervisor input.":
      "ချိတ်ဆက်မှုထိန်းချုပ်စနစ်ထံ ပေးပို့သောအချက်အလက် မမှန်ပါ။",
  "Incomplete supervisor input.":
      "ချိတ်ဆက်မှုထိန်းချုပ်စနစ်ထံ ပေးပို့သောအချက်အလက် မပြည့်စုံပါ။",
  "Invalid text encoding.": "စာသားကုဒ်ရေးသားမှုပုံစံ မမှန်ပါ။",
  "Invalid network text.": "ကွန်ရက်အချက်အလက် မမှန်ပါ။",
  "Invalid server address.": "ဆာဗာလိပ်စာ မမှန်ပါ။",
  "Invalid tunnel address.": "TUN လိပ်စာ မမှန်ပါ။",
  "Invalid tunnel session identity.": "TUN ချိတ်ဆက်မှုအမှတ် မမှန်ပါ။",
  "Cancelled.": "ပယ်ဖျက်လိုက်ပါပြီ။",
  "Native connection service is unavailable in this build.":
      "ဤဗားရှင်းတွင် ချိတ်ဆက်မှုစနစ် အသုံးပြုမရပါ။",
  "Cannot read native connection state. Reopen CMP VPN.":
      "ချိတ်ဆက်မှုအခြေအနေကို ဖတ်မရပါ။ CMP VPN ကို ပြန်ဖွင့်ပါ။",
  "Allow Android VPN permission to connect.":
      "ချိတ်ဆက်ရန် Android VPN ခွင့်ပြုချက်ပေးပါ။",
  "Preparing Android VPN…": "Android VPN ပြင်ဆင်နေသည်…",
  "Checking HTTPS through Android VPN…":
      "Android VPN မှတစ်ဆင့် HTTPS စစ်ဆေးနေသည်…",
  "Android VPN connected. HTTPS through the tunnel verified.":
      "Android VPN ချိတ်ဆက်ပြီးပါပြီ။ VPN မှတစ်ဆင့် HTTPS စစ်ဆေးမှု အောင်မြင်ပါတယ်။",
  "Disconnecting Android VPN…": "Android VPN ဖြုတ်နေသည်…",
  "Android VPN disconnected.": "Android VPN ဖြုတ်ပြီးပါပြီ။",
  "Android VPN permission was revoked.":
      "Android VPN ခွင့်ပြုချက်ကို ပြန်ရုပ်သိမ်းထားပါတယ်။",
  "Android VPN permission was not granted.":
      "Android VPN ခွင့်ပြုချက် မပေးထားပါ။ ပြန်ချိတ်ပြီး ခွင့်ပြုပေးပါ။",
  "Android VPN connection cancelled.":
      "Android VPN ချိတ်ဆက်မှုကို ပယ်ဖျက်လိုက်ပါတယ်။",
  "Android VPN service stopped.": "Android VPN ဝန်ဆောင်မှု ရပ်သွားပါတယ်။",
  "Android VPN service could not start. Reopen the app and allow VPN permission.":
      "Android VPN စတင်မရပါ။ အက်ပ်ကို ပြန်ဖွင့်ပြီး VPN ခွင့်ပြုချက်ပေးပါ။",
  "No physical route is available. Check Wi-Fi or mobile data.":
      "အင်တာနက်လမ်းကြောင်း မရှိပါ။ Wi-Fi သို့မဟုတ် မိုဘိုင်းဒေတာကို စစ်ပါ။",
  "Cannot resolve the VPN server. Check Wi-Fi or mobile data.":
      "VPN ဆာဗာလိပ်စာကို ရှာမရပါ။ Wi-Fi သို့မဟုတ် မိုဘိုင်းဒေတာကို စစ်ပါ။",
  "Android Xray could not start. Check profile compatibility or restart the app.":
      "Android Xray စတင်မရပါ။ ဆာဗာဆက်တင်ကို စစ်ပါ သို့မဟုတ် အက်ပ်ကို ပြန်ဖွင့်ပါ။",
  "Android VPN routing could not be verified.":
      "Android VPN လမ်းကြောင်းကို အတည်ပြုမရပါ။ ပြန်ချိတ်ကြည့်ပါ။",
  "Android VPN setup failed. Check this profile and the network.":
      "Android VPN ပြင်ဆင်မရပါ။ ဆာဗာဆက်တင်နဲ့ အင်တာနက်ကို စစ်ပါ။",
  "Android HTTPS check did not return HTTP 204. Check the probe URL.":
      "HTTPS စစ်ဆေးမှုက HTTP 204 ပြန်မပေးပါ။ စစ်ဆေးမည့်လိပ်စာကို ပြင်ဆင်ပါ။",
  "Android HTTPS certificate verification failed. Check the network or probe URL.":
      "HTTPS လုံခြုံရေးလက်မှတ်ကို အတည်ပြုမရပါ။ ကွန်ရက် သို့မဟုတ် စစ်ဆေးမည့်လိပ်စာကို စစ်ပါ။",
  "Android HTTPS through the VPN failed. Check the server, network and probe URL.":
      "VPN မှတစ်ဆင့် HTTPS စစ်ဆေးမှု မအောင်မြင်ပါ။ ဆာဗာ၊ ကွန်ရက်နဲ့ စစ်ဆေးမည့်လိပ်စာကို စစ်ပါ။",
  "Invalid Android VPN configuration.": "Android VPN ဆက်တင် မမှန်ပါ။",
  "Default server is already available.":
      "အခမဲ့ဆာဗာ ရှိပြီးသားပါ။ ရွေးပြီး ချိတ်နိုင်ပါတယ်။",
  "The default server cannot be removed.":
      "အခမဲ့ဆာဗာကို ဖယ်ရှားမရပါ။ ကိုယ်ပိုင်ဆာဗာကို ရွေးသုံးနိုင်ပါတယ်။",
  "Android VPN is already starting or stopping.":
      "Android VPN ချိတ်နေသည် သို့မဟုတ် ဖြုတ်နေသည်။ ခဏစောင့်ပါ။",
};
