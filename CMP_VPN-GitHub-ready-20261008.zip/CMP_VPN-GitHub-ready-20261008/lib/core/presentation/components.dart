import '../l10n/app_strings.dart';
import 'package:flutter/material.dart';

class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 38});
  final double size;
  @override
  Widget build(BuildContext context) => Semantics(
    label: context.tr('CMP VPN logo'),
    image: true,
    child: Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary,
        borderRadius: BorderRadius.circular(size * .3),
      ),
      child: Icon(
        Icons.shield_outlined,
        color: Theme.of(context).colorScheme.onPrimary,
        size: size * .65,
      ),
    ),
  );
}

class SurfacePanel extends StatelessWidget {
  const SurfacePanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(24),
  });
  final Widget child;
  final EdgeInsetsGeometry padding;
  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surfaceContainerLow,
    shape: RoundedRectangleBorder(
      side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
      borderRadius: BorderRadius.circular(24),
    ),
    child: Padding(padding: padding, child: child),
  );
}

class SectionHeading extends StatelessWidget {
  const SectionHeading({
    super.key,
    this.eyebrow = '',
    required this.title,
    this.description = '',
  });
  final String eyebrow;
  final String title;
  final String description;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      if (eyebrow.isNotEmpty)
        AppText(
          eyebrow.toUpperCase(),
          style: TextStyle(
            color: Theme.of(context).colorScheme.primary,
            letterSpacing: 0,
            fontWeight: FontWeight.w700,
            fontSize: 11,
          ),
        ),
      if (eyebrow.isNotEmpty) const SizedBox(height: 6),
      AppText(title, style: Theme.of(context).textTheme.titleLarge),
      if (description.isNotEmpty) ...[
        const SizedBox(height: 8),
        AppText(description),
      ],
      const SizedBox(height: 18),
    ],
  );
}

class EmptyCollection extends StatelessWidget {
  const EmptyCollection({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    required this.availability,
  });
  final IconData icon;
  final String title;
  final String description;
  final String availability;
  @override
  Widget build(BuildContext context) => SurfacePanel(
    child: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 42),
          child: Column(
            children: [
              Icon(
                icon,
                size: 48,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 24),
              AppText(
                title,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 10),
              AppText(description, textAlign: TextAlign.center),
              const SizedBox(height: 24),
              AppText(
                availability,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
