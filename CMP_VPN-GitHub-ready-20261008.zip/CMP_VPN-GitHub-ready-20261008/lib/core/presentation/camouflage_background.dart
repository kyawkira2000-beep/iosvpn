import 'package:flutter/material.dart';

/// Vector camouflage: no downloaded artwork, extra assets or continuous repaint.
class CamouflageBackground extends StatelessWidget {
  const CamouflageBackground({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => CustomPaint(
    painter: _CamouflagePainter(
      Theme.of(context).brightness == Brightness.dark,
    ),
    child: SizedBox.expand(child: child),
  );
}

class _CamouflagePainter extends CustomPainter {
  const _CamouflagePainter(this.dark);
  final bool dark;
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    final colors = dark
        ? const [
            Color(0xFF1B251E),
            Color(0xFF27352A),
            Color(0xFF344030),
            Color(0xFF222D26),
          ]
        : const [
            Color(0xFFDEE1CE),
            Color(0xFFB6C0A3),
            Color(0xFFC8C9AC),
            Color(0xFF9EAF95),
          ];
    canvas.drawRect(Offset.zero & size, Paint()..color = colors[0]);
    for (var row = -1; row < (size.height / 250).ceil() + 1; row++) {
      for (var column = -1; column < (size.width / 300).ceil() + 1; column++) {
        canvas.save();
        canvas.translate(
          column * 310.0 + (row.isEven ? 100 : -30),
          row * 250.0,
        );
        final patch = Path()
          ..moveTo(10, 35)
          ..cubicTo(55, -28, 140, 12, 155, 40)
          ..cubicTo(184, 83, 254, 21, 292, 83)
          ..cubicTo(335, 147, 215, 155, 208, 201)
          ..cubicTo(194, 255, 126, 205, 86, 227)
          ..cubicTo(15, 262, -33, 192, 4, 140)
          ..cubicTo(37, 95, -24, 83, 10, 35)
          ..close();
        canvas.drawPath(
          patch,
          Paint()..color = colors[1 + (row + column).abs() % 3],
        );
        canvas.translate(185, 105);
        canvas.scale(.50, .48);
        canvas.rotate(.7);
        canvas.drawPath(
          patch,
          Paint()..color = colors[1 + (row * 2 + column + 1).abs() % 3],
        );
        canvas.restore();
      }
    }
    // Quiet the pattern behind text while keeping a recognizable camo silhouette.
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: dark
              ? [const Color(0x00202A22), const Color(0x99121916)]
              : [const Color(0x35F6F5EB), const Color(0xAAF6F5EB)],
        ).createShader(Offset.zero & size),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_CamouflagePainter oldDelegate) =>
      oldDelegate.dark != dark;
}
