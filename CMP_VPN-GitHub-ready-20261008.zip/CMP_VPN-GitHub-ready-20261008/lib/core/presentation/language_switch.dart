import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/settings/presentation/language_controller.dart';
import '../l10n/app_strings.dart';

class LanguageSwitch extends ConsumerWidget {
  const LanguageSwitch({super.key, this.compact = false});
  final bool compact;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final language = ref.watch(languageProvider);
    Future<void> change(String value) async {
      try {
        await ref.read(languageProvider.notifier).select(value);
      } catch (_) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: AppText('Could not save language. Please try again.'),
            ),
          );
        }
      }
    }

    if (compact) {
      return TextButton.icon(
        key: const Key('language-toggle'),
        onPressed: () => change(language == 'my' ? 'en' : 'my'),
        icon: const Icon(Icons.translate_rounded, size: 18),
        label: Text(language == 'my' ? 'EN' : 'မြန်မာ'),
      );
    }
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final item in [('my', 'မြန်မာ'), ('en', 'English')])
          ChoiceChip(
            key: Key('language-${item.$1}'),
            label: Text(item.$2),
            selected: language == item.$1,
            onSelected: (_) => change(item.$1),
          ),
      ],
    );
  }
}
