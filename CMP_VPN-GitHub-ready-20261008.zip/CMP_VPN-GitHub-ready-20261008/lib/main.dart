import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/aerolink_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  LicenseRegistry.addLicense(() async* {
    yield LicenseEntryWithLineBreaks([
      'Noto Sans Myanmar',
    ], await rootBundle.loadString('assets/licenses/NotoSansMyanmar-OFL.txt'));
    yield LicenseEntryWithLineBreaks([
      defaultTargetPlatform == TargetPlatform.android
          ? 'Xray-core 26.9.30 (unmodified)'
          : 'Xray-core 26.3.27 (unmodified)',
    ], await rootBundle.loadString('assets/licenses/xray-MPL-2.0.txt'));
    yield LicenseEntryWithLineBreaks([
      'XTLS/libXray 26.9.30 (MIT, unmodified)',
    ], await rootBundle.loadString('assets/licenses/libXray-MIT.txt'));
    yield LicenseEntryWithLineBreaks([
      'Wintun (WireGuard LLC, signed binary)',
    ], await rootBundle.loadString('assets/licenses/wintun.txt'));
  });
  runApp(const ProviderScope(child: AerolinkApp()));
}
