import '../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import '../core/presentation/components.dart';
import 'app_shell.dart';

/// A branded first frame, with no artificial startup delay or network activity.
class StartupScreen extends StatefulWidget {
  const StartupScreen({super.key});
  @override
  State<StartupScreen> createState() => _StartupScreenState();
}

class _StartupScreenState extends State<StartupScreen> {
  bool ready = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() => ready = true);
    });
  }

  @override
  Widget build(BuildContext context) => ready
      ? const AppShell()
      : Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const BrandMark(size: 64),
                const SizedBox(height: 20),
                AppText(
                  'CMP VPN',
                  style: Theme.of(context).textTheme.headlineLarge,
                ),
              ],
            ),
          ),
        );
}
