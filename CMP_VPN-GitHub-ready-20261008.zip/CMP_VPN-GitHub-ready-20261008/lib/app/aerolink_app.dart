import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/settings/presentation/settings_controller.dart';
import 'startup_screen.dart';
import 'app_theme.dart';
import '../features/settings/presentation/language_controller.dart';

class AerolinkApp extends ConsumerWidget {
  const AerolinkApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => MaterialApp(
    title: 'CMP VPN',
    locale: Locale(ref.watch(languageProvider)),
    supportedLocales: const [Locale('my'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    debugShowCheckedModeBanner: false,
    theme: AppTheme.create(Brightness.light),
    darkTheme: AppTheme.create(Brightness.dark),
    themeMode: ref.watch(themeModeProvider),
    home: const StartupScreen(),
  );
}
