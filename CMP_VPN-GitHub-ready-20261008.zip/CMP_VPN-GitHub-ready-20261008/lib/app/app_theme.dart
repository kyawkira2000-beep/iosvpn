import 'package:flutter/material.dart';

abstract final class AppTheme {
  static ThemeData create(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme =
        ColorScheme.fromSeed(
          seedColor: const Color(0xFF2878E8),
          brightness: brightness,
        ).copyWith(
          primary: dark ? const Color(0xFF9CC5FF) : const Color(0xFF2168D5),
          onPrimary: dark ? const Color(0xFF08264D) : Colors.white,
          surface: dark ? const Color(0xFF101723) : const Color(0xFFF4F6FA),
          surfaceContainerLow: dark ? const Color(0xFF1B2535) : Colors.white,
          outlineVariant: dark
              ? const Color(0xFF3C4A60)
              : const Color(0xFFDDE3EE),
        );
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      fontFamily: 'Noto Sans Myanmar',
      textTheme: TextTheme(
        headlineLarge: TextStyle(
          fontSize: 34,
          fontWeight: FontWeight.w700,
          letterSpacing: 0,
          color: scheme.onSurface,
        ),
        headlineMedium: TextStyle(
          fontSize: 26,
          fontWeight: FontWeight.w600,
          letterSpacing: 0,
          color: scheme.onSurface,
        ),
        titleLarge: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: scheme.onSurface,
        ),
        bodyMedium: TextStyle(
          fontSize: 14,
          height: 1.5,
          color: scheme.onSurfaceVariant,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: scheme.surfaceContainerLow,
        indicatorColor: scheme.primary.withValues(alpha: .12),
      ),
      dividerColor: scheme.outlineVariant,
      tooltipTheme: const TooltipThemeData(
        waitDuration: Duration(milliseconds: 350),
      ),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
      ),
    );
  }
}
