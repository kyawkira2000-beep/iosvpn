import 'package:flutter/material.dart';
import '../core/l10n/app_strings.dart';
import '../core/presentation/language_switch.dart';
import '../features/connection/presentation/home_screen.dart';
import '../features/logs/presentation/logs_screen.dart';
import '../features/profiles/presentation/servers_screen.dart';
import '../features/settings/presentation/settings_screen.dart';
import '../features/subscriptions/presentation/subscriptions_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int selected = 0;
  void showLogs() => Navigator.of(
    context,
  ).push(MaterialPageRoute<void>(builder: (_) => const LogsScreen()));
  @override
  Widget build(BuildContext context) {
    final screen = switch (selected) {
      0 => HomeScreen(
        onServers: () => setState(() => selected = 1),
        onLogs: showLogs,
      ),
      1 => Column(
        children: [
          const ServersScreen(),
          const SizedBox(height: 24),
          const SubscriptionsScreen(),
        ],
      ),
      _ => SettingsScreen(onLogs: showLogs),
    };
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'CMP VPN',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        actions: const [LanguageSwitch(compact: true), SizedBox(width: 12)],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          key: ValueKey(selected),
          padding: const EdgeInsets.all(20),
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 640),
              child: screen,
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selected,
        onDestinationSelected: (value) => setState(() => selected = value),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.power_settings_new),
            label: context.tr('Home'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.dns_outlined),
            label: context.tr('Configs'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.tune_rounded),
            label: context.tr('Settings'),
          ),
        ],
      ),
    );
  }
}
