import '../../../core/l10n/app_strings.dart';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import '../../../core/domain/app_failure.dart';
import '../data/qr_decoder.dart';

class QrCameraScreen extends StatefulWidget {
  const QrCameraScreen({super.key});
  @override
  State<QrCameraScreen> createState() => _QrCameraScreenState();
}

class _QrCameraScreenState extends State<QrCameraScreen>
    with WidgetsBindingObserver {
  CameraController? camera;
  bool busy = false;
  String? error;
  int generation = 0;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    initialize();
  }

  Future<void> initialize() async {
    final token = ++generation;
    CameraController? next;
    try {
      final devices = await availableCameras();
      if (devices.isEmpty) {
        throw const AppFailure(
          'No camera was found. Import a QR image instead.',
        );
      }
      final device =
          devices
              .where((d) => d.lensDirection == CameraLensDirection.back)
              .firstOrNull ??
          devices.first;
      next = CameraController(
        device,
        ResolutionPreset.high,
        enableAudio: false,
      );
      await next.initialize();
      if (!mounted || token != generation) {
        await next.dispose();
        return;
      }
      setState(() {
        camera = next;
        error = null;
      });
    } catch (e) {
      await next?.dispose();
      if (mounted && token == generation) {
        setState(
          () => error = e is AppFailure
              ? safeError(e)
              : "Camera access is unavailable. Check camera permissions or import a QR image.",
        );
      }
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      generation++;
      final old = camera;
      camera = null;
      old?.dispose();
      if (mounted) setState(() {});
    } else if (state == AppLifecycleState.resumed && camera == null) {
      initialize();
    }
  }

  Future<void> scan() async {
    final active = camera;
    if (active == null || busy) return;
    setState(() => busy = true);
    XFile? photo;
    try {
      photo = await active.takePicture();
      if (await photo.length() > 8 * 1024 * 1024) {
        throw const AppFailure(
          'Camera image is too large. Import a smaller QR image.',
        );
      }
      final text = await decodeQr(await photo.readAsBytes());
      if (mounted) Navigator.of(context).pop(text);
    } catch (e) {
      if (mounted) setState(() => error = safeError(e));
    } finally {
      // Delete only the temporary image returned by this camera capture.
      if (photo != null) {
        try {
          await File(photo.path).delete();
        } catch (_) {}
      }
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    generation++;
    WidgetsBinding.instance.removeObserver(this);
    camera?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const AppText("Scan QR code")),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          const AppText(
            "Point the camera at one QR code, then press Scan. Images are decoded on this device.",
          ),
          const SizedBox(height: 16),
          Expanded(
            child: camera == null
                ? Center(child: AppText(error ?? "Opening camera…"))
                : Center(
                    child: AspectRatio(
                      aspectRatio: camera!.value.aspectRatio,
                      child: CameraPreview(camera!),
                    ),
                  ),
          ),
          if (error != null && camera != null)
            Padding(padding: const EdgeInsets.all(12), child: AppText(error!)),
          FilledButton.icon(
            onPressed: camera != null && !busy ? scan : null,
            icon: const Icon(Icons.qr_code_scanner),
            label: AppText(busy ? "Reading…" : "Scan QR"),
          ),
        ],
      ),
    ),
  );
}
