import '../../../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:file_selector/file_selector.dart';
import '../../../core/domain/app_failure.dart';
import '../../../core/presentation/components.dart';
import '../data/qr_decoder.dart';
import 'catalog_controller.dart';
import 'import_dialog.dart';
import 'qr_camera_screen.dart';

class ServersScreen extends ConsumerWidget {
  const ServersScreen({super.key});
  Future<void> action(BuildContext context, Future<void> Function() run) async {
    try {
      await run();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: AppText(safeError(e))));
      }
    }
  }

  Future<void> imageQr(BuildContext context) async {
    final file = await openFile(
      acceptedTypeGroups: [
        XTypeGroup(
          label: context.tr("QR images"),
          extensions: ['png', 'jpg', 'jpeg'],
          mimeTypes: ['image/png', 'image/jpeg'],
        ),
      ],
    );
    if (file == null) return;
    if (await file.length() > 8 * 1024 * 1024) {
      throw const AppFailure('QR image exceeds 8 MB.');
    }
    final value = await decodeQr(await file.readAsBytes());
    if (context.mounted) await reviewQr(context, value);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final library = ref.watch(catalogProvider);
    final busy = ref.watch(libraryBusyProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeading(title: "Choose a server"),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            FilledButton.icon(
              onPressed: busy || !library.hasValue
                  ? null
                  : () => showDialog<void>(
                      context: context,
                      builder: (_) => const ImportDialog(),
                    ),
              icon: const Icon(Icons.add_link),
              label: const AppText("Add your key"),
            ),
            OutlinedButton.icon(
              onPressed: busy || !library.hasValue
                  ? null
                  : () => showDialog<void>(
                      context: context,
                      builder: (_) => const ImportDialog(manual: true),
                    ),
              icon: const Icon(Icons.edit_outlined),
              label: const AppText("Manual entry"),
            ),
            OutlinedButton.icon(
              onPressed: busy || !library.hasValue
                  ? null
                  : () => action(context, () => imageQr(context)),
              icon: const Icon(Icons.image_outlined),
              label: const AppText("QR image"),
            ),
            OutlinedButton.icon(
              onPressed: busy || !library.hasValue
                  ? null
                  : () => action(context, () async {
                      final result = await Navigator.push<String>(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const QrCameraScreen(),
                        ),
                      );
                      if (result != null && context.mounted) {
                        await reviewQr(context, result);
                      }
                    }),
              icon: const Icon(Icons.qr_code_scanner),
              label: const AppText("Scan QR"),
            ),
          ],
        ),
        const SizedBox(height: 20),
        library.when(
          loading: () => const LinearProgressIndicator(),
          error: (e, _) => SurfacePanel(
            child: Column(
              children: [
                AppText(safeError(e)),
                TextButton(
                  onPressed: () => ref.invalidate(catalogProvider),
                  child: const AppText("Retry secure storage"),
                ),
              ],
            ),
          ),
          data: (catalog) {
            if (catalog.profiles.isEmpty) {
              return const EmptyCollection(
                icon: Icons.dns_outlined,
                title: "A home for your servers",
                description:
                    "Add a VLESS link, scan a QR code or enter your server details.",
                availability: "VPN connection support is still being built.",
              );
            }
            return Column(
              children: [
                for (final saved in catalog.profiles)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: SurfacePanel(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                catalog.selected == saved.key
                                    ? Icons.radio_button_checked
                                    : Icons.radio_button_off,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  saved.isBuiltIn
                                      ? context.tr('Free server')
                                      : saved.displayName,
                                  style: Theme.of(
                                    context,
                                  ).textTheme.titleMedium,
                                ),
                              ),
                              if (!saved.isBuiltIn)
                                PopupMenuButton<String>(
                                  key: Key('profile-menu-${saved.key}'),
                                  enabled: !busy,
                                  onSelected: (value) => action(context, () async {
                                    if (value == 'delete') {
                                      final yes = await showDialog<bool>(
                                        context: context,
                                        builder: (ctx) => AlertDialog(
                                          title: const AppText(
                                            "Remove server?",
                                          ),
                                          content: AppText(
                                            saved.subscriptionId == null
                                                ? "Remove this server from encrypted storage?"
                                                : "Remove this server? A subscription refresh can add it again.",
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () =>
                                                  Navigator.pop(ctx, false),
                                              child: const AppText("Cancel"),
                                            ),
                                            FilledButton(
                                              onPressed: () =>
                                                  Navigator.pop(ctx, true),
                                              child: const AppText("Remove"),
                                            ),
                                          ],
                                        ),
                                      );
                                      if (yes == true) {
                                        await ref
                                            .read(catalogProvider.notifier)
                                            .removeProfile(saved.key);
                                      }
                                    } else {
                                      final yes = await showDialog<bool>(
                                        context: context,
                                        builder: (ctx) => AlertDialog(
                                          title: const AppText(
                                            "Copy secret connection link?",
                                          ),
                                          content: const AppText(
                                            "This link contains your credentials. Other apps may read your clipboard. Share it only with people you trust.",
                                          ),
                                          actions: [
                                            TextButton(
                                              onPressed: () =>
                                                  Navigator.pop(ctx, false),
                                              child: const AppText("Cancel"),
                                            ),
                                            FilledButton(
                                              onPressed: () =>
                                                  Navigator.pop(ctx, true),
                                              child: const AppText("Copy link"),
                                            ),
                                          ],
                                        ),
                                      );
                                      if (yes == true) {
                                        await Clipboard.setData(
                                          ClipboardData(
                                            text: saved.exportLink!,
                                          ),
                                        );
                                      }
                                    }
                                  }),
                                  itemBuilder: (_) => const [
                                    PopupMenuItem(
                                      value: 'copy',
                                      child: AppText(
                                        "Export link to clipboard",
                                      ),
                                    ),
                                    PopupMenuItem(
                                      value: 'delete',
                                      child: AppText("Remove"),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          AppText(
                            saved.isBuiltIn
                                ? 'Default'
                                : saved.subscriptionId == null
                                ? "Personal server"
                                : "From subscription",
                            style: const TextStyle(fontSize: 12),
                          ),
                          for (final warning in saved.profile.warnings)
                            Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: AppText(
                                warning,
                                style: TextStyle(
                                  color: Theme.of(
                                    context,
                                  ).colorScheme.onSurfaceVariant,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          const SizedBox(height: 8),
                          TextButton(
                            onPressed: busy
                                ? null
                                : () => action(
                                    context,
                                    () => ref
                                        .read(catalogProvider.notifier)
                                        .select(saved.key),
                                  ),
                            child: AppText(
                              catalog.selected == saved.key
                                  ? "Selected"
                                  : "Select",
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}
