import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/domain/app_failure.dart';
import '../../subscriptions/data/subscription_client.dart';
import '../../subscriptions/domain/subscription_feed.dart';
import '../data/catalog_repository.dart';
import '../domain/catalog.dart';
import '../domain/vless_profile.dart';
import '../domain/bundled_profile.dart';

final vaultStorageProvider = Provider<VaultStorage>(
  (ref) => const NativeVaultStorage(),
);
final bundledProfileProvider = Provider<SavedProfile?>(
  (ref) => bundledProfile(),
);
final catalogRepositoryProvider = Provider(
  (ref) => CatalogRepository(
    ref.watch(vaultStorageProvider),
    defaultProfile: ref.watch(bundledProfileProvider),
  ),
);
final subscriptionClientProvider = Provider((ref) => SubscriptionClient());
final catalogProvider = AsyncNotifierProvider<CatalogController, Catalog>(
  CatalogController.new,
);
final libraryBusyProvider = NotifierProvider<LibraryBusy, bool>(
  LibraryBusy.new,
);

class LibraryBusy extends Notifier<bool> {
  @override
  bool build() => false;
  void set(bool value) => state = value;
}

class CatalogController extends AsyncNotifier<Catalog> {
  @override
  Future<Catalog> build() => ref.watch(catalogRepositoryProvider).load();
  Future<void> _change(Future<Catalog> Function(Catalog) operation) async {
    if (ref.read(libraryBusyProvider)) {
      throw const AppFailure('Another library operation is still running.');
    }
    final catalog = state.asData?.value;
    if (catalog == null) {
      throw const AppFailure(
        'Wait for secure storage to load or retry opening it.',
      );
    }
    ref.read(libraryBusyProvider.notifier).set(true);
    try {
      final next = ref
          .read(catalogRepositoryProvider)
          .withDefault(await operation(catalog));
      await ref.read(catalogRepositoryProvider).save(next);
      state = AsyncData(next);
    } finally {
      ref.read(libraryBusyProvider.notifier).set(false);
    }
  }

  Future<void> importLink(String link) => _change((catalog) async {
    final saved = SavedProfile(VlessProfile.parse(link));
    if (catalog.profiles.any(
      (p) => p.isBuiltIn && sameCredentials(p.profile, saved.profile),
    )) {
      throw const AppFailure('Default server is already available.');
    }
    if (catalog.profiles.any((p) => p.key == saved.key)) {
      throw const AppFailure('This manual profile is already in your library.');
    }
    return Catalog(
      profiles: List.unmodifiable([...catalog.profiles, saved]),
      subscriptions: catalog.subscriptions,
      selected: saved.key,
    );
  });
  Future<void> select(String key) => _change((c) async {
    if (!c.profiles.any((p) => p.key == key)) {
      throw const AppFailure('This server is no longer in the library.');
    }
    return Catalog(
      profiles: c.profiles,
      subscriptions: c.subscriptions,
      selected: key,
    );
  });
  Future<void> removeProfile(String key) => _change((c) async {
    if (c.profiles.any((p) => p.key == key && p.isBuiltIn)) {
      throw const AppFailure('The default server cannot be removed.');
    }
    return Catalog(
      profiles: List.unmodifiable(c.profiles.where((p) => p.key != key)),
      subscriptions: c.subscriptions,
      selected: c.selected == key ? null : c.selected,
    );
  });
  Future<void> removeSubscription(String id) => _change((c) async {
    final profiles = c.profiles.where((p) => p.subscriptionId != id).toList();
    return Catalog(
      profiles: List.unmodifiable(profiles),
      subscriptions: List.unmodifiable(
        c.subscriptions.where((s) => s.id != id),
      ),
      selected: profiles.any((p) => p.key == c.selected) ? c.selected : null,
    );
  });
  Catalog _replace(
    Catalog c,
    String id,
    String name,
    String url,
    SubscriptionFeed feed,
  ) {
    final profiles = [
      ...c.profiles.where((p) => p.subscriptionId != id),
      ...feed.profiles.map((p) => SavedProfile(p, subscriptionId: id)),
    ];
    final sub = SavedSubscription(
      id: id,
      name: name,
      url: url,
      updated: DateTime.now().millisecondsSinceEpoch,
      upload: feed.upload,
      download: feed.download,
      total: feed.total,
      expiry: feed.expiry,
      rejected: feed.rejected,
    );
    return Catalog(
      profiles: List.unmodifiable(profiles),
      subscriptions: List.unmodifiable([
        ...c.subscriptions.where((s) => s.id != id),
        sub,
      ]),
      selected: profiles.any((p) => p.key == c.selected) ? c.selected : null,
    );
  }

  Future<void> addSubscription(String name, String url) => _change((c) async {
    final validated = validateSubscriptionUrl(url).toString();
    if (name.trim().isEmpty ||
        name.length > 80 ||
        name.contains(RegExp(r'[\x00-\x1f]'))) {
      throw const AppFailure('Choose a subscription name of 1–80 characters.');
    }
    if (c.subscriptions.any((s) => s.url == validated)) {
      throw const AppFailure('This subscription is already saved.');
    }
    if (c.subscriptions.length >= 20) {
      throw const AppFailure('You can save up to 20 subscriptions.');
    }
    final feed = await ref.read(subscriptionClientProvider).fetch(validated);
    final random = Random.secure();
    final id = List.generate(
      16,
      (_) => random.nextInt(256).toRadixString(16).padLeft(2, '0'),
    ).join();
    return _replace(c, id, name.trim(), validated, feed);
  });
  Future<void> refresh(String id) => _change((c) async {
    final sub = c.subscriptions.where((s) => s.id == id).firstOrNull;
    if (sub == null) throw const AppFailure('Subscription no longer exists.');
    final feed = await ref.read(subscriptionClientProvider).fetch(sub.url);
    return _replace(c, id, sub.name, sub.url, feed);
  });
}
