import '../../../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/domain/app_failure.dart';
import '../../subscriptions/presentation/subscription_dialog.dart';
import '../domain/vless_profile.dart';
import 'catalog_controller.dart';

Future<void> reviewQr(BuildContext context, String content) async {
  if (content.startsWith('https://')) {
    await showDialog<void>(
      context: context,
      builder: (_) => SubscriptionDialog(initialUrl: content),
    );
  } else if (content.startsWith('vless://')) {
    await showDialog<void>(
      context: context,
      builder: (_) => ImportDialog(initialLink: content),
    );
  } else {
    throw const AppFailure(
      'QR must contain one VLESS link or HTTPS subscription URL.',
    );
  }
}

class ImportDialog extends ConsumerStatefulWidget {
  const ImportDialog({super.key, this.initialLink = '', this.manual = false});
  final String initialLink;
  final bool manual;
  @override
  ConsumerState<ImportDialog> createState() => _ImportDialogState();
}

class _ImportDialogState extends ConsumerState<ImportDialog> {
  late final link = TextEditingController(text: widget.initialLink);
  final fields = {
    for (final name in [
      'Name',
      'Server address',
      'Port',
      'UUID',
      'SNI',
      'Fingerprint',
      'Flow',
      'Public key',
      'Short ID',
      'ALPN',
      'Extra parameters',
    ])
      name: TextEditingController(),
  };
  String security = 'reality', transport = 'tcp';
  String? error;
  bool busy = false;
  @override
  void initState() {
    super.initState();
    fields['Port']!.text = '443';
    fields['Fingerprint']!.text = 'chrome';
    fields['Flow']!.text = 'xtls-rprx-vision';
  }

  String manualLink() {
    String get(String name) => fields[name]!.text.trim();
    final port = int.tryParse(get('Port'));
    if (port == null || port < 1 || port > 65535) {
      throw const AppFailure('Enter a valid port (1–65535).');
    }
    Map<String, String> extra;
    try {
      final values = Uri(query: get('Extra parameters')).queryParametersAll;
      if (values.values.any((v) => v.length != 1)) {
        throw const FormatException();
      }
      extra = values.map((k, v) => MapEntry(k, v.single));
    } catch (_) {
      throw const AppFailure(
        'Extra parameters must be URL query syntax, for example path=%2Fws.',
      );
    }
    final core = {
      'type': transport,
      'security': security,
      'encryption': 'none',
      'sni': get('SNI'),
      'fp': get('Fingerprint'),
      'flow': get('Flow'),
      'alpn': get('ALPN'),
      if (security == 'reality') ...{
        'pbk': get('Public key'),
        'sid': get('Short ID'),
      },
    };
    if (extra.keys.any(core.containsKey)) {
      throw const AppFailure(
        'Extra parameters cannot override the fields above.',
      );
    }
    return Uri(
      scheme: 'vless',
      userInfo: get('UUID'),
      host: get('Server address'),
      port: port,
      queryParameters: {...core, ...extra},
      fragment: get('Name'),
    ).toString();
  }

  Future<void> save() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final input = widget.manual ? manualLink() : link.text;
      VlessProfile.parse(input);
      await ref.read(catalogProvider.notifier).importLink(input);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) setState(() => error = safeError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    link.dispose();
    for (final f in fields.values) {
      f.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !busy,
    child: AlertDialog(
      title: AppText(
        widget.manual ? "Add server manually" : "Import VLESS link",
      ),
      content: SizedBox(
        width: 520,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const AppText("Enter your VLESS key."),
              const SizedBox(height: 16),
              if (!widget.manual)
                TextField(
                  key: const Key('vless-input'),
                  controller: link,
                  maxLines: 5,
                  maxLength: 16384,
                  autocorrect: false,
                  enableSuggestions: false,
                  enableIMEPersonalizedLearning: false,
                  decoration: InputDecoration(
                    labelText: context.tr("VLESS link"),
                    hintText: 'vless://…',
                  ),
                ),
              if (widget.manual) ...[
                DropdownButtonFormField<String>(
                  initialValue: security,
                  decoration: InputDecoration(
                    labelText: context.tr("Security"),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'reality',
                      child: AppText('REALITY'),
                    ),
                    DropdownMenuItem(
                      value: 'tls',
                      child: AppText("TLS (connection testing later)"),
                    ),
                  ],
                  onChanged: busy ? null : (v) => setState(() => security = v!),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: transport,
                  decoration: InputDecoration(
                    labelText: context.tr("Transport"),
                  ),
                  items: [
                    for (final t in [
                      'tcp',
                      'raw',
                      'ws',
                      'grpc',
                      'httpupgrade',
                      'xhttp',
                    ])
                      DropdownMenuItem(value: t, child: AppText(t)),
                  ],
                  onChanged: busy
                      ? null
                      : (v) => setState(() => transport = v!),
                ),
                for (final field in fields.entries)
                  if (security == 'reality' ||
                      !['Public key', 'Short ID'].contains(field.key))
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: TextField(
                        key: Key('manual-${field.key}'),
                        controller: field.value,
                        maxLength: field.key == 'Extra parameters' ? 4096 : 512,
                        obscureText: field.key == 'UUID',
                        autocorrect: false,
                        enableSuggestions: false,
                        enableIMEPersonalizedLearning: false,
                        decoration: InputDecoration(
                          labelText: context.tr(field.key),
                          helperText: field.key == 'Extra parameters'
                              ? context.tr(
                                  "Optional query fields such as path, host or serviceName",
                                )
                              : null,
                        ),
                      ),
                    ),
              ],
              if (error != null)
                AppText(
                  error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: busy ? null : () => Navigator.pop(context),
          child: const AppText("Cancel"),
        ),
        FilledButton(
          key: const Key('save-profile'),
          onPressed: busy ? null : save,
          child: AppText(busy ? "Saving…" : "Save server"),
        ),
      ],
    ),
  );
}
