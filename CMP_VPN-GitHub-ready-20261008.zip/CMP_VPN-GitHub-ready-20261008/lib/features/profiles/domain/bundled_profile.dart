import 'catalog.dart';
import 'vless_profile.dart';

/// Supplied from an ignored local build configuration, never a checked-in key.
/// Bundling enables offline first use; it does not make credentials impossible
/// to recover from a binary or running process. UI/export protection is separate.
SavedProfile? bundledProfile() {
  if (const bool.fromEnvironment('DMS_MANAGED_ONLY')) return null;
  const link = String.fromEnvironment('DMS_DEFAULT_VLESS');
  if (link.isEmpty) return null;
  return SavedProfile(VlessProfile.parse(link), isBuiltIn: true);
}

bool sameCredentials(VlessProfile a, VlessProfile b) =>
    a.uuid == b.uuid && a.host == b.host && a.port == b.port;
