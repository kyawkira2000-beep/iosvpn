import 'dart:convert';
import 'package:crypto/crypto.dart';
import '../../../core/domain/app_failure.dart';

class VlessProfile {
  VlessProfile._(this.link, this.uri, this.parameters, this.id, this.warnings);
  final String link;
  final Uri uri;
  final Map<String, List<String>> parameters;
  final String id;
  final List<String> warnings;
  String get name =>
      uri.fragment.isEmpty ? uri.host : Uri.decodeComponent(uri.fragment);
  String get host => uri.host;
  String get endpoint => '${host.contains(':') ? '[$host]' : host}:$port';
  int get port => uri.port;
  String get uuid => Uri.decodeComponent(uri.userInfo).toLowerCase();
  String value(String key, [String fallback = '']) =>
      parameters[key]?.first ?? fallback;
  String get security => value('security');
  String get transport => value('type', 'tcp');
  bool get managed => value('dms') == '1';
  bool get baselineEligible =>
      (security == 'reality' || managed) &&
      ['tcp', 'raw'].contains(transport) &&
      warnings.isEmpty;

  static const known = {
    'dms',
    'type',
    'security',
    'encryption',
    'sni',
    'fp',
    'flow',
    'pbk',
    'sid',
    'alpn',
    'path',
    'host',
    'serviceName',
    'mode',
    'authority',
    'spx',
    'allowInsecure',
    'insecure',
    'headerType',
    'extra',
    'pqv',
  };
  static VlessProfile parse(String input) {
    final text = input.trim();
    if (text.length > 16384) {
      throw const AppFailure('VLESS link exceeds 16 KB.');
    }
    try {
      if (RegExp(r'[\x00-\x20\x7f]').hasMatch(text) ||
          RegExp(r'%(?![0-9a-fA-F]{2})').hasMatch(text)) {
        throw const AppFailure(
          'The link contains invalid whitespace or percent encoding.',
        );
      }
      final uri = Uri.parse(text);
      if (uri.scheme != 'vless') {
        throw const AppFailure('Only VLESS connection links are supported.');
      }
      if (!uri.hasAuthority ||
          uri.host.isEmpty ||
          !uri.hasPort ||
          uri.port < 1 ||
          uri.port > 65535) {
        throw const AppFailure(
          'A valid server address and port (1–65535) are required.',
        );
      }
      if (uri.path.isNotEmpty && uri.path != '/') {
        throw const AppFailure(
          'Transport paths belong in the path query parameter.',
        );
      }
      if (!uri.host.contains(':') && !_hostname(uri.host)) {
        throw const AppFailure(
          'Server address must be an IP address or ASCII hostname (use punycode for international domains).',
        );
      }
      final uuid = Uri.decodeComponent(uri.userInfo);
      if (!RegExp(
        r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
      ).hasMatch(uuid)) {
        throw const AppFailure('A valid UUID is required.');
      }
      final query = uri.queryParametersAll;
      if (query.length > 64) {
        throw const AppFailure('Too many connection parameters.');
      }
      for (final entry in query.entries) {
        if (RegExp(r'[\x00-\x20\x7f]').hasMatch(entry.key)) {
          throw const AppFailure(
            'Connection parameter names contain invalid characters.',
          );
        }
        if (known.contains(entry.key) && entry.value.length != 1) {
          throw const AppFailure(
            'A connection parameter occurs more than once.',
          );
        }
        if (entry.value.any(
          (value) => RegExp(r'[\x00-\x1f\x7f]').hasMatch(value),
        )) {
          throw const AppFailure(
            'Connection parameters contain control characters.',
          );
        }
      }
      String get(String key, [String fallback = '']) =>
          query[key]?.first ?? fallback;
      if (!['reality', 'tls'].contains(get('security'))) {
        throw const AppFailure('security must be reality or tls.');
      }
      if (get('encryption', 'none') != 'none') {
        throw const AppFailure(
          'This version supports VLESS encryption=none only.',
        );
      }
      if (query.keys.any(
        (key) => [
          'privatekey',
          'private_key',
          'password',
        ].contains(key.toLowerCase()),
      )) {
        throw const AppFailure(
          'A client link must not contain server private keys or passwords.',
        );
      }
      for (final key in ['allowInsecure', 'insecure']) {
        if (query.containsKey(key) &&
            !['false', '0'].contains(get(key).toLowerCase())) {
          throw const AppFailure(
            'Disabling certificate validation is not supported.',
          );
        }
      }
      final type = get('type', 'tcp');
      if (![
        'tcp',
        'raw',
        'ws',
        'grpc',
        'httpupgrade',
        'xhttp',
      ].contains(type)) {
        throw const AppFailure(
          'This transport is not supported by the importer.',
        );
      }
      final flow = get('flow');
      if (query.containsKey('dms') &&
          (get('dms') != '1' ||
              get('security') != 'tls' ||
              !['tcp', 'raw'].contains(type) ||
              flow.isNotEmpty ||
              query.keys.any(
                (k) => !{
                  'dms',
                  'security',
                  'type',
                  'encryption',
                  'sni',
                }.contains(k),
              ))) {
        throw const AppFailure(
          'Managed access requires TLS over TCP/RAW without extra transport options.',
        );
      }
      if (flow.isNotEmpty && flow != 'xtls-rprx-vision') {
        throw const AppFailure('Unsupported VLESS flow.');
      }
      if (flow.isNotEmpty && !['tcp', 'raw'].contains(type)) {
        throw const AppFailure('Vision flow requires TCP/RAW in this client.');
      }
      if (get('security') == 'reality') {
        if (!['tcp', 'raw', 'grpc', 'xhttp'].contains(type)) {
          throw const AppFailure(
            'REALITY is incompatible with this transport.',
          );
        }
        if (get('sni').isEmpty ||
            get('fp').isEmpty ||
            get('pbk').isEmpty ||
            !query.containsKey('sid')) {
          throw const AppFailure(
            'REALITY requires SNI, fingerprint, public key and a short ID field (which may be empty).',
          );
        }
        if (!RegExp(r'^[A-Za-z0-9_-]{43}=?$').hasMatch(get('pbk')) ||
            base64Url.decode(base64Url.normalize(get('pbk'))).length != 32) {
          throw const AppFailure(
            'REALITY public key must contain 32 base64url-encoded bytes.',
          );
        }
        if (!RegExp(r'^(?:[0-9a-fA-F]{2}){0,8}$').hasMatch(get('sid'))) {
          throw const AppFailure(
            'REALITY short ID must be even-length hexadecimal, up to 16 characters.',
          );
        }
      }
      if (get('sni').isNotEmpty && !_hostname(get('sni'))) {
        throw const AppFailure('SNI must be a hostname.');
      }
      if (get('alpn').isNotEmpty &&
          get('alpn')
              .split(',')
              .any(
                (item) =>
                    item.isEmpty ||
                    item.length > 255 ||
                    item.contains(RegExp(r'\s')),
              )) {
        throw const AppFailure(
          'ALPN must be a comma-separated list without empty values.',
        );
      }
      final name = Uri.decodeComponent(uri.fragment);
      if (name.length > 120 || RegExp(r'[\x00-\x1f\x7f]').hasMatch(name)) {
        throw const AppFailure(
          'Profile name is too long or contains control characters.',
        );
      }
      final warnings = <String>[];
      if (query.keys.any((key) => !known.contains(key))) {
        warnings.add(
          'Extra parameters are preserved; runtime support is not verified.',
        );
      }
      if (get('security') == 'tls' && get('dms') != '1') {
        warnings.add('TLS connection testing follows the REALITY baseline.');
      }
      if (!['tcp', 'raw'].contains(type)) {
        warnings.add('This transport needs native compatibility testing.');
      }
      if (['extra', 'pqv', 'headerType'].any(query.containsKey)) {
        warnings.add('Advanced parameters require a matching native core.');
      }
      final normalized = <String, Object>{
        'server': uri.host.toLowerCase(),
        'port': uri.port,
        'uuid': uuid.toLowerCase(),
        'parameters': {
          for (final key in query.keys.toList()..sort()) key: query[key],
        },
      };
      final id = sha256.convert(utf8.encode(jsonEncode(normalized))).toString();
      return VlessProfile._(
        text,
        uri,
        Map.unmodifiable(
          query.map(
            (key, value) => MapEntry(key, List<String>.unmodifiable(value)),
          ),
        ),
        id,
        List.unmodifiable(warnings),
      );
    } on AppFailure {
      rethrow;
    } catch (_) {
      throw const AppFailure(
        'The VLESS link is malformed. Check its address, port and encoding.',
      );
    }
  }

  static bool _hostname(String text) {
    final host = text.endsWith('.') ? text.substring(0, text.length - 1) : text;
    if (host.isEmpty || host.length > 253) return false;
    return host
        .split('.')
        .every(
          (label) =>
              label.length <= 63 &&
              RegExp(
                r'^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$',
              ).hasMatch(label),
        );
  }
}
