import 'vless_profile.dart';

class SavedProfile {
  const SavedProfile(
    this.profile, {
    this.subscriptionId,
    this.isBuiltIn = false,
  });
  final VlessProfile profile;
  final String? subscriptionId;
  final bool isBuiltIn;
  String get key => isBuiltIn
      ? 'builtin:free'
      : '${subscriptionId ?? 'manual'}:${profile.id}';
  String get displayName => isBuiltIn ? 'အခမဲ့ဆာဗာ' : profile.name;
  String? get exportLink => isBuiltIn ? null : profile.link;
  Map<String, Object?> toJson() => {
    'link': profile.link,
    'subscriptionId': subscriptionId,
  };
  factory SavedProfile.fromJson(Map<String, dynamic> json) => SavedProfile(
    VlessProfile.parse(json['link'] as String),
    subscriptionId: json['subscriptionId'] as String?,
  );
}

class SavedSubscription {
  const SavedSubscription({
    required this.id,
    required this.name,
    required this.url,
    required this.updated,
    this.upload,
    this.download,
    this.total,
    this.expiry,
    this.rejected = 0,
  });
  final String id, name, url;
  final int updated, rejected;
  final int? upload, download, total, expiry;
  bool get expired =>
      expiry != null &&
      DateTime.now().millisecondsSinceEpoch ~/ 1000 >= expiry!;
  bool get exhausted =>
      total != null &&
      total! > 0 &&
      upload != null &&
      download != null &&
      upload! + download! >= total!;
  Map<String, Object?> toJson() => {
    'id': id,
    'name': name,
    'url': url,
    'updated': updated,
    'upload': upload,
    'download': download,
    'total': total,
    'expiry': expiry,
    'rejected': rejected,
  };
  factory SavedSubscription.fromJson(Map<String, dynamic> j) =>
      SavedSubscription(
        id: j['id'] as String,
        name: j['name'] as String,
        url: j['url'] as String,
        updated: j['updated'] as int,
        upload: j['upload'] as int?,
        download: j['download'] as int?,
        total: j['total'] as int?,
        expiry: j['expiry'] as int?,
        rejected: j['rejected'] as int? ?? 0,
      );
}

class Catalog {
  const Catalog({
    this.profiles = const [],
    this.subscriptions = const [],
    this.selected,
  });
  final List<SavedProfile> profiles;
  final List<SavedSubscription> subscriptions;
  final String? selected;
  SavedProfile? get selectedProfile {
    for (final p in profiles) {
      if (p.key == selected) return p;
    }
    return null;
  }

  Map<String, Object?> toJson() => {
    'version': 1,
    'profiles': profiles
        .where((e) => !e.isBuiltIn)
        .map((e) => e.toJson())
        .toList(),
    'subscriptions': subscriptions.map((e) => e.toJson()).toList(),
    'selected': selected,
  };
  factory Catalog.fromJson(Map<String, dynamic> j) {
    if (j['version'] != 1) {
      throw const FormatException('Unsupported vault version');
    }
    return Catalog(
      profiles: List.unmodifiable(
        (j['profiles'] as List).map(
          (e) => SavedProfile.fromJson(Map<String, dynamic>.from(e as Map)),
        ),
      ),
      subscriptions: List.unmodifiable(
        (j['subscriptions'] as List).map(
          (e) =>
              SavedSubscription.fromJson(Map<String, dynamic>.from(e as Map)),
        ),
      ),
      selected: j['selected'] as String?,
    );
  }
}
