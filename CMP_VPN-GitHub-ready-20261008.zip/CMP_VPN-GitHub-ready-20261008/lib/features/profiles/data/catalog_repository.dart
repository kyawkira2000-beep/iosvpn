import 'dart:convert';
import 'package:flutter/services.dart';
import '../../../core/domain/app_failure.dart';
import '../domain/catalog.dart';
import '../domain/bundled_profile.dart';

abstract interface class VaultStorage {
  Future<String?> read();
  Future<void> write(String content, String? expected);
}

class NativeVaultStorage implements VaultStorage {
  const NativeVaultStorage({this.testing = false});
  final bool testing;
  static const channel = MethodChannel('dev.aerolink/vault');
  @override
  Future<String?> read() =>
      channel.invokeMethod<String>('read', {'testing': testing});
  @override
  Future<void> write(String content, String? expected) =>
      channel.invokeMethod<void>('write', {
        'content': content,
        'expected': expected ?? '',
        'testing': testing,
      });
}

class CatalogRepository {
  CatalogRepository(this.storage, {this.defaultProfile});
  final VaultStorage storage;
  final SavedProfile? defaultProfile;
  String? _previous;
  bool _loaded = false;
  Future<Catalog> load() async {
    try {
      final raw = await storage.read();
      if (raw != null && utf8.encode(raw).length > 4 * 1024 * 1024) {
        throw const FormatException();
      }
      final decoded = raw == null || raw.isEmpty
          ? null
          : jsonDecode(raw) as Map<String, dynamic>;
      final catalog = decoded == null
          ? const Catalog()
          : Catalog.fromJson(decoded);
      _previous = raw;
      _loaded = true;
      final initialized = decoded?['defaultInitialized'] == true;
      final merged = withDefault(catalog, selectDefault: !initialized);
      if (defaultProfile != null && !initialized) await save(merged);
      return merged;
    } catch (_) {
      throw const AppFailure(
        'Secure storage could not be opened. Your existing data was not overwritten. Retry under the same OS account.',
      );
    }
  }

  Catalog withDefault(Catalog catalog, {bool selectDefault = false}) {
    final bundled = defaultProfile;
    if (bundled == null) return catalog;
    final profiles = [
      bundled,
      ...catalog.profiles.where(
        (p) => !p.isBuiltIn && !sameCredentials(p.profile, bundled.profile),
      ),
    ];
    return Catalog(
      profiles: List.unmodifiable(profiles),
      subscriptions: catalog.subscriptions,
      selected: selectDefault || !profiles.any((p) => p.key == catalog.selected)
          ? bundled.key
          : catalog.selected,
    );
  }

  Future<void> save(Catalog catalog) async {
    if (!_loaded) throw const AppFailure('Secure storage is not ready.');
    if (catalog.profiles.where((p) => !p.isBuiltIn).length > 1000 ||
        catalog.subscriptions.length > 20) {
      throw const AppFailure(
        'Limit reached: 1,000 profiles or 20 subscriptions.',
      );
    }
    final raw = jsonEncode({
      ...withDefault(catalog).toJson(),
      if (defaultProfile != null) 'defaultInitialized': true,
    });
    if (utf8.encode(raw).length > 4 * 1024 * 1024) {
      throw const AppFailure('Encrypted profile library exceeds 4 MB.');
    }
    try {
      await storage.write(raw, _previous);
      _previous = raw;
    } on PlatformException catch (e) {
      if (e.code == 'conflict') {
        throw const AppFailure(
          'Another app instance changed the library. Close and reopen CMP VPN before trying again.',
        );
      }
      throw const AppFailure(
        'Could not save to secure storage. No changes were applied.',
      );
    } catch (_) {
      throw const AppFailure(
        'Could not save to secure storage. No changes were applied.',
      );
    }
  }
}
