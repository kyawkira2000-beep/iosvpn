import 'dart:isolate';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:zxing2/qrcode.dart';
import '../../../core/domain/app_failure.dart';

Future<String> decodeQr(Uint8List bytes) =>
    Isolate.run(() => decodeQrBytes(bytes));
String decodeQrBytes(Uint8List bytes) {
  if (bytes.length > 8 * 1024 * 1024) {
    throw const AppFailure('QR image exceeds 8 MB.');
  }
  try {
    final img.Decoder decoder;
    if (img.PngDecoder().isValidFile(bytes)) {
      decoder = img.PngDecoder();
    } else if (img.JpegDecoder().isValidFile(bytes)) {
      decoder = img.JpegDecoder();
    } else {
      throw const AppFailure('Choose a PNG or JPEG QR image.');
    }
    final info = decoder.startDecode(bytes);
    if (info == null ||
        info.width <= 0 ||
        info.height <= 0 ||
        info.width > 4096 ||
        info.height > 4096 ||
        info.width * info.height > 12000000) {
      throw const AppFailure(
        'Image dimensions are invalid or exceed 12 megapixels / 4096 pixels per side.',
      );
    }
    var image = decoder.decodeFrame(0);
    if (image == null) {
      throw const AppFailure('The QR image could not be read.');
    }
    image = img.bakeOrientation(image);
    if (image.width > 1800 || image.height > 1800) {
      image = img.copyResize(
        image,
        width: image.width >= image.height ? 1800 : null,
        height: image.height > image.width ? 1800 : null,
      );
    }
    for (var turn = 0; turn < 4; turn++) {
      final pixels = Int32List(image!.width * image.height);
      for (final p in image) {
        pixels[p.y * image.width + p.x] =
            0xff000000 | (p.r.toInt() << 16) | (p.g.toInt() << 8) | p.b.toInt();
      }
      final source = RGBLuminanceSource(image.width, image.height, pixels);
      for (final inverted in [false, true]) {
        try {
          final result = QRCodeReader().decode(
            BinaryBitmap(HybridBinarizer(inverted ? source.invert() : source)),
          );
          if (result.text.length > 16384) {
            throw const AppFailure('QR content exceeds 16 KB.');
          }
          return result.text.trim();
        } on AppFailure {
          rethrow;
        } catch (_) {
          /* Try the next orientation. */
        }
      }
      image = img.copyRotate(image, angle: 90);
    }
    throw const AppFailure(
      'No readable QR code found. Try a clear, uncropped image.',
    );
  } on AppFailure {
    rethrow;
  } catch (_) {
    throw const AppFailure('The QR image is invalid or unreadable.');
  }
}
