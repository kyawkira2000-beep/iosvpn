enum ConnectionStatus {
  disconnected('မချိတ်ဆက်ရသေး'),
  connecting('ချိတ်ဆက်နေသည်'),
  connected('ချိတ်ဆက်ထားသည်'),
  reconnecting('ပြန်ချိတ်နေသည်'),
  failed('ချိတ်ဆက်မှု မအောင်မြင်ပါ');

  const ConnectionStatus(this.label);
  final String label;
}
