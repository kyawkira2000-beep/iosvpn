import 'dart:convert';
import 'dart:io';
import '../../../core/domain/app_failure.dart';
import '../../profiles/domain/vless_profile.dart';

/// Maps allowlisted fields to the pinned Windows and Android Xray runtimes.
String buildXrayConfig(
  VlessProfile profile,
  int httpPort,
  int socksPort, {
  Map<String, String>? tun,
  bool android = false,
  bool ios = false,
  int? gatewayPort,
}) {
  if (ios && (android || tun != null || profile.managed)) {
    throw const AppFailure(
      'iOS requires a direct VLESS profile and its own packet tunnel.',
    );
  }
  if (profile.managed &&
      !android &&
      (gatewayPort == null || gatewayPort < 1024 || gatewayPort > 65535)) {
    throw const AppFailure(
      'Managed access requires an authenticated device transport.',
    );
  }
  if (android && tun != null) {
    throw const AppFailure('Android VPN cannot use a Windows network plan.');
  }
  if (tun != null &&
      (InternetAddress.tryParse(tun['address'] ?? '') == null ||
          (tun['interface'] ?? '').trim().isEmpty ||
          !RegExp(
            r'^CMP VPN-[a-fA-F0-9]{8}-[a-fA-F0-9]{4}$',
          ).hasMatch(tun['name'] ?? ''))) {
    throw const AppFailure('The native TUN network plan is incomplete.');
  }
  if ((!profile.managed && profile.security != 'reality') ||
      !['tcp', 'raw'].contains(profile.transport)) {
    throw const AppFailure(
      'This runtime currently connects VLESS REALITY over TCP/RAW. Other transports remain import-only.',
    );
  }
  const supported = {
    'dms',
    'type',
    'encryption',
    'security',
    'sni',
    'fp',
    'flow',
    'pbk',
    'sid',
    'spx',
    'allowInsecure',
    'insecure',
  };
  if (profile.parameters.entries.any(
    (e) => !supported.contains(e.key) && e.value.any((v) => v.isNotEmpty),
  )) {
    throw const AppFailure(
      'This profile contains parameters the installed runtime adapter does not support. They have not been discarded.',
    );
  }
  if (httpPort < 1024 ||
      httpPort > 65535 ||
      socksPort < 1024 ||
      socksPort > 65535 ||
      httpPort == socksPort) {
    throw const AppFailure('Could not allocate local proxy ports.');
  }
  return jsonEncode({
    if (profile.managed && android)
      'dmsGateway': {
        'host': profile.host,
        'port': profile.port,
        'serverName': profile.value('sni', profile.host),
        'uuid': profile.uuid,
      },
    'log': {'loglevel': 'none', 'access': 'none', 'error': 'none'},
    'inbounds': [
      if (android || ios)
        {
          'tag': 'tun-in',
          'protocol': 'tun',
          'settings': {'name': 'dms-vpn', 'MTU': 1400},
        },
      if (tun != null)
        {
          'tag': 'tun-in',
          'protocol': 'tun',
          'port': 0,
          'settings': {'name': tun['name'], 'MTU': 1400},
        },
      if (!android && !ios)
        {
          'tag': 'http-in',
          'listen': '127.0.0.1',
          'port': httpPort,
          'protocol': 'http',
          'settings': {},
        },
      if (!android && !ios)
        {
          'tag': 'socks-in',
          'listen': '127.0.0.1',
          'port': socksPort,
          'protocol': 'socks',
          'settings': {'auth': 'noauth', 'udp': tun != null},
        },
    ],
    // The only outbound is the selected VLESS server; no direct fallback.
    'outbounds': [
      {
        'tag': 'proxy',
        'protocol': 'vless',
        'settings': {
          'vnext': [
            {
              'address': profile.managed
                  ? '127.0.0.1'
                  : tun?['address'] ?? profile.host,
              'port': profile.managed ? (gatewayPort ?? 0) : profile.port,
              'users': [
                {
                  'id': profile.uuid,
                  'encryption': 'none',
                  if (profile.value('flow').isNotEmpty)
                    'flow': profile.value('flow'),
                },
              ],
            },
          ],
        },
        'streamSettings': {
          if (tun != null && !profile.managed)
            'sockopt': {'interface': tun['interface']},
          'network': 'raw',
          'security': profile.managed ? 'none' : 'reality',
          if (!profile.managed)
            'realitySettings': {
              'show': false,
              'serverName': profile.value('sni'),
              'fingerprint': profile.value('fp'),
              'password': profile.value('pbk').replaceAll('=', ''),
              'shortId': profile.value('sid'),
              'spiderX': profile.value('spx', '/'),
            },
        },
      },
    ],
  });
}
