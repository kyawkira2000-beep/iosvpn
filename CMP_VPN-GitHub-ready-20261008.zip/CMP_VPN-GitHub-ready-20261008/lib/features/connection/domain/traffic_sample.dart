class TrafficSample {
  const TrafficSample(
    this.upload,
    this.download,
    this.tick, {
    this.uploadRate,
    this.downloadRate,
  });
  final int upload, download, tick;
  final double? uploadRate, downloadRate;

  static TrafficSample? parse(List<String> parts, TrafficSample? previous) {
    if (parts.length != 6) return null;
    final up = int.tryParse(parts[3]);
    final down = int.tryParse(parts[4]);
    final tick = int.tryParse(parts[5]);
    if (up == null ||
        down == null ||
        tick == null ||
        up < 0 ||
        down < 0 ||
        tick < 0) {
      return null;
    }
    if (previous != null &&
        tick == previous.tick &&
        up == previous.upload &&
        down == previous.download) {
      return previous;
    }
    final valid =
        previous != null &&
        tick > previous.tick &&
        up >= previous.upload &&
        down >= previous.download;
    return TrafficSample(
      up,
      down,
      tick,
      uploadRate: valid
          ? (up - previous.upload) * 1000 / (tick - previous.tick)
          : null,
      downloadRate: valid
          ? (down - previous.download) * 1000 / (tick - previous.tick)
          : null,
    );
  }
}

String formatBytes(num? value) {
  if (value == null) return '—';
  var size = value.toDouble();
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  var unit = 0;
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024;
    unit++;
  }
  return '${size.toStringAsFixed(unit == 0 ? 0 : 1)} ${units[unit]}';
}
