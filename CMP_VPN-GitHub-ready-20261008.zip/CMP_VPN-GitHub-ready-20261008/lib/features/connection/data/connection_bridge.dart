import 'package:flutter/services.dart';
import 'dart:convert';

abstract interface class ConnectionBridge {
  Future<String> status();
  Future<void> start(String config, int httpPort, int socksPort, String probe);
  Future<void> stop();
}

class NativeConnectionBridge implements ConnectionBridge {
  static const channel = MethodChannel('dev.aerolink/connection');
  void setTrayHandler(Future<void> Function()? handler) {
    channel.setMethodCallHandler(
      handler == null
          ? null
          : (call) async {
              if (call.method == 'trayToggle') await handler();
            },
    );
  }

  @override
  Future<String> status() async =>
      await channel.invokeMethod<String>('status') ??
      'disconnected|Ready to connect.|0';
  @override
  Future<void> start(
    String config,
    int httpPort,
    int socksPort,
    String probe,
  ) => channel.invokeMethod<void>('start', {
    'config': config,
    'httpPort': httpPort,
    'socksPort': socksPort,
    'probe': probe,
    'tunName':
        ((jsonDecode(config) as Map)['inbounds'] as List)
            .where((i) => i['protocol'] == 'tun')
            .map((i) => i['settings']['name'] as String)
            .firstOrNull ??
        '',
  });
  @override
  Future<void> stop() => channel.invokeMethod<void>('stop');
}

class TunPlatform {
  Future<Map<String, String>> prepare(String host) async {
    final result = await NativeConnectionBridge.channel
        .invokeMapMethod<String, String>('prepareTun', host);
    if (result == null) throw StateError('Tunnel preparation failed.');
    return result;
  }

  Future<void> elevate() =>
      NativeConnectionBridge.channel.invokeMethod<void>('elevate');
}
