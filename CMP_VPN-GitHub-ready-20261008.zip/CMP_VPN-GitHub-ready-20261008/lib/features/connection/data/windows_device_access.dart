import 'dart:async';
import 'dart:convert';
import 'dart:io';
import '../../profiles/domain/vless_profile.dart';

class WindowsDeviceAccess {
  static String get executable =>
      '${File(Platform.resolvedExecutable).parent.path}${Platform.pathSeparator}CMP VPN_access.exe';
  static Map<String, Object> endpoint(
    VlessProfile profile,
    Map<String, String>? tun,
  ) => {
    'host': profile.host,
    'port': profile.port,
    'serverName': profile.value('sni', profile.host),
    'uuid': profile.uuid,
    if (tun != null) ...{
      'address': tun['address']!,
      'interface': tun['interface']!,
    },
  };

  static Future<String> request(Map<String, Object?> command) async {
    final process = await Process.start(executable, [], runInShell: false);
    final output = process.stdout.transform(utf8.decoder).join();
    final errors = process.stderr.drain<void>();
    try {
      process.stdin.writeln(jsonEncode(command));
      await process.stdin.close();
      final code = await process.exitCode.timeout(const Duration(seconds: 25));
      final result = await output;
      await errors;
      if (code != 0 || result.length > 32768) {
        throw const FormatException('Device access failed');
      }
      return result;
    } finally {
      process.kill();
    }
  }

  Process? _process;
  int _generation = 0;
  Future<int> start(VlessProfile profile, Map<String, String>? tun) async {
    await stop();
    final generation = ++_generation;
    final process = await Process.start(executable, [], runInShell: false);
    if (generation != _generation) {
      process.kill();
      throw const FormatException('Connection cancelled');
    }
    _process = process;
    unawaited(process.stderr.drain<void>());
    final ready = Completer<int>();
    process.stdout
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .listen(
          (line) {
            if (ready.isCompleted) return;
            try {
              final value = jsonDecode(line) as Map;
              final port = value['port'];
              if (port is! int || port < 1024 || port > 65535) {
                throw const FormatException();
              }
              ready.complete(port);
            } catch (_) {
              ready.completeError(
                const FormatException('Device transport failed'),
              );
            }
          },
          onError: (Object error) {
            if (!ready.isCompleted) ready.completeError(error);
          },
          onDone: () {
            if (!ready.isCompleted) {
              ready.completeError(
                const FormatException('Device transport ended'),
              );
            }
          },
        );
    process.stdin.writeln(
      jsonEncode({'action': 'relay', 'endpoint': endpoint(profile, tun)}),
    );
    try {
      return await ready.future.timeout(const Duration(seconds: 25));
    } catch (_) {
      await stop();
      rethrow;
    }
  }

  Future<void> stop() async {
    _generation++;
    final process = _process;
    _process = null;
    if (process == null) return;
    try {
      await process.stdin.close();
      await process.exitCode.timeout(const Duration(seconds: 2));
    } catch (_) {
      process.kill();
    }
  }
}
