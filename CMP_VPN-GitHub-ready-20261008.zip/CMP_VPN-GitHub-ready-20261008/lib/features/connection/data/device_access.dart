import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../profiles/domain/vless_profile.dart';
import 'windows_device_access.dart';

class DeviceAccessTransport {
  static const channel = MethodChannel('dev.dmsvpn/device_access');
  Future<Map<String, dynamic>> request(
    VlessProfile profile,
    String action, {
    String? version,
  }) async {
    final Map<String, Object?> command = {
      'endpoint': {
        'host': profile.host,
        'port': profile.port,
        'serverName': profile.value('sni', profile.host),
        'uuid': profile.uuid,
      },
      'action': action,
      if (version != null) ...{'version': version, 'acknowledged': true},
    };
    final raw = Platform.isWindows
        ? await WindowsDeviceAccess.request(command)
        : await channel.invokeMethod<String>('request', command);
    if (raw == null || raw.length > 32768) throw const FormatException();
    return jsonDecode(raw) as Map<String, dynamic>;
  }
}

class DeviceAccessView {
  const DeviceAccessView({
    this.profileId,
    this.status = 'idle',
    this.notice,
    this.fingerprint,
  });
  final String? fingerprint;
  final String? profileId;
  final String status;
  final Map<String, dynamic>? notice;
  bool get busy => status == 'checking';
  String get message => switch (status) {
    'approved' => 'Device approved',
    'pending' || 'unassigned' => 'Waiting for administrator approval',
    'rejected' => 'Device request rejected. Contact your administrator.',
    'revoked' => 'Device access revoked. Contact your administrator.',
    'suspended' => 'Your account is suspended. Contact your administrator.',
    'notice_required' => 'Read the VPN traffic notice before connecting.',
    'checking' => 'Checking device access…',
    'idle' => 'Administrator approval required',
    _ =>
      'Cannot securely reach the approval server. Check the address, certificate and network.',
  };
}

final deviceAccessTransportProvider = Provider<DeviceAccessTransport>(
  (ref) => DeviceAccessTransport(),
);
final deviceAccessProvider =
    NotifierProvider<DeviceAccessController, DeviceAccessView>(
      DeviceAccessController.new,
    );

class DeviceAccessController extends Notifier<DeviceAccessView> {
  int _generation = 0;
  @override
  DeviceAccessView build() => const DeviceAccessView();
  Future<bool> check(VlessProfile profile) async {
    if (!profile.managed) return false;
    final generation = ++_generation;
    state = DeviceAccessView(profileId: profile.id, status: 'checking');
    try {
      final transport = ref.read(deviceAccessTransportProvider);
      final identity = await transport.request(profile, 'identity');
      final fingerprint = identity['fingerprint'];
      if (fingerprint is! String ||
          !RegExp(r'^[0-9a-f]{64}$').hasMatch(fingerprint)) {
        throw const FormatException();
      }
      var response = await transport.request(profile, 'enroll');
      if (response['status'] == 'approved') {
        response = await transport.request(profile, 'status');
      }
      final status = response['status'];
      if (status is! String ||
          !{
            'approved',
            'pending',
            'rejected',
            'revoked',
            'unassigned',
            'suspended',
            'notice_required',
          }.contains(status)) {
        throw const FormatException();
      }
      Map<String, dynamic>? notice;
      if (status == 'notice_required') {
        notice = await transport.request(profile, 'notice');
        if (notice['enabled'] != true ||
            notice['version'] is! String ||
            (notice['version'] as String).isEmpty ||
            notice['textEn'] is! String ||
            notice['textMy'] is! String ||
            notice['retentionDays'] is! int) {
          throw const FormatException();
        }
      }
      if (!ref.mounted || generation != _generation) return false;
      state = DeviceAccessView(
        profileId: profile.id,
        status: status,
        notice: notice,
        fingerprint: fingerprint,
      );
      return status == 'approved';
    } catch (_) {
      if (ref.mounted && generation == _generation) {
        state = DeviceAccessView(profileId: profile.id, status: 'error');
      }
      return false;
    }
  }

  Future<void> acknowledge(VlessProfile profile, String version) async {
    if (state.busy ||
        state.profileId != profile.id ||
        state.status != 'notice_required' ||
        state.notice?['version'] != version) {
      return;
    }
    final generation = ++_generation;
    state = DeviceAccessView(profileId: profile.id, status: 'checking');
    try {
      final response = await ref
          .read(deviceAccessTransportProvider)
          .request(profile, 'acknowledge', version: version);
      if (response['status'] != 'acknowledged') throw const FormatException();
      if (ref.mounted && generation == _generation) await check(profile);
    } catch (_) {
      if (ref.mounted && generation == _generation) {
        state = DeviceAccessView(profileId: profile.id, status: 'error');
      }
    }
  }
}
