import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/domain/app_failure.dart';
import '../../profiles/presentation/catalog_controller.dart';
import '../data/connection_bridge.dart';
import '../data/device_access.dart';
import '../data/windows_device_access.dart';
import '../domain/connection_status.dart';
import '../domain/xray_config.dart';
import '../domain/traffic_sample.dart';

class ConnectionView {
  const ConnectionView({
    this.status = ConnectionStatus.disconnected,
    this.message = 'Ready to connect.',
    this.available = false,
    this.latency,
    this.since,
    this.activeName,
    this.stopping = false,
    this.traffic,
    this.events = const [],
  });
  final ConnectionStatus status;
  final String message;
  final bool available, stopping;
  final int? latency;
  final DateTime? since;
  final String? activeName;
  final List<String> events;
  final TrafficSample? traffic;
  bool get active =>
      status == ConnectionStatus.connecting ||
      status == ConnectionStatus.connected ||
      status == ConnectionStatus.reconnecting ||
      stopping;
}

final connectionBridgeProvider = Provider<ConnectionBridge>(
  (ref) => NativeConnectionBridge(),
);
final nativePlatformProvider = Provider<TargetPlatform>(
  (ref) => defaultTargetPlatform,
);
final connectionProvider =
    NotifierProvider<ConnectionController, ConnectionView>(
      ConnectionController.new,
    );
final probeUrlProvider = NotifierProvider<ProbeUrl, String>(ProbeUrl.new);
final tunPlatformProvider = Provider<TunPlatform>((ref) => TunPlatform());
final tunModeProvider = NotifierProvider<TunMode, bool>(TunMode.new);
final autoReconnectProvider = NotifierProvider<AutoReconnect, bool>(
  AutoReconnect.new,
);
// A provider makes backoff deterministic in tests without changing production policy.
final reconnectDelaysProvider = Provider<List<Duration>>(
  (ref) => const [
    Duration(seconds: 2),
    Duration(seconds: 4),
    Duration(seconds: 8),
    Duration(seconds: 16),
    Duration(seconds: 30),
  ],
);

class AutoReconnect extends Notifier<bool> {
  @override
  bool build() =>
      ref.read(nativePlatformProvider) == TargetPlatform.windows ||
      ref.read(nativePlatformProvider) == TargetPlatform.android;
  void set(bool value) {
    state = value;
    final controller = ref.read(connectionProvider.notifier);
    if (value) {
      controller.enableReconnect();
    } else {
      controller.cancelReconnect();
    }
  }
}

class TunMode extends Notifier<bool> {
  @override
  bool build() => true;
  void set(bool value) {
    if (!ref.read(connectionProvider).active) state = value;
  }
}

class ProbeUrl extends Notifier<String> {
  @override
  String build() => 'https://cp.cloudflare.com/generate_204';
  void set(String value) {
    final uri = Uri.tryParse(value.trim());
    if (uri == null ||
        uri.scheme != 'https' ||
        uri.host.isEmpty ||
        uri.userInfo.isNotEmpty ||
        uri.hasFragment ||
        value.length > 2048) {
      throw const AppFailure(
        'Use an HTTPS endpoint without credentials or fragment that returns HTTP 204.',
      );
    }
    state = uri.toString();
  }
}

class ConnectionController extends Notifier<ConnectionView> {
  final _deviceTransport = WindowsDeviceAccess();
  Timer? _timer;
  Timer? _retryTimer;
  bool _keepAlive = false, _verified = false;
  DateTime? _connectedSince;
  int _attempt = 0, _generation = 0;
  String? _sessionKey, _sessionLink;
  bool _disposed = false, _polling = false, _command = false;
  String? _lastNative;
  @override
  ConnectionView build() {
    _disposed = false;
    final bridge = ref.read(connectionBridgeProvider);
    ref.onDispose(() {
      _disposed = true;
      _timer?.cancel();
      _retryTimer?.cancel();
      _generation++;
      unawaited(_deviceTransport.stop());
      if (bridge is NativeConnectionBridge) bridge.setTrayHandler(null);
    });
    if (bridge is NativeConnectionBridge) {
      bridge.setTrayHandler(() => state.active ? disconnect() : connect());
    }
    ref.listen(catalogProvider, (_, next) {
      final saved = next.asData?.value.selectedProfile;
      if (next.hasValue &&
          _sessionKey != null &&
          (saved?.key != _sessionKey || saved?.profile.link != _sessionLink)) {
        cancelReconnect();
      }
    });
    Future.microtask(poll);
    return const ConnectionView();
  }

  List<String> _events(String message) => List.unmodifiable(
    [
      ...state.events,
      '${DateTime.now().toLocal().toString().split('.').first}  $message',
    ].reversed.take(100).toList().reversed,
  );

  void cancelReconnect() {
    _keepAlive = false;
    _retryTimer?.cancel();
    _retryTimer = null;
    if (state.status == ConnectionStatus.reconnecting) {
      state = ConnectionView(
        status: ConnectionStatus.disconnected,
        available: state.available,
        message: 'Automatic reconnection cancelled.',
        events: _events('Automatic reconnection cancelled.'),
      );
    }
  }

  void enableReconnect() {
    final saved = ref.read(catalogProvider).asData?.value.selectedProfile;
    if (state.status == ConnectionStatus.connected &&
        saved?.key == _sessionKey &&
        saved?.profile.link == _sessionLink) {
      _keepAlive = true;
      _verified = true;
    }
  }

  bool _transient(String message) =>
      message.startsWith('Xray stopped unexpectedly.') ||
      message.startsWith('HTTPS through the selected server') ||
      message.startsWith('No physical route') ||
      message.startsWith('Cannot resolve') ||
      message.startsWith('The TUN adapter stopped.') ||
      message.startsWith('Android VPN routing could not be verified.') ||
      message.startsWith('Android HTTPS through the VPN failed.');

  void _scheduleRetry(String failure) {
    final platform = ref.read(nativePlatformProvider);
    if (platform != TargetPlatform.windows &&
        platform != TargetPlatform.android &&
        platform != TargetPlatform.iOS) {
      return;
    }
    if (!_transient(failure)) {
      _keepAlive = false;
      return;
    }
    if (!_keepAlive ||
        !_verified ||
        !ref.read(autoReconnectProvider) ||
        _retryTimer != null) {
      return;
    }
    final saved = ref.read(catalogProvider).asData?.value.selectedProfile;
    if (saved?.key != _sessionKey || saved?.profile.link != _sessionLink) {
      cancelReconnect();
      return;
    }
    final delays = ref.read(reconnectDelaysProvider);
    if (_attempt >= delays.length) {
      _keepAlive = false;
      return;
    }
    final delay = delays[_attempt++];
    final message =
        'Connection lost. Retry $_attempt/${delays.length} in ${delay.inSeconds}s. Normal networking may resume while disconnected.';
    state = ConnectionView(
      status: ConnectionStatus.reconnecting,
      available: true,
      activeName: saved!.displayName,
      message: message,
      events: _events(message),
    );
    _retryTimer = Timer(delay, () {
      _retryTimer = null;
      if (!_disposed && _keepAlive) connect(automatic: true);
    });
  }

  Future<void> poll() async {
    if (_disposed || _polling || _command) return;
    final platform = ref.read(nativePlatformProvider);
    if (platform != TargetPlatform.windows &&
        platform != TargetPlatform.android &&
        platform != TargetPlatform.iOS) {
      return;
    }
    _polling = true;
    final generation = _generation;
    try {
      final raw = await ref.read(connectionBridgeProvider).status();
      if (_disposed || generation != _generation) return;
      final parts = raw.split('|');
      if (parts.length != 3 && parts.length != 6) return;
      _timer ??= Timer.periodic(const Duration(seconds: 1), (_) => poll());
      final phase = switch (parts[0]) {
        'connecting' => ConnectionStatus.connecting,
        'connected' => ConnectionStatus.connected,
        'failed' => ConnectionStatus.failed,
        _ => ConnectionStatus.disconnected,
      };
      final changed = raw != _lastNative;
      if (!_command &&
          (phase == ConnectionStatus.failed ||
              phase == ConnectionStatus.disconnected)) {
        await _deviceTransport.stop();
      }
      final event = parts[1] != state.message || phase != state.status;
      _lastNative = raw;
      if (_retryTimer != null && phase == ConnectionStatus.failed) return;
      if (phase == ConnectionStatus.connected && _keepAlive) {
        _verified = true;
        _connectedSince ??= DateTime.now();
        if (DateTime.now().difference(_connectedSince!).inSeconds >= 60) {
          _attempt = 0;
          _connectedSince = DateTime.now();
        }
      } else if (phase != ConnectionStatus.connected) {
        _connectedSince = null;
      }
      if (changed || !state.available || phase == ConnectionStatus.connected) {
        state = ConnectionView(
          status: phase,
          message: parts[1],
          available: true,
          latency: phase == ConnectionStatus.connected
              ? int.tryParse(parts[2])
              : null,
          since: phase == ConnectionStatus.connected
              ? (state.since ?? DateTime.now())
              : null,
          activeName:
              (phase == ConnectionStatus.connected ||
                  phase == ConnectionStatus.connecting)
              ? state.activeName
              : null,
          stopping:
              state.stopping &&
              (phase == ConnectionStatus.connecting ||
                  phase == ConnectionStatus.connected),
          events: event ? _events(parts[1]) : state.events,
          traffic: phase == ConnectionStatus.connected
              ? TrafficSample.parse(parts, state.traffic)
              : null,
        );
      }
      if (phase == ConnectionStatus.failed) _scheduleRetry(parts[1]);
    } on MissingPluginException {
      _timer?.cancel();
      if (!_disposed) {
        state = ConnectionView(
          message: 'Native connection service is unavailable in this build.',
          events: state.events,
        );
      }
    } catch (_) {
      if (!_disposed) {
        state = ConnectionView(
          status: ConnectionStatus.failed,
          message: 'Cannot read native connection state. Reopen CMP VPN.',
          events: state.events,
        );
      }
    } finally {
      _polling = false;
    }
  }

  Future<void> connect({bool automatic = false}) async {
    if (_command ||
        (state.active &&
            !(automatic && state.status == ConnectionStatus.reconnecting)) ||
        !state.available) {
      return;
    }
    if (!automatic) {
      _keepAlive = true;
      _verified = false;
      _attempt = 0;
      _connectedSince = null;
      _retryTimer?.cancel();
      _retryTimer = null;
    }
    final generation = ++_generation;
    _command = true;
    ServerSocket? http, socks;
    try {
      final catalog = ref.read(catalogProvider).asData?.value;
      final saved = catalog?.selectedProfile;
      if (saved == null) throw const AppFailure('Select a saved server first.');
      if (const bool.fromEnvironment('DMS_MANAGED_ONLY') &&
          !saved.profile.managed) {
        throw const AppFailure(
          'Import the managed invitation from your administrator. Ordinary VLESS keys cannot connect in this build.',
        );
      }
      if (automatic &&
          (!_keepAlive ||
              saved.key != _sessionKey ||
              saved.profile.link != _sessionLink)) {
        return;
      }
      _sessionKey = saved.key;
      _sessionLink = saved.profile.link;
      final subscription = catalog!.subscriptions
          .where((s) => s.id == saved.subscriptionId)
          .firstOrNull;
      if (subscription != null &&
          (subscription.expired || subscription.exhausted)) {
        throw const AppFailure(
          'The provider reports this subscription expired or exhausted. Refresh it before connecting.',
        );
      }
      final android =
          ref.read(nativePlatformProvider) == TargetPlatform.android;
      final ios = ref.read(nativePlatformProvider) == TargetPlatform.iOS;
      if (ios && saved.profile.managed) {
        throw const AppFailure(
          'iOS requires a direct VLESS profile and its own packet tunnel.',
        );
      }
      if (saved.profile.managed) {
        final approved = await ref
            .read(deviceAccessProvider.notifier)
            .check(saved.profile);
        if (!approved) throw AppFailure(ref.read(deviceAccessProvider).message);
        if (_disposed || generation != _generation) return;
      }
      if (!android && !ios) {
        http = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
        socks = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
      }
      final tun = !android && !ios && ref.read(tunModeProvider)
          ? await ref.read(tunPlatformProvider).prepare(saved.profile.host)
          : null;
      final gatewayPort = saved.profile.managed && !android && !ios
          ? await _deviceTransport.start(saved.profile, tun)
          : null;
      final config = buildXrayConfig(
        saved.profile,
        http?.port ?? 10808,
        socks?.port ?? 10809,
        tun: tun,
        android: android,
        ios: ios,
        gatewayPort: gatewayPort,
      );
      final h = http?.port ?? 10808, s = socks?.port ?? 10809;
      await http?.close();
      http = null;
      await socks?.close();
      socks = null;
      if (_disposed ||
          generation != _generation ||
          (automatic && !_keepAlive)) {
        await _deviceTransport.stop();
        return;
      }
      await ref
          .read(connectionBridgeProvider)
          .start(config, h, s, ref.read(probeUrlProvider));
      if (!_disposed && generation == _generation) {
        _lastNative = null;
        state = ConnectionView(
          status: ConnectionStatus.connecting,
          message: 'Starting a verified connection…',
          available: true,
          activeName: saved.displayName,
          events: _events('Connection requested.'),
        );
      }
    } catch (e) {
      await _deviceTransport.stop();
      if (!_disposed && generation == _generation) {
        final message = e is AppFailure
            ? e.message
            : e is PlatformException && (e.code == 'tun' || e.code == 'vpn')
            ? e.message ?? 'Could not prepare TUN mode.'
            : 'Could not start the connection. A previous session may still be closing.';
        state = ConnectionView(
          status: ConnectionStatus.failed,
          message: message,
          available: true,
          events: _events(message),
        );
        if (automatic) _scheduleRetry(message);
      }
    } finally {
      await http?.close();
      await socks?.close();
      _command = false;
    }
  }

  Future<void> disconnect() async {
    cancelReconnect();
    _generation++;
    if (state.stopping) return;
    _command = true;
    try {
      await ref.read(connectionBridgeProvider).stop();
      await _deviceTransport.stop();
      if (!_disposed) {
        state = ConnectionView(
          status: state.status,
          message: ref.read(nativePlatformProvider) == TargetPlatform.android
              ? 'Disconnecting Android VPN…'
              : ref.read(nativePlatformProvider) == TargetPlatform.iOS
              ? 'Disconnecting iOS VPN…'
              : 'Disconnecting and restoring Windows network settings…',
          available: true,
          stopping: true,
          activeName: state.activeName,
          events: _events('Disconnect requested.'),
        );
      }
      _lastNative = null;
    } catch (_) {
      if (!_disposed) {
        state = ConnectionView(
          status: ConnectionStatus.failed,
          available: true,
          message:
              'Could not signal disconnect. Close CMP VPN to trigger the supervisor cleanup.',
          events: state.events,
        );
      }
    } finally {
      _command = false;
    }
  }
}
