import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/connection_status.dart';
import 'connection_controller.dart';

final connectionStatusProvider = Provider<ConnectionStatus>(
  (ref) => ref.watch(connectionProvider).status,
);
