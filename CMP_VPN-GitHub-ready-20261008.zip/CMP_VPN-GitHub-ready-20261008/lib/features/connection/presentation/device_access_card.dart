import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/l10n/app_strings.dart';
import '../../../core/presentation/components.dart';
import '../../profiles/domain/vless_profile.dart';
import '../data/device_access.dart';

class DeviceAccessCard extends ConsumerWidget {
  const DeviceAccessCard({
    super.key,
    required this.profile,
    required this.active,
  });
  final VlessProfile profile;
  final bool active;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(deviceAccessProvider);
    final access = current.profileId == profile.id
        ? current
        : const DeviceAccessView();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: SurfacePanel(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Icon(Icons.admin_panel_settings_outlined),
            const SizedBox(height: 8),
            AppText(access.message, textAlign: TextAlign.center),
            if (access.fingerprint != null)
              TextButton(
                child: const AppText('Device identity'),
                onPressed: () => showDialog<void>(
                  context: context,
                  builder: (dialog) => AlertDialog(
                    title: const AppText('Device identity'),
                    content: SelectableText(
                      RegExp('.{1,16}')
                          .allMatches(access.fingerprint!)
                          .map((m) => m.group(0)!)
                          .join('\n'),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(dialog),
                        child: const AppText('Close'),
                      ),
                    ],
                  ),
                ),
              ),
            if (!active)
              TextButton(
                onPressed: access.busy
                    ? null
                    : () async {
                        if (access.notice == null) {
                          await ref
                              .read(deviceAccessProvider.notifier)
                              .check(profile);
                          return;
                        }
                        final notice = access.notice!;
                        final accepted = await showDialog<bool>(
                          context: context,
                          builder: (dialog) => AlertDialog(
                            title: const AppText('VPN traffic notice'),
                            content: SizedBox(
                              width: 460,
                              child: SingleChildScrollView(
                                child: Text(
                                  notice[Localizations.localeOf(
                                                context,
                                              ).languageCode ==
                                              'my'
                                          ? 'textMy'
                                          : 'textEn']
                                      as String,
                                ),
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(dialog, false),
                                child: const AppText('Cancel'),
                              ),
                              FilledButton(
                                onPressed: () => Navigator.pop(dialog, true),
                                child: const AppText('I understand and agree'),
                              ),
                            ],
                          ),
                        );
                        if (accepted == true && context.mounted) {
                          await ref
                              .read(deviceAccessProvider.notifier)
                              .acknowledge(
                                profile,
                                notice['version'] as String,
                              );
                        }
                      },
                child: AppText(
                  access.notice == null ? 'Check access' : 'Read notice',
                ),
              ),
          ],
        ),
      ),
    );
  }
}
