import '../../../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/presentation/components.dart';
import 'connection_controller.dart';
import 'device_access_card.dart';
import '../domain/connection_status.dart';
import '../domain/traffic_sample.dart';
import '../../profiles/presentation/catalog_controller.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key, required this.onServers, required this.onLogs});
  final VoidCallback onServers, onLogs;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final catalog = ref.watch(catalogProvider);
    final selected = catalog.asData?.value.selectedProfile;
    final connection = ref.watch(connectionProvider);
    final live = connection.status == ConnectionStatus.connected;
    final failed = connection.status == ConnectionStatus.failed;
    final accent = live ? const Color(0xFF23845A) : scheme.primary;
    final elapsed = connection.since == null
        ? null
        : DateTime.now().difference(connection.since!);
    final duration = elapsed == null
        ? '00:00'
        : '${elapsed.inHours.toString().padLeft(2, '0')}:${(elapsed.inMinutes % 60).toString().padLeft(2, '0')}:${(elapsed.inSeconds % 60).toString().padLeft(2, '0')}';
    return Column(
      children: [
        SurfacePanel(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: .09),
                  borderRadius: BorderRadius.circular(40),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      live
                          ? Icons.verified_user_rounded
                          : Icons.shield_outlined,
                      size: 16,
                      color: accent,
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: AppText(
                        connection.status.label,
                        key: const Key('connection-status'),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: failed ? scheme.error : scheme.onSurface,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withValues(alpha: .04),
                  border: Border.all(
                    color: accent.withValues(alpha: .20),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withValues(alpha: .12),
                      blurRadius: 36,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: SizedBox(
                  width: 148,
                  height: 148,
                  child: FilledButton(
                    key: const Key('connect-button'),
                    onPressed:
                        !connection.available ||
                            connection.stopping ||
                            (selected == null && !connection.active)
                        ? null
                        : () => connection.active
                              ? ref
                                    .read(connectionProvider.notifier)
                                    .disconnect()
                              : ref.read(connectionProvider.notifier).connect(),
                    style: FilledButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(8),
                      backgroundColor: accent,
                      foregroundColor: live ? Colors.white : scheme.onPrimary,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          connection.active && !live
                              ? Icons.sync_rounded
                              : Icons.power_settings_new_rounded,
                          size: 48,
                        ),
                        const SizedBox(height: 6),
                        Flexible(
                          child: AppText(
                            connection.stopping
                                ? "Please wait"
                                : connection.active
                                ? "Disconnect"
                                : "Connect",
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              if (live) ...[
                const SizedBox(height: 12),
                AppText(
                  duration,
                  style: TextStyle(color: scheme.onSurfaceVariant),
                ),
              ],
              if (!live) ...[
                const SizedBox(height: 16),
                AppText(
                  connection.active
                      ? 'Connecting securely…'
                      : failed
                      ? 'Try again'
                      : selected == null
                      ? 'Choose server'
                      : 'Tap to connect',
                  style: TextStyle(
                    fontSize: 12,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
              const SizedBox(height: 24),
              const Divider(height: 1),
              ListTile(
                key: const Key('selected-server'),
                contentPadding: const EdgeInsets.only(top: 8),
                leading: Icon(
                  selected?.isBuiltIn == true
                      ? Icons.public_rounded
                      : Icons.dns_outlined,
                  color: scheme.primary,
                ),
                title: Text(
                  selected?.isBuiltIn == true
                      ? context.tr('Free server')
                      : connection.activeName ??
                            selected?.displayName ??
                            context.tr('Choose server'),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                subtitle: selected?.isBuiltIn == true
                    ? const AppText('Default', style: TextStyle(fontSize: 12))
                    : null,
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: onServers,
              ),
            ],
          ),
        ),
        if (selected?.profile.managed == true)
          DeviceAccessCard(
            profile: selected!.profile,
            active: connection.active,
          ),
        if (failed || catalog.hasError) ...[
          const SizedBox(height: 12),
          SurfacePanel(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                AppText(
                  catalog.hasError
                      ? "Could not open your server library. Reopen the app."
                      : connection.message,
                  style: TextStyle(color: scheme.error),
                  textAlign: TextAlign.center,
                ),
                TextButton(onPressed: onLogs, child: const AppText("Details")),
              ],
            ),
          ),
        ],
        if (connection.traffic != null) ...[
          const SizedBox(height: 14),
          SurfacePanel(
            padding: const EdgeInsets.all(16),
            child: Wrap(
              spacing: 24,
              runSpacing: 12,
              alignment: WrapAlignment.spaceAround,
              children: [
                _Metric(
                  Icons.south_rounded,
                  'Download',
                  '${formatBytes(connection.traffic!.downloadRate)}/s',
                ),
                _Metric(
                  Icons.north_rounded,
                  'Upload',
                  '${formatBytes(connection.traffic!.uploadRate)}/s',
                ),
                _Metric(
                  Icons.swap_vert,
                  'Total',
                  formatBytes(
                    connection.traffic!.upload + connection.traffic!.download,
                  ),
                ),
              ],
            ),
          ),
        ],
        if (live && connection.latency != null) ...[
          const SizedBox(height: 14),
          SurfacePanel(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Icon(Icons.network_ping_rounded, color: scheme.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const AppText(
                        'Latency',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      AppText(
                        'HTTPS check through VPN',
                        style: TextStyle(
                          fontSize: 11,
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  '${connection.latency} ms',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: scheme.primary,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric(this.icon, this.label, this.value);
  final IconData icon;
  final String label, value;
  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Icon(icon, size: 18, color: Theme.of(context).colorScheme.primary),
      AppText(value, style: const TextStyle(fontWeight: FontWeight.w600)),
      AppText(label, style: const TextStyle(fontSize: 11)),
    ],
  );
}
