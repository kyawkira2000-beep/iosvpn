import 'dart:async';
import 'dart:io';
import '../../../core/domain/app_failure.dart';
import '../domain/subscription_feed.dart';

Uri validateSubscriptionUrl(String text) {
  final uri = Uri.tryParse(text.trim());
  if (text.length > 4096 ||
      uri == null ||
      uri.scheme != 'https' ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty ||
      uri.hasFragment ||
      uri.port < 1 ||
      uri.port > 65535) {
    throw const AppFailure(
      'Use a valid HTTPS subscription URL without user-info or a fragment.',
    );
  }
  return uri;
}

class SubscriptionClient {
  SubscriptionClient({
    HttpClient Function()? clientFactory,
    this.timeout = const Duration(seconds: 25),
  }) : _clientFactory = clientFactory ?? HttpClient.new;
  final HttpClient Function() _clientFactory;
  final Duration timeout;
  Future<SubscriptionFeed> fetch(String url) async {
    final uri = validateSubscriptionUrl(url);
    final client = _clientFactory()
      ..connectionTimeout = const Duration(seconds: 10);
    // Never send a user's subscription credentials through an inherited proxy.
    client.findProxy = (_) => 'DIRECT';
    try {
      return await _fetch(client, uri).timeout(timeout);
    } on AppFailure {
      rethrow;
    } on TimeoutException {
      throw const AppFailure(
        'Subscription request timed out. Existing servers were kept.',
      );
    } on HandshakeException {
      throw const AppFailure(
        'The subscription TLS certificate could not be verified.',
      );
    } catch (_) {
      throw const AppFailure(
        'Could not download the subscription. Check your network and URL.',
      );
    } finally {
      client.close(force: true);
    }
  }

  Future<SubscriptionFeed> _fetch(HttpClient client, Uri original) async {
    var current = original;
    for (var redirect = 0; redirect <= 3; redirect++) {
      final request = await client.getUrl(current);
      request.followRedirects = false;
      request.headers.set(HttpHeaders.userAgentHeader, 'CMP VPN/0.2');
      request.headers.set(HttpHeaders.acceptHeader, 'text/plain');
      final response = await request.close();
      if ([301, 302, 303, 307, 308].contains(response.statusCode)) {
        final location = response.headers.value(HttpHeaders.locationHeader);
        if (location == null || redirect == 3) {
          throw const AppFailure(
            'Subscription redirect limit exceeded or destination missing.',
          );
        }
        final next = validateSubscriptionUrl(
          current.resolve(location).toString(),
        );
        if (next.origin != original.origin) {
          throw const AppFailure(
            'Cross-origin subscription redirects are blocked to protect credentials.',
          );
        }
        await response.listen((_) {}).cancel();
        current = next;
        continue;
      }
      if ([401, 403].contains(response.statusCode)) {
        throw const AppFailure(
          'Subscription access was denied. It may be disabled or expired.',
        );
      }
      if (response.statusCode != 200) {
        throw AppFailure(
          'Subscription server returned HTTP ${response.statusCode}. Existing servers were kept.',
        );
      }
      if (response.contentLength > SubscriptionFeed.maxBytes) {
        throw const AppFailure('Subscription exceeds the 2 MB limit.');
      }
      final bytes = <int>[];
      await for (final chunk in response) {
        if (bytes.length + chunk.length > SubscriptionFeed.maxBytes) {
          throw const AppFailure('Subscription exceeds the 2 MB limit.');
        }
        bytes.addAll(chunk);
      }
      return SubscriptionFeed.parse(
        bytes,
        userInfo: response.headers.value('subscription-userinfo'),
      );
    }
    throw const AppFailure('Too many redirects.');
  }
}
