import '../../../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/domain/app_failure.dart';
import '../../profiles/presentation/catalog_controller.dart';

class SubscriptionDialog extends ConsumerStatefulWidget {
  const SubscriptionDialog({super.key, this.initialUrl = ''});
  final String initialUrl;
  @override
  ConsumerState<SubscriptionDialog> createState() => _SubscriptionDialogState();
}

class _SubscriptionDialogState extends ConsumerState<SubscriptionDialog> {
  final name = TextEditingController();
  late final url = TextEditingController(text: widget.initialUrl);
  bool busy = false, reveal = false;
  String? error;
  @override
  void dispose() {
    name.dispose();
    url.dispose();
    super.dispose();
  }

  Future<void> save() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await ref
          .read(catalogProvider.notifier)
          .addSubscription(name.text, url.text);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) setState(() => error = safeError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !busy,
    child: AlertDialog(
      title: const AppText("Add subscription"),
      content: SizedBox(
        width: 500,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const AppText(
                "Download server profiles from this HTTPS URL. The URL may contain a secret token and will be stored encrypted.",
              ),
              const SizedBox(height: 16),
              TextField(
                key: const Key('subscription-name'),
                controller: name,
                maxLength: 80,
                decoration: InputDecoration(labelText: context.tr("Name")),
              ),
              const SizedBox(height: 12),
              TextField(
                key: const Key('subscription-url'),
                controller: url,
                maxLength: 4096,
                obscureText: !reveal,
                autocorrect: false,
                enableSuggestions: false,
                enableIMEPersonalizedLearning: false,
                decoration: InputDecoration(
                  labelText: context.tr("HTTPS subscription URL"),
                  suffixIcon: IconButton(
                    onPressed: () => setState(() => reveal = !reveal),
                    tooltip: context.tr(reveal ? "Hide URL" : "Reveal URL"),
                    icon: Icon(
                      reveal ? Icons.visibility_off : Icons.visibility,
                    ),
                  ),
                ),
              ),
              if (error != null)
                AppText(
                  error!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: busy ? null : () => Navigator.pop(context),
          child: const AppText("Cancel"),
        ),
        FilledButton(
          onPressed: busy ? null : save,
          child: AppText(busy ? "Downloading…" : "Download and save"),
        ),
      ],
    ),
  );
}
