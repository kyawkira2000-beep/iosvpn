import '../../../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/domain/app_failure.dart';
import '../../../core/presentation/components.dart';
import '../../profiles/presentation/catalog_controller.dart';
import 'subscription_dialog.dart';

class SubscriptionsScreen extends ConsumerWidget {
  const SubscriptionsScreen({super.key});
  String traffic(int? bytes) => bytes == null
      ? "Unknown"
      : '${(bytes / 1073741824).toStringAsFixed(2)} GB';
  Future<void> action(
    BuildContext context,
    Future<void> Function() operation,
  ) async {
    try {
      await operation();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: AppText(safeError(e))));
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(catalogProvider);
    final busy = ref.watch(libraryBusyProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeading(title: "Subscriptions"),
        FilledButton.icon(
          onPressed: busy || !state.hasValue
              ? null
              : () => showDialog<void>(
                  context: context,
                  builder: (_) => const SubscriptionDialog(),
                ),
          icon: const Icon(Icons.add),
          label: const AppText("Add subscription"),
        ),
        const SizedBox(height: 20),
        if (busy) const LinearProgressIndicator(),
        state.when(
          loading: () => const LinearProgressIndicator(),
          error: (e, _) => AppText(safeError(e)),
          data: (catalog) {
            if (catalog.subscriptions.isEmpty) {
              return const EmptyCollection(
                icon: Icons.rss_feed_rounded,
                title: "No subscriptions yet",
                description:
                    "Add an HTTPS subscription URL to import and update its servers.",
                availability:
                    "Usage and expiry are shown only when supplied by the server.",
              );
            }
            return Column(
              children: [
                for (final sub in catalog.subscriptions)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: SurfacePanel(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            sub.name,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '${context.tr('Servers')}: ${catalog.profiles.where((p) => p.subscriptionId == sub.id).length} · ${Uri.parse(sub.url).host}',
                          ),
                          Text(
                            '${context.tr('Updated')} — ${DateTime.fromMillisecondsSinceEpoch(sub.updated).toLocal().toString().split('.').first}',
                          ),
                          const SizedBox(height: 12),
                          Text(
                            '${context.tr('Upload')}: ${context.tr(traffic(sub.upload))} · ${context.tr('Download')}: ${context.tr(traffic(sub.download))}',
                          ),
                          Text(
                            '${context.tr('Allowance')} — ${context.tr(sub.total == 0 ? 'Unlimited (provider reported)' : traffic(sub.total))}',
                          ),
                          Text(
                            '${context.tr('Expires')} — ${sub.expiry == null ? context.tr('Unknown') : DateTime.fromMillisecondsSinceEpoch(sub.expiry! * 1000).toLocal().toString().split('.').first}',
                          ),
                          if (sub.expired || sub.exhausted)
                            AppText(
                              sub.expired
                                  ? "Expired according to provider metadata"
                                  : "Traffic allowance reached",
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.error,
                              ),
                            ),
                          if (sub.rejected > 0)
                            Text(
                              '${context.tr('Unsupported profiles skipped')}: ${sub.rejected}',
                            ),
                          const SizedBox(height: 12),
                          Wrap(
                            spacing: 12,
                            children: [
                              OutlinedButton.icon(
                                onPressed: busy
                                    ? null
                                    : () => action(
                                        context,
                                        () => ref
                                            .read(catalogProvider.notifier)
                                            .refresh(sub.id),
                                      ),
                                icon: const Icon(Icons.refresh),
                                label: const AppText("Update"),
                              ),
                              TextButton(
                                onPressed: busy
                                    ? null
                                    : () => action(context, () async {
                                        final yes = await showDialog<bool>(
                                          context: context,
                                          builder: (ctx) => AlertDialog(
                                            title: const AppText(
                                              "Delete subscription?",
                                            ),
                                            content: const AppText(
                                              "This removes the saved URL and its imported profiles. Your provider account is unchanged.",
                                            ),
                                            actions: [
                                              TextButton(
                                                onPressed: () =>
                                                    Navigator.pop(ctx, false),
                                                child: const AppText("Cancel"),
                                              ),
                                              FilledButton(
                                                onPressed: () =>
                                                    Navigator.pop(ctx, true),
                                                child: const AppText("Delete"),
                                              ),
                                            ],
                                          ),
                                        );
                                        if (yes == true) {
                                          await ref
                                              .read(catalogProvider.notifier)
                                              .removeSubscription(sub.id);
                                        }
                                      }),
                                child: const AppText("Delete"),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}
