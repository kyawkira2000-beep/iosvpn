import 'dart:convert';
import '../../../core/domain/app_failure.dart';
import '../../profiles/domain/vless_profile.dart';

class SubscriptionFeed {
  const SubscriptionFeed(
    this.profiles,
    this.rejected, {
    this.upload,
    this.download,
    this.total,
    this.expiry,
  });
  final List<VlessProfile> profiles;
  final int rejected;
  final int? upload, download, total, expiry;
  static const maxBytes = 2 * 1024 * 1024;
  static SubscriptionFeed parse(List<int> bytes, {String? userInfo}) {
    if (bytes.length > maxBytes) {
      throw const AppFailure('Subscription exceeds the 2 MB limit.');
    }
    try {
      var text = utf8.decode(bytes).trim().replaceFirst('\ufeff', '');
      if (!text.contains('://')) {
        if (text.startsWith('{') || text.startsWith('[')) {
          throw const AppFailure(
            'JSON subscriptions are not supported. Use a standard VLESS link-list subscription.',
          );
        }
        final compact = text.replaceAll(RegExp(r'\s'), '');
        if (!RegExp(r'^[A-Za-z0-9+/=_-]+$').hasMatch(compact)) {
          throw const AppFailure(
            'The subscription is not a VLESS list or base64 link list.',
          );
        }
        final decoded = base64Url.decode(base64Url.normalize(compact));
        if (decoded.length > maxBytes) {
          throw const AppFailure('Decoded subscription exceeds 2 MB.');
        }
        text = utf8.decode(decoded).trim();
      }
      if (text.startsWith('{') || text.startsWith('[')) {
        throw const AppFailure(
          'JSON subscriptions are not supported. Use a standard VLESS link-list subscription.',
        );
      }
      final lines = const LineSplitter()
          .convert(text)
          .where((line) => line.trim().isNotEmpty)
          .toList();
      if (lines.length > 500) {
        throw const AppFailure('Subscription has more than 500 profiles.');
      }
      final unique = <String, VlessProfile>{};
      var rejected = 0;
      for (final line in lines) {
        try {
          final profile = VlessProfile.parse(line);
          unique[profile.id] = profile;
        } on AppFailure {
          rejected++;
        }
      }
      if (unique.isEmpty) {
        throw const AppFailure(
          'No valid VLESS profiles were found. Existing servers were kept.',
        );
      }
      final values = <String, int>{};
      for (final field in (userInfo ?? '').split(';')) {
        final pair = field.trim().split('=');
        if (pair.length == 2) {
          final n = int.tryParse(pair[1].trim());
          if (n != null && n >= 0 && n <= 9007199254740991) {
            values[pair[0].trim()] = n;
          }
        }
      }
      return SubscriptionFeed(
        List.unmodifiable(unique.values),
        rejected,
        upload: values['upload'],
        download: values['download'],
        total: values['total'],
        expiry: (values['expire'] ?? 0) > 0 && values['expire']! <= 253402300799
            ? values['expire']
            : null,
      );
    } on AppFailure {
      rethrow;
    } catch (_) {
      throw const AppFailure(
        'Subscription encoding is invalid. Existing servers were kept.',
      );
    }
  }
}
