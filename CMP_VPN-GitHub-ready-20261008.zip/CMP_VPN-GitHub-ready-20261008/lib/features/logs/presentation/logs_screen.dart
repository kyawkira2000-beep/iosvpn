import '../../../core/l10n/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../connection/presentation/connection_controller.dart';
import '../../../core/presentation/components.dart';

class LogsScreen extends ConsumerWidget {
  const LogsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
    appBar: AppBar(title: const AppText("Connection logs")),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ref.watch(connectionProvider).events.isNotEmpty
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final event in ref.watch(connectionProvider).events)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: AppText(event),
                  ),
              ],
            )
          : const EmptyCollection(
              icon: Icons.receipt_long_outlined,
              title: "No connection events",
              description:
                  "There has not been a VPN session. Connection events will appear here once the service is available.",
              availability: "No network activity has been recorded.",
            ),
    ),
  );
}
