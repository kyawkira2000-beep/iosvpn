import '../../../core/l10n/app_strings.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/presentation/components.dart';
import 'settings_controller.dart';
import '../../../core/presentation/language_switch.dart';
import '../../connection/presentation/connection_controller.dart';
import '../../../core/domain/app_failure.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key, required this.onLogs});
  final VoidCallback onLogs;
  Future<void> editProbe(BuildContext context, WidgetRef ref) async {
    final input = TextEditingController(text: ref.read(probeUrlProvider));
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const AppText('HTTPS စစ်ဆေးမည့် URL'),
        content: TextField(
          controller: input,
          autocorrect: false,
          decoration: InputDecoration(
            labelText: context.tr('HTTPS URL'),
            helperText: context.tr('HTTP 204 ပြန်ပေးသော URL'),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const AppText("Cancel"),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, input.text),
            child: const AppText('သိမ်းမည်'),
          ),
        ],
      ),
    );
    Future<void>.delayed(const Duration(seconds: 1), input.dispose);
    if (value != null && context.mounted) {
      try {
        ref.read(probeUrlProvider.notifier).set(value);
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: AppText(safeError(e))));
        }
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ref.watch(themeModeProvider);
    final windows = defaultTargetPlatform == TargetPlatform.windows;
    final supportsAutoReconnect =
        windows || defaultTargetPlatform == TargetPlatform.android;
    final active = ref.watch(connectionProvider).active;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SectionHeading(title: "Preferences"),
        SurfacePanel(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppText(
                'Language',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              const LanguageSwitch(),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SurfacePanel(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppText(
                "Appearance",
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final choice in [
                    (
                      ThemeMode.system,
                      Icons.brightness_auto_outlined,
                      "System",
                    ),
                    (ThemeMode.light, Icons.light_mode_outlined, "Light"),
                    (ThemeMode.dark, Icons.dark_mode_outlined, "Dark"),
                  ])
                    ChoiceChip(
                      key: Key('theme-${choice.$1.name}'),
                      avatar: Icon(choice.$2, size: 18),
                      label: AppText(choice.$3),
                      selected: theme == choice.$1,
                      onSelected: (_) => ref
                          .read(themeModeProvider.notifier)
                          .select(choice.$1),
                    ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SurfacePanel(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Column(
            children: [
              if (supportsAutoReconnect)
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const AppText('အလိုအလျောက် ပြန်ချိတ်မည်'),
                  subtitle: const AppText(
                    'လိုင်းပြတ်လျှင် ၅ ကြိမ်အထိ ပြန်ကြိုးစားမည်။',
                  ),
                  value: ref.watch(autoReconnectProvider),
                  onChanged: (value) =>
                      ref.read(autoReconnectProvider.notifier).set(value),
                ),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const AppText("Advanced"),
                leading: const Icon(Icons.tune_rounded),
                children: [
                  if (windows) ...[
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const AppText('TUN VPN'),
                      subtitle: const AppText("Use System Proxy when off"),
                      value: ref.watch(tunModeProvider),
                      onChanged: active
                          ? null
                          : (value) =>
                                ref.read(tunModeProvider.notifier).set(value),
                    ),
                    TextButton.icon(
                      icon: const Icon(Icons.admin_panel_settings_outlined),
                      label: const AppText("Restart as administrator"),
                      onPressed: active
                          ? null
                          : () async {
                              try {
                                await ref.read(tunPlatformProvider).elevate();
                              } catch (_) {
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: AppText(
                                        "Could not restart as administrator.",
                                      ),
                                    ),
                                  );
                                }
                              }
                            },
                    ),
                  ],
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const AppText('HTTPS စစ်ဆေးမည့် URL'),
                    trailing: const Icon(Icons.edit_outlined, size: 20),
                    onTap: active ? null : () => editProbe(context, ref),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(bottom: 14),
                    child: AppText(
                      "Normal internet resumes when the VPN stops.",
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.receipt_long_outlined),
                title: const AppText("Connection logs"),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: onLogs,
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SurfacePanel(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: ExpansionTile(
            tilePadding: EdgeInsets.zero,
            leading: const BrandMark(size: 30),
            title: const AppText('CMP VPN'),
            subtitle: const AppText('1.0.0', style: TextStyle(fontSize: 12)),
            children: [
              const AppText(
                "Personal server settings are encrypted on this device.",
                style: TextStyle(fontSize: 12),
              ),
              TextButton(
                onPressed: () => showLicensePage(
                  context: context,
                  applicationName: 'CMP VPN',
                  applicationVersion: '1.0.0',
                ),
                child: const AppText('လိုင်စင်များ'),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
