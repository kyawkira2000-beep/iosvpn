import 'dart:async';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

abstract interface class LanguageStore {
  Future<String?> read();
  Future<void> write(String language);
}

class NativeLanguageStore implements LanguageStore {
  static const channel = MethodChannel('dev.aerolink/preferences');
  @override
  Future<String?> read() => channel.invokeMethod<String>('getLanguage');
  @override
  Future<void> write(String language) =>
      channel.invokeMethod<void>('setLanguage', language);
}

final languageStoreProvider = Provider<LanguageStore>(
  (ref) => NativeLanguageStore(),
);
final languageProvider = NotifierProvider<LanguageController, String>(
  LanguageController.new,
);

class LanguageController extends Notifier<String> {
  int _revision = 0;
  Future<void> _writes = Future.value();
  @override
  String build() {
    unawaited(_load(_revision));
    return 'en';
  }

  Future<void> _load(int revision) async {
    try {
      final saved = await ref.read(languageStoreProvider).read();
      if (ref.mounted &&
          revision == _revision &&
          (saved == 'my' || saved == 'en')) {
        state = saved!;
      }
    } catch (_) {
      /* Keep a usable default if preferences are unavailable. */
    }
  }

  Future<void> select(String language) async {
    if (language != 'my' && language != 'en') {
      throw ArgumentError.value(language);
    }
    _revision++;
    state = language;
    // Serialize writes so quick taps cannot leave an older choice on disk.
    final operation = _writes
        .catchError((Object _) {})
        .then((_) => ref.read(languageStoreProvider).write(language));
    _writes = operation;
    await operation;
  }
}
