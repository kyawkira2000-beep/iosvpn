#!/usr/bin/env python3
"""Fetch the pinned static Apple engine; no system installs or TLS overrides."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def safe_member(name):
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name:
        raise ValueError("Unsafe engine archive path")
    if "LibXray.xcframework" not in path.parts:
        return None
    index = path.parts.index("LibXray.xcframework")
    return Path(*path.parts[index:])

def main():
    manifest = json.loads((ROOT / "native/ios/manifest.json").read_text(encoding="utf-8-sig"))
    cache = ROOT / ".local/ios-engine"
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / (manifest["sha256"] + ".zip")
    if not archive.exists():
        temporary = archive.with_suffix(".download")
        with urllib.request.urlopen(manifest["url"], timeout=120) as response, temporary.open("wb") as output:
            shutil.copyfileobj(response, output)
        temporary.replace(archive)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if digest != manifest["sha256"]:
        raise SystemExit("Engine checksum mismatch. Remove the cached archive and retry.")
    framework_root = ROOT / "ios/Frameworks"
    framework_root.mkdir(exist_ok=True)
    destination = framework_root / "LibXray.xcframework"
    with tempfile.TemporaryDirectory(dir=framework_root) as staging:
        with zipfile.ZipFile(archive) as source:
            total = 0
            for entry in source.infolist():
                relative = safe_member(entry.filename)
                if relative is None or entry.is_dir():
                    continue
                if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError("Engine archive contains a symlink")
                total += entry.file_size
                if total > 1024 * 1024 * 1024:
                    raise ValueError("Engine archive exceeds size limit")
                target = Path(staging) / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.open(entry) as incoming, target.open("wb") as output:
                    shutil.copyfileobj(incoming, output)
        prepared = Path(staging) / "LibXray.xcframework"
        if not (prepared / "Info.plist").is_file():
            raise SystemExit("Expected XCFramework missing from pinned archive")
        if destination.exists():
            expected = {p.relative_to(prepared) for p in prepared.rglob("*") if p.is_file()}
            actual = {p.relative_to(destination) for p in destination.rglob("*") if p.is_file()}
            if expected != actual or any(hashlib.sha256((prepared / p).read_bytes()).digest() != hashlib.sha256((destination / p).read_bytes()).digest() for p in expected):
                raise SystemExit("Existing engine differs. Preserve/remove it manually before rerunning.")
        else:
            prepared.rename(destination)
    print("Pinned LibXray static XCFramework verified:", destination)

if __name__ == "__main__":
    main()
