#!/usr/bin/env bash
set -euo pipefail
[[ "$(uname -s)" == Darwin ]] || { echo 'This build requires macOS and Xcode.' >&2; exit 1; }
cd "$(dirname "$0")/.."
xcodebuild -version
flutter pub get
python3 scripts/get_ios_engine.py
ruby scripts/configure_ios.rb
# An unsigned compile proves linkage only. It cannot be installed on an iPhone.
flutter build ios --release --no-codesign
printf '\nUnsigned build complete. Use Xcode Archive with valid profiles to export an IPA.\n'
