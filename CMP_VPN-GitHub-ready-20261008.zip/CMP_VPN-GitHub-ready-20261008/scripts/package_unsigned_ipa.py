#!/usr/bin/env python3
"""Package an actual Xcode-built application, clearly marked unsigned."""
import hashlib
from pathlib import Path
import plistlib
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MACHO = {bytes.fromhex(value) for value in ('cffaedfe', 'feedfacf', 'cafebabe', 'bebafeca', 'cefaedfe', 'feedface')}

def validate_bundle(bundle):
    with (bundle / 'Info.plist').open('rb') as source:
        info = plistlib.load(source)
    executable = info.get('CFBundleExecutable', '')
    if not executable or Path(executable).name != executable:
        raise ValueError('Missing or unsafe bundle executable')
    with (bundle / executable).open('rb') as source:
        if source.read(4) not in MACHO:
            raise ValueError('Expected a compiled Mach-O executable; refusing to package source files')
    return info

def package(root=ROOT):
    app = root / 'build/ios/iphoneos/Runner.app'
    runner = validate_bundle(app)
    extension = app / 'PlugIns/PacketTunnel.appex'
    tunnel = validate_bundle(extension)
    if tunnel.get('CFBundleIdentifier') != runner.get('CFBundleIdentifier', '') + '.PacketTunnel':
        raise ValueError('Runner and PacketTunnel bundle identifiers do not match')
    if tunnel.get('NSExtension', {}).get('NSExtensionPointIdentifier') != 'com.apple.networkextension.packet-tunnel':
        raise ValueError('Packet Tunnel extension metadata missing')
    destination = root / 'build/ios/export'
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / 'CMP_VPN-UNSIGNED.ipa'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as output:
        for path in sorted(app.rglob('*')):
            relative = Path('Payload/Runner.app') / path.relative_to(app)
            if path.is_symlink():
                raise ValueError('Unexpected symlink in iOS device application')
            if path.is_file():
                output.write(path, relative.as_posix())
    (destination / 'README.txt').write_text(
        'UNSIGNED CMP VPN IPA. This is a compiled build, NOT an installable signed release.\n'
        'Runner and PacketTunnel both require valid Apple signing/provisioning with Network Extension entitlement.\n'
        'Physical-device VPN behavior has not been validated by this cloud build.\n', encoding='utf-8')
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    (destination / 'SHA256SUMS.txt').write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
    print('Created unsigned IPA (requires Apple signing):', archive)
    return archive

if __name__ == '__main__':
    package()
