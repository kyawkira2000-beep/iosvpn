#!/usr/bin/env ruby
# Run on macOS with gem xcodeproj 1.27.0. Repeat-safe; preserves other targets.
require 'xcodeproj'
root = File.expand_path('..', __dir__)
project = Xcodeproj::Project.open(File.join(root, 'ios/Runner.xcodeproj'))
runner = project.targets.find { |target| target.name == 'Runner' } or abort 'Runner target missing'
framework_path = File.join(root, 'ios/Frameworks/LibXray.xcframework')
abort 'Run python3 scripts/get_ios_engine.py first' unless File.directory?(framework_path)
base = ENV.fetch('CMP_BUNDLE_ID', 'dev.cmpvpn.client')
abort 'CMP_BUNDLE_ID must be a reverse DNS identifier' unless base.match?(/\A[a-zA-Z][a-zA-Z0-9-]*(\.[a-zA-Z0-9-]+)+\z/)
team = ENV['CMP_APPLE_TEAM']
extension = project.targets.find { |target| target.name == 'PacketTunnel' } || project.new_target(:app_extension, 'PacketTunnel', :ios, '15.0')
extension.add_build_configuration('Profile', :release) unless extension.build_configurations.any? { |config| config.name == 'Profile' }
group = project.main_group.find_subpath('PacketTunnel', true)
group.set_source_tree('<group>')
group.path = 'PacketTunnel'
source = group.files.find { |file| file.path == 'PacketTunnelProvider.swift' } || group.new_file('PacketTunnelProvider.swift')
extension.source_build_phase.add_file_reference(source, true)
framework_group = project.frameworks_group
framework = framework_group.files.find { |file| file.path == 'Frameworks/LibXray.xcframework' } || framework_group.new_file('Frameworks/LibXray.xcframework')
framework.source_tree = 'SOURCE_ROOT'
extension.frameworks_build_phase.add_file_reference(framework, true)
runner.add_dependency(extension) unless runner.dependencies.any? { |dep| dep.target == extension }
embed = runner.copy_files_build_phases.find { |phase| phase.name == 'Embed App Extensions' } || runner.new_copy_files_build_phase('Embed App Extensions')
embed.dst_subfolder_spec = '13'
embedded = embed.add_file_reference(extension.product_reference, true)
embedded.settings = { 'ATTRIBUTES' => ['RemoveHeadersOnCopy'] }
project.build_configurations.each { |config| config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0' }
[runner, extension].each do |target|
  target.build_configurations.each do |config|
    settings = config.build_settings
    settings['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0'
    settings['SWIFT_VERSION'] = '5.0'
    settings['CODE_SIGN_STYLE'] = 'Automatic'
    settings['DEVELOPMENT_TEAM'] = team if team && !team.empty?
    settings['PRODUCT_BUNDLE_IDENTIFIER'] = target == runner ? base : "#{base}.PacketTunnel"
    settings['CODE_SIGN_ENTITLEMENTS'] = target == runner ? 'Runner/Runner.entitlements' : 'PacketTunnel/PacketTunnel.entitlements'
    next if target == runner
    settings['INFOPLIST_FILE'] = 'PacketTunnel/Info.plist'
    settings['GENERATE_INFOPLIST_FILE'] = 'NO'
    settings['APPLICATION_EXTENSION_API_ONLY'] = 'YES'
    settings['SKIP_INSTALL'] = 'YES'
    settings['MARKETING_VERSION'] = '1.0.0'
    settings['CURRENT_PROJECT_VERSION'] = '1'
    settings['TARGETED_DEVICE_FAMILY'] = '1,2'
    settings['OTHER_LDFLAGS'] = ['$(inherited)', '-lresolv', '-framework', 'Security', '-framework', 'CoreFoundation']
  end
end
project.save
puts "Configured #{base} and #{base}.PacketTunnel. No signing credentials were stored."
