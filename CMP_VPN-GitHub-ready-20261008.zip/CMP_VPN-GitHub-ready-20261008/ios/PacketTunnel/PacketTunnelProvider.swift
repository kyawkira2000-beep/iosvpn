import Foundation
import NetworkExtension
import Darwin
import LibXray

/// Owns the single Go runtime in the extension; never link LibXray into Runner.
final class PacketTunnelProvider: NEPacketTunnelProvider {
    private let worker = DispatchQueue(label: "dev.cmpvpn.engine")
    private var generation = 0
    private var running = false
    private var timer: DispatchSourceTimer?
    private var interfaceName: String?
    private var baseline: (UInt64, UInt64)?

    private func invoke(_ method: String, payload: [String: Any] = [:]) throws -> [String: Any] {
        let request = try JSONSerialization.data(withJSONObject: ["apiVersion": 3, "method": method, "payload": payload])
        let text = String(decoding: request, as: UTF8.self)
        guard let response = text.withCString({ CGoInvoke(UnsafeMutablePointer(mutating: $0)) }) else { throw failure("VPN engine did not respond.") }
        defer { CGoFree(response) }
        let data = Data(String(cString: response).utf8)
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any], json["success"] as? Bool == true else {
            // Native errors can include configuration secrets; do not forward them.
            throw failure("VPN engine operation failed.")
        }
        return json["data"] as? [String: Any] ?? [:]
    }

    override func startTunnel(options: [String: NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        worker.async {
            self.generation += 1
            let token = self.generation
            do {
                guard !self.running, let raw = options?["config"] as? String, raw.utf8.count <= 131072,
                      var config = try JSONSerialization.jsonObject(with: Data(raw.utf8)) as? [String: Any],
                      var outbounds = config["outbounds"] as? [[String: Any]], outbounds.count == 1,
                      outbounds[0]["protocol"] as? String == "vless",
                      (outbounds[0]["streamSettings"] as? [String: Any])?["security"] as? String == "reality",
                      var settings = outbounds[0]["settings"] as? [String: Any],
                      var servers = settings["vnext"] as? [[String: Any]], servers.count == 1,
                      let host = servers[0]["address"] as? String else { throw self.failure("Invalid iOS VPN configuration.") }
                // Resolve before installing tunnel DNS, then retain the original REALITY SNI.
                let address = try self.resolve(host)
                servers[0]["address"] = address
                settings["vnext"] = servers
                outbounds[0]["settings"] = settings
                config["outbounds"] = outbounds
                config["inbounds"] = [["tag": "tun-in", "protocol": "tun", "settings": ["name": "cmp-vpn", "MTU": 1400]]]
                config["log"] = ["loglevel": "none", "access": "none", "error": "none"]
                let network = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: address)
                network.mtu = 1400
                let ipv4 = NEIPv4Settings(addresses: ["172.19.0.2"], subnetMasks: ["255.255.255.252"])
                ipv4.includedRoutes = [NEIPv4Route.default()]
                let ipv6 = NEIPv6Settings(addresses: ["fd74:636d:7000::2"], networkPrefixLengths: [64])
                ipv6.includedRoutes = [NEIPv6Route.default()]
                if address.contains(":") {
                    ipv6.excludedRoutes = [NEIPv6Route(destinationAddress: address, networkPrefixLength: 128)]
                } else {
                    ipv4.excludedRoutes = [NEIPv4Route(destinationAddress: address, subnetMask: "255.255.255.255")]
                }
                network.ipv4Settings = ipv4
                network.ipv6Settings = ipv6
                let dns = NEDNSSettings(servers: ["1.1.1.1", "2606:4700:4700::1111"])
                dns.matchDomains = [""]
                network.dnsSettings = dns
                let template = config
                self.setTunnelNetworkSettings(network) { error in
                    self.worker.async {
                        guard token == self.generation else { completionHandler(self.failure("VPN start was cancelled.")); return }
                        do {
                            if let error = error { throw error }
                            let descriptor = try self.tunnelDescriptor()
                            self.interfaceName = descriptor.1
                            self.baseline = self.counters()
                            var native = template
                            native["env"] = ["xray.tun.fd": String(descriptor.0)]
                            let bytes = try JSONSerialization.data(withJSONObject: native)
                            _ = try self.invoke("runXray", payload: ["xrayJson": String(decoding: bytes, as: UTF8.self)])
                            self.running = true
                            self.watchEngine()
                            completionHandler(nil)
                        } catch {
                            _ = try? self.invoke("stopXray")
                            completionHandler(self.failure("Could not start the iOS VPN tunnel."))
                        }
                    }
                }
            } catch { completionHandler(self.failure("Could not prepare the iOS VPN tunnel. Check the server and network.")) }
        }
    }

    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        worker.async {
            self.generation += 1
            self.timer?.cancel()
            self.timer = nil
            _ = try? self.invoke("stopXray")
            self.running = false
            self.interfaceName = nil
            self.baseline = nil
            // NetworkExtension owns the utun FD and removes the installed routes.
            completionHandler()
        }
    }

    override func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)?) {
        worker.async {
            guard messageData == Data("stats".utf8), self.running else { completionHandler?(nil); return }
            let value = self.counters()
            let base = self.baseline ?? value
            let up = value.0 >= base.0 ? value.0 - base.0 : 0
            let down = value.1 >= base.1 ? value.1 - base.1 : 0
            completionHandler?(try? JSONSerialization.data(withJSONObject: ["upload": up, "download": down, "tick": Int(ProcessInfo.processInfo.systemUptime * 1000)]))
        }
    }

    private func watchEngine() {
        let source = DispatchSource.makeTimerSource(queue: worker)
        source.schedule(deadline: .now() + 2, repeating: 2)
        source.setEventHandler { [weak self] in
            guard let self = self, self.running else { return }
            if (try? self.invoke("getXrayState")["running"] as? Bool) != true {
                self.running = false
                self.timer?.cancel()
                self.timer = nil
                self.cancelTunnelWithError(self.failure("VPN engine stopped."))
            }
        }
        timer = source
        source.resume()
    }

    private func resolve(_ host: String) throws -> String {
        var hints = addrinfo()
        hints.ai_family = AF_UNSPEC
        hints.ai_socktype = SOCK_STREAM
        var results: UnsafeMutablePointer<addrinfo>?
        guard getaddrinfo(host, nil, &hints, &results) == 0, let head = results else { throw failure("Server DNS failed.") }
        defer { freeaddrinfo(head) }
        var cursor: UnsafeMutablePointer<addrinfo>? = head
        while let entry = cursor {
            var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(entry.pointee.ai_addr, entry.pointee.ai_addrlen, &buffer, socklen_t(buffer.count), nil, 0, NI_NUMERICHOST) == 0 {
                return String(cString: buffer)
            }
            cursor = entry.pointee.ai_next
        }
        throw failure("Server DNS failed.")
    }

    private func tunnelDescriptor() throws -> (Int32, String) {
        // BSD UTUN_OPT_IFNAME identifies the extension's one utun socket without KVC/private selectors.
        var found: [(Int32, String)] = []
        for fd in 0..<min(getdtablesize(), 16384) {
            var name = [CChar](repeating: 0, count: Int(IFNAMSIZ))
            var length = socklen_t(name.count)
            if getsockopt(fd, 2, 2, &name, &length) == 0 {
                let value = String(cString: name)
                if value.hasPrefix("utun") { found.append((fd, value)) }
            }
        }
        guard found.count == 1, let result = found.first else { throw failure("Could not identify the VPN interface safely.") }
        return result
    }

    private func counters() -> (UInt64, UInt64) {
        var list: UnsafeMutablePointer<ifaddrs>?
        guard let expected = interfaceName, getifaddrs(&list) == 0, let first = list else { return (0, 0) }
        defer { freeifaddrs(first) }
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let entry = cursor {
            let row = entry.pointee
            if String(cString: row.ifa_name) == expected, row.ifa_addr?.pointee.sa_family == UInt8(AF_LINK), let data = row.ifa_data {
                let stats = data.assumingMemoryBound(to: if_data.self).pointee
                // OS output to utun is upload; packets injected into the OS are download.
                return (UInt64(stats.ifi_obytes), UInt64(stats.ifi_ibytes))
            }
            cursor = row.ifa_next
        }
        return (0, 0)
    }
    private func failure(_ message: String) -> NSError { NSError(domain: "dev.cmpvpn.tunnel", code: 1, userInfo: [NSLocalizedDescriptionKey: message]) }
}
