import Flutter
import UIKit
import Security
import NetworkExtension

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  private let vpn = CMPVPNBridge()
  private let vaultQueue = DispatchQueue(label: "dev.cmpvpn.vault")
  private let vaultService = "dev.cmpvpn.client.profiles"

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)
    guard let registrar = engineBridge.pluginRegistry.registrar(forPlugin: "CMPNativeBridge") else { return }
    let messenger = registrar.messenger()
    FlutterMethodChannel(name: "dev.aerolink/connection", binaryMessenger: messenger).setMethodCallHandler { [weak self] call, result in
      self?.vpn.handle(call, result: result)
    }
    FlutterMethodChannel(name: "dev.aerolink/preferences", binaryMessenger: messenger).setMethodCallHandler { call, result in
      switch call.method {
      case "getLanguage": result(UserDefaults.standard.string(forKey: "language") ?? "en")
      case "setLanguage":
        guard let language = call.arguments as? String, ["en", "my"].contains(language) else {
          result(FlutterError(code: "language", message: "Invalid language", details: nil)); return
        }
        UserDefaults.standard.set(language, forKey: "language")
        result(nil)
      default: result(FlutterMethodNotImplemented)
      }
    }
    FlutterMethodChannel(name: "dev.aerolink/vault", binaryMessenger: messenger).setMethodCallHandler { [weak self] call, result in
      guard let self = self else { return }
      self.vaultQueue.async {
        do {
          let args = call.arguments as? [String: Any] ?? [:]
          let account = (args["testing"] as? Bool == true) ? "test" : "profiles"
          let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: self.vaultService, kSecAttrAccount as String: account]
          var readQuery = query
          readQuery[kSecReturnData as String] = true
          readQuery[kSecMatchLimit as String] = kSecMatchLimitOne
          var item: CFTypeRef?
          let status = SecItemCopyMatching(readQuery as CFDictionary, &item)
          guard status == errSecSuccess || status == errSecItemNotFound else { throw VaultError.storage }
          let existing = (item as? Data).flatMap { String(data: $0, encoding: .utf8) }
          if call.method == "read" {
            DispatchQueue.main.async { result(existing) }; return
          }
          guard call.method == "write" else { DispatchQueue.main.async { result(FlutterMethodNotImplemented) }; return }
          guard let content = args["content"] as? String, let data = content.data(using: .utf8), data.count <= 4 * 1024 * 1024,
                (args["expected"] as? String ?? "") == (existing ?? "") else { throw VaultError.conflict }
          let attributes: [String: Any] = [kSecValueData as String: data, kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
          var insert = query
          attributes.forEach { insert[$0.key] = $0.value }
          let written = status == errSecItemNotFound ? SecItemAdd(insert as CFDictionary, nil) : SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
          guard written == errSecSuccess else { throw VaultError.storage }
          DispatchQueue.main.async { result(nil) }
        } catch {
          DispatchQueue.main.async { result(FlutterError(code: "vault", message: "Secure storage could not be updated. Reload and try again.", details: nil)) }
        }
      }
    }
  }
  private enum VaultError: Error { case storage, conflict }
}

/// Flutter-facing manager. Configuration is passed as transient start options,
/// never written into the system VPN preferences or a shared plaintext file.
private final class CMPVPNBridge {
    private var manager: NETunnelProviderManager?
    private var starting = false
    private var generation = 0
    private var lastError: String?
    private var verifiedAt: Date?
    private var latency = 0
    private var probeSerial = 0
    private var probeTask: URLSessionDataTask?
    private var probeURL = URL(string: "https://cp.cloudflare.com/generate_204")!
    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 8
        config.timeoutIntervalForResource = 10
        return URLSession(configuration: config)
    }()
    private var extensionID: String { (Bundle.main.bundleIdentifier ?? "dev.cmpvpn.client") + ".PacketTunnel" }

    func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        switch call.method {
        case "status":
            load { error in
                if error != nil { result(FlutterError(code: "vpn", message: "Cannot read iOS VPN preferences.", details: nil)); return }
                self.status(result)
            }
        case "start":
            guard !starting, let args = call.arguments as? [String: Any],
                  let config = args["config"] as? String, config.utf8.count <= 131072,
                  let probe = args["probe"] as? String, let url = URL(string: probe),
                  url.scheme == "https", url.host != nil, url.user == nil, url.password == nil, url.fragment == nil else {
                result(FlutterError(code: "vpn", message: "Invalid iOS VPN request or a start is already pending.", details: nil)); return
            }
            starting = true
            generation += 1
            let token = generation
            lastError = nil
            verifiedAt = nil
            probeSerial += 1
            probeTask?.cancel()
            probeTask = nil
            probeURL = url
            load { error in
                guard token == self.generation else { result(self.cancelled()); return }
                guard error == nil else { self.starting = false; result(self.failed()); return }
                let manager = self.manager ?? NETunnelProviderManager()
                guard ![NEVPNStatus.connected, .connecting, .reasserting, .disconnecting].contains(manager.connection.status) else {
                    self.starting = false; result(self.failed()); return
                }
                let settings = NETunnelProviderProtocol()
                settings.providerBundleIdentifier = self.extensionID
                settings.serverAddress = "CMP VPN"
                settings.disconnectOnSleep = false
                manager.protocolConfiguration = settings
                manager.localizedDescription = "CMP VPN"
                manager.isEnabled = true
                manager.isOnDemandEnabled = false
                manager.saveToPreferences { error in
                    DispatchQueue.main.async {
                        guard token == self.generation else { result(self.cancelled()); return }
                        guard error == nil else { self.starting = false; result(self.failed()); return }
                        manager.loadFromPreferences { error in
                            DispatchQueue.main.async {
                                guard token == self.generation else { result(self.cancelled()); return }
                                self.starting = false
                                guard error == nil else { result(self.failed()); return }
                                do {
                                    self.manager = manager
                                    try manager.connection.startVPNTunnel(options: ["config": config as NSString])
                                    result(nil)
                                } catch { result(self.failed()) }
                            }
                        }
                    }
                }
            }
        case "stop":
            generation += 1
            let token = generation
            starting = false
            verifiedAt = nil
            lastError = nil
            probeSerial += 1
            probeTask?.cancel()
            probeTask = nil
            load { error in
                guard error == nil else { result(self.failed()); return }
                guard token == self.generation else { result(nil); return }
                self.manager?.connection.stopVPNTunnel()
                result(nil)
            }
        default: result(FlutterMethodNotImplemented)
        }
    }

    private func load(_ completion: @escaping (Error?) -> Void) {
        if manager != nil { completion(nil); return }
        NETunnelProviderManager.loadAllFromPreferences { managers, error in
            DispatchQueue.main.async {
                // Do not replace an object established by another pending start.
                if self.manager == nil {
                    self.manager = managers?.first { ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == self.extensionID }
                }
                completion(error)
            }
        }
    }

    private func status(_ result: @escaping FlutterResult) {
        guard let manager = manager else {
            result(starting ? "connecting|Starting iOS VPN…|0" : "disconnected|Ready to connect.|0"); return
        }
        guard manager.connection.status == .connected else {
            verifiedAt = nil
            probeSerial += 1
            probeTask?.cancel()
            probeTask = nil
            if let error = lastError { result("failed|\(error)|0") }
            else if starting || [.connecting, .reasserting, .disconnecting].contains(manager.connection.status) { result("connecting|Changing iOS VPN connection…|0") }
            else { result("disconnected|Ready to connect.|0") }
            return
        }
        if verifiedAt == nil || Date().timeIntervalSince(verifiedAt!) > 15 { verify(manager) }
        guard verifiedAt != nil else { result("connecting|Checking HTTPS through the selected server.|0"); return }
        let snapshot = "connected|HTTPS through VPN verified.|\(latency)"
        guard let provider = manager.connection as? NETunnelProviderSession else { result(snapshot); return }
        var completed = false
        let token = generation
        func finish(_ data: Data?) {
            guard !completed else { return }
            completed = true
            guard token == self.generation, manager.connection.status == .connected, self.verifiedAt != nil else {
                result("disconnected|VPN connection changed.|0"); return
            }
            if let data = data, let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let up = object["upload"] as? NSNumber, let down = object["download"] as? NSNumber, let tick = object["tick"] as? NSNumber {
                result("\(snapshot)|\(up.uint64Value)|\(down.uint64Value)|\(tick.uint64Value)")
            } else { result(snapshot) }
        }
        do {
            try provider.sendProviderMessage(Data("stats".utf8)) { data in DispatchQueue.main.async { finish(data) } }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { finish(nil) }
        } catch { finish(nil) }
    }

    private func verify(_ manager: NETunnelProviderManager) {
        guard probeTask == nil else { return }
        let token = generation
        probeSerial += 1
        let check = probeSerial
        let url = probeURL
        let started = ProcessInfo.processInfo.systemUptime
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 8
        probeTask = session.dataTask(with: request) { _, response, error in
            DispatchQueue.main.async {
                guard token == self.generation, check == self.probeSerial else { return }
                self.probeTask = nil
                guard manager.connection.status == .connected else { return }
                guard error == nil, let http = response as? HTTPURLResponse, http.statusCode == 204, http.url == url else {
                    self.verifiedAt = nil
                    self.lastError = "iOS HTTPS through the VPN failed. Check the server and try again."
                    manager.connection.stopVPNTunnel()
                    return
                }
                self.latency = max(1, Int((ProcessInfo.processInfo.systemUptime - started) * 1000))
                self.verifiedAt = Date()
            }
        }
        probeTask?.resume()
    }
    private func cancelled() -> FlutterError { FlutterError(code: "vpn", message: "VPN start was cancelled.", details: nil) }
    private func failed() -> FlutterError { FlutterError(code: "vpn", message: "Could not start iOS VPN. Check VPN permission and signing.", details: nil) }
}
