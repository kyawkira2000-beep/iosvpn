# CMP VPN — iOS engine source, 2026-10-08

The iOS Packet Tunnel source and Flutter connection adapter are now implemented. This is **source for a Mac build**, not a tested iPhone release or an IPA. Xcode/Swift compilation and physical-device networking have not been verified on this Windows host.

Implemented: transient VPN start options (no plaintext profile file), signed Network Extension target setup, VLESS REALITY TCP/RAW with pinned static libXray 26.9.30, pre-tunnel endpoint resolution, IPv4/IPv6 default routes, tunnel DNS, serialized start/stop, engine supervision, interface counters, and an HTTPS check from the containing app before showing Connected. The private profile catalog stays in Keychain. The provider owns one Go runtime; Runner never links it.

## Build on a Mac

Requirements: Xcode with iOS SDK, Flutter compatible with Dart >=3.12.2, Python 3, Ruby and `xcodeproj` 1.27.0. Minimum iOS 15 (the pinned native library requires it).

```sh
gem install --user-install xcodeproj -v 1.27.0
bash scripts/build_ios.sh
```

The build script verifies the official engine ZIP SHA-256, installs the XCFramework inside this project, configures and embeds the PacketTunnel extension, and performs an unsigned release compile. It requires no Apple password. It never modifies another VPN profile.

Optional identifiers, before running the build script:

```sh
export CMP_BUNDLE_ID=dev.yourcompany.cmpvpn
export CMP_APPLE_TEAM=YOUR_TEAM_ID
bash scripts/build_ios.sh
```

For an installable IPA: open `ios/Runner.xcworkspace`, select your team for Runner and PacketTunnel, register both bundle identifiers with Network Extensions capability, then Product → Archive → Distribute App. A valid Apple signing/provisioning setup is necessary. An unsigned .app cannot be installed as an IPA by renaming or zipping it.

`configure_ios.rb` adds the PacketTunnel target to the existing Flutter project; rerunning it reuses the target and embedded extension. The distributed project must be configured by this script before Xcode compilation. LibXray is static: link it only in PacketTunnel, never embed a second Go runtime.

## Mandatory Mac/iPhone validation still pending

1. Compile both Runner and extension with the pinned framework; resolve any SDK/Swift compatibility errors before signing.
2. Connect a valid REALITY profile and verify a changed egress IP, UDP DNS, IPv4 and IPv6 with actual server traffic. The app's HTTPS probe is a reachability check, not a complete leak test.
3. Try rejected VPN permission, wrong credentials, unreachable DNS/server, cancel during start, repeated connect/disconnect, and relaunch while connected.
4. Test Wi-Fi ↔ cellular, screen lock/sleep, memory pressure and extension restart. Background auto-reconnect/on-demand start is intentionally disabled: credentials are transient start options.
5. Check upload/download direction against known transfers. BSD interface counters may wrap on long sessions; UI resets negative deltas safely. Watch extension RAM under load.
6. Inspect that profiles are absent from VPN preferences, logs and delivery archives. No browsing reports or DMS device approval is enabled for direct CMP profiles.

The native FD lookup uses BSD UTUN_OPT_IFNAME and refuses ambiguous matches; it does not use private KVC accessors. Its behavior must be validated on the supported iOS versions. A VPN stopped by iOS can allow normal networking to resume; this preview makes no always-on/kill-switch guarantee.

## References

- Apple Packet Tunnel: https://developer.apple.com/documentation/networkextension/nepackettunnelprovider
- Pinned engine API/build: https://github.com/XTLS/libXray/tree/3c694b23290f9849fe52284a345ebd4343bc90cd
- Pinned Darwin TUN implementation: https://github.com/XTLS/Xray-core/blob/b26a91de4f32/proxy/tun/tun_darwin.go
