# GitHub Mac build

This workflow compiles the real Runner app and PacketTunnel extension on macOS. It produces **CMP_VPN-UNSIGNED.ipa** only after both compiled executables and extension metadata are present. It is not a signed release and cannot be installed directly on an iPhone.

1. Put the contents of this iOS source package at the root of your private GitHub repository, including `.github/workflows/ios-compile.yml`.
2. Open Actions → CMP VPN iOS compile → Run workflow.
3. If compilation fails, inspect the failed step; no IPA artifact is published as success.
4. Download `CMP_VPN-iOS-UNSIGNED` from the completed run's Artifacts.

Apple signing remains a separate required step. Both the containing app and PacketTunnel extension need matching provisioning profiles with the Network Extension capability. Do not commit certificates, private keys or provisioning files. GitHub account access alone does not supply Apple signing.

No cloud run or source upload has been performed merely by creating this workflow file. Mac runner usage is subject to your GitHub account's Actions limits/billing settings. The workflow only starts manually and retains build artifacts for seven days.
