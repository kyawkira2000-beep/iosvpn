# CMP VPN iOS — 2026-10-08

VPN tunnel engine ချိတ်ဆက်မည့် source ကို ရေးထည့်ပြီးပါပြီ။ ဒီ ZIP က Mac မှာ build စစ်ဖို့ source ဖြစ်ပြီး install လုပ်နိုင်တဲ့ IPA မဟုတ်သေးပါ။

Packet Tunnel extension၊ pinned Xray engine download/checksum၊ IPv4/IPv6/DNS routing၊ connect/disconnect၊ speed counters၊ HTTPS latency စစ်ဆေးမှု၊ Keychain storage နဲ့ မြန်မာ/English UI ပါပါတယ်။

## Mac ရလာလျှင်
Xcode၊ Flutter (Dart 3.12.2 နှင့်အထက်)၊ Python 3၊ Ruby လိုပါတယ်။ ZIP ကိုဖြည်ပြီး project folder ရဲ့ Terminal မှာ —

```sh
gem install --user-install xcodeproj -v 1.27.0
bash scripts/build_ios.sh
```

Engine ကို download/checksum စစ်ပြီး Xcode extension target ထည့်ကာ unsigned build စမ်းပါမယ်။ iOS 15 နှင့်အထက် လိုပါတယ်။

ဖုန်းမှာ install လုပ်ဖို့ ios/Runner.xcworkspace ကို Xcode မှာဖွင့်ပြီး Runner နဲ့ PacketTunnel နှစ်ခုလုံးအတွက် Apple team၊ bundle ID၊ VPN capability၊ provisioning ကို ပြင်ပါ။ ထို့နောက် Archive → Distribute App ကနေ IPA ထုတ်ပါ။ အသေးစိတ်ကို IOS_BUILD.md မှာ ကြည့်ပါ။

## စစ်ဆေးရန် ကျန်နေသည်
ဒီ Windows စက်မှာ Swift/Xcode build မစစ်နိုင်ပါ။ iPhone မှာ Wi-Fi/mobile data ပြောင်းခြင်း၊ DNS/IPv6 routing၊ screen lock၊ RAM သုံးစွဲမှုနဲ့ traffic counter ကို စမ်းသပ်ရန် ကျန်ပါတယ်။ Background auto-reconnect မပါသေးပါ။ ဖုန်းမှာ အလုပ်လုပ်ပြီလို့ အတည်မပြုရသေးပါ။

Flutter tests 59 ခု၊ engine archive tests 3 ခု အောင်ပါတယ်။ ယခင် Android APK ကို ဒီ source update ကြောင့် ပြန်မထုတ်ထားပါ။
