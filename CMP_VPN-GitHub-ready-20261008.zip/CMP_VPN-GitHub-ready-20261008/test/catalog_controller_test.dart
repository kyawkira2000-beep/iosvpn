import 'dart:async';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/profiles/domain/vless_profile.dart';
import 'package:cmp_vpn/features/profiles/presentation/catalog_controller.dart';
import 'package:cmp_vpn/features/subscriptions/data/subscription_client.dart';
import 'package:cmp_vpn/features/subscriptions/domain/subscription_feed.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'support.dart';

class FeedClient extends SubscriptionClient {
  SubscriptionFeed feed = SubscriptionFeed([VlessProfile.parse(testLink)], 0);
  bool fail = false;
  Completer<void>? gate;
  @override
  Future<SubscriptionFeed> fetch(String url) async {
    await gate?.future;
    if (fail) throw const AppFailure('Fetch failed');
    return feed;
  }
}

void main() {
  late MemoryVault vault;
  late FeedClient client;
  late ProviderContainer container;
  setUp(() async {
    vault = MemoryVault();
    client = FeedClient();
    container = ProviderContainer(
      overrides: [
        vaultStorageProvider.overrideWithValue(vault),
        subscriptionClientProvider.overrideWithValue(client),
      ],
    );
    await container.read(catalogProvider.future);
  });
  tearDown(() => container.dispose());
  test('manual import dedup, failed save rollback and removal', () async {
    final controller = container.read(catalogProvider.notifier);
    await controller.importLink(testLink);
    final original = container.read(catalogProvider).requireValue;
    await expectLater(
      controller.importLink(testLink),
      throwsA(isA<AppFailure>()),
    );
    vault.fail = true;
    await expectLater(
      controller.removeProfile(original.selected!),
      throwsA(isA<AppFailure>()),
    );
    expect(container.read(catalogProvider).requireValue, same(original));
    expect(container.read(libraryBusyProvider), isFalse);
    vault.fail = false;
    await controller.removeProfile(original.selected!);
    expect(container.read(catalogProvider).requireValue.profiles, isEmpty);
  });
  test(
    'subscription refresh is atomic, scoped and preserves selection',
    () async {
      final controller = container.read(catalogProvider.notifier);
      await controller.importLink(testLink);
      await controller.addSubscription('One', 'https://one.invalid/token');
      await controller.addSubscription('Two', 'https://two.invalid/token');
      var c = container.read(catalogProvider).requireValue;
      final sub = c.subscriptions.first, key = c.profiles[1].key;
      await controller.select(key);
      await controller.refresh(sub.id);
      expect(container.read(catalogProvider).requireValue.selected, key);
      client.fail = true;
      final saved = vault.content;
      await expectLater(controller.refresh(sub.id), throwsA(isA<AppFailure>()));
      expect(vault.content, saved);
      expect(container.read(catalogProvider).requireValue.profiles.length, 3);
      client.fail = false;
      client.feed = SubscriptionFeed([
        VlessProfile.parse(
          testLink.replaceFirst('server.invalid', 'new.invalid'),
        ),
      ], 1);
      await controller.refresh(sub.id);
      c = container.read(catalogProvider).requireValue;
      expect(c.selected, isNull);
      expect(c.profiles.length, 3);
      expect(c.subscriptions.last.rejected, 1);
      await controller.removeSubscription(sub.id);
      c = container.read(catalogProvider).requireValue;
      expect(c.profiles.length, 2);
      expect(c.subscriptions.length, 1);
      expect(c.profiles.first.subscriptionId, isNull);
    },
  );
  test('concurrent mutation rejected while download runs', () async {
    client.gate = Completer<void>();
    final controller = container.read(catalogProvider.notifier);
    final pending = controller.addSubscription(
      'One',
      'https://one.invalid/token',
    );
    await expectLater(
      controller.importLink(testLink),
      throwsA(isA<AppFailure>()),
    );
    expect(container.read(libraryBusyProvider), isTrue);
    client.gate!.complete();
    await pending;
    expect(container.read(libraryBusyProvider), isFalse);
  });
}
