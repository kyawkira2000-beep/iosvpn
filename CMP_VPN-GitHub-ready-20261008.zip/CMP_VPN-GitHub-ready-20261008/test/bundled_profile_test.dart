import 'dart:convert';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/profiles/data/catalog_repository.dart';
import 'package:cmp_vpn/features/profiles/domain/catalog.dart';
import 'package:cmp_vpn/features/profiles/domain/vless_profile.dart';
import 'package:cmp_vpn/features/profiles/presentation/catalog_controller.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'support.dart';

void main() {
  final bundled = SavedProfile(VlessProfile.parse(testLink), isBuiltIn: true);
  final manual = SavedProfile(
    VlessProfile.parse(
      testLink.replaceFirst('server.invalid', 'personal.invalid'),
    ),
  );
  test(
    'first upgrade selects default, preserves personal profiles, stores no bundled link',
    () async {
      final vault = MemoryVault()
        ..content = jsonEncode(
          Catalog(profiles: [manual], selected: manual.key).toJson(),
        );
      final repo = CatalogRepository(vault, defaultProfile: bundled);
      final catalog = await repo.load();
      expect(catalog.selectedProfile!.isBuiltIn, isTrue);
      expect(catalog.profiles.map((p) => p.key), [bundled.key, manual.key]);
      expect(vault.content, isNot(contains(testLink)));
      expect(jsonDecode(vault.content!)['defaultInitialized'], isTrue);
      expect(bundled.exportLink, isNull);
      expect(bundled.displayName, 'အခမဲ့ဆာဗာ');
    },
  );
  test(
    'manual choice persists across restart and deleting it restores default',
    () async {
      final vault = MemoryVault();
      ProviderContainer session() => ProviderContainer(
        overrides: [
          vaultStorageProvider.overrideWithValue(vault),
          bundledProfileProvider.overrideWithValue(bundled),
        ],
      );
      var container = session();
      await container.read(catalogProvider.future);
      await container
          .read(catalogProvider.notifier)
          .importLink(manual.profile.link);
      expect(container.read(catalogProvider).requireValue.selected, manual.key);
      container.dispose();
      container = session();
      addTearDown(container.dispose);
      expect(
        (await container.read(catalogProvider.future)).selected,
        manual.key,
      );
      await container.read(catalogProvider.notifier).removeProfile(manual.key);
      expect(
        container.read(catalogProvider).requireValue.selected,
        bundled.key,
      );
      await expectLater(
        container.read(catalogProvider.notifier).removeProfile(bundled.key),
        throwsA(isA<AppFailure>()),
      );
      await expectLater(
        container
            .read(catalogProvider.notifier)
            .importLink(testLink.replaceFirst('#Test%20Server', '#Renamed')),
        throwsA(isA<AppFailure>()),
      );
    },
  );
  test(
    'old copies of bundled credentials cannot appear as exportable manual entries',
    () async {
      final oldCopy = SavedProfile(
        bundled.profile,
        subscriptionId: 'subscription',
      );
      final vault = MemoryVault()
        ..content = jsonEncode(
          Catalog(profiles: [oldCopy], selected: oldCopy.key).toJson(),
        );
      final catalog = await CatalogRepository(
        vault,
        defaultProfile: bundled,
      ).load();
      expect(catalog.profiles.length, 1);
      expect(catalog.selectedProfile!.exportLink, isNull);
      expect(vault.content, isNot(contains(testLink)));
    },
  );
  test(
    'corrupt storage is never replaced by automatic default setup',
    () async {
      final vault = MemoryVault()..content = 'corrupt';
      await expectLater(
        CatalogRepository(vault, defaultProfile: bundled).load(),
        throwsA(isA<AppFailure>()),
      );
      expect(vault.content, 'corrupt');
    },
  );
}
