import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/profiles/domain/vless_profile.dart';
import 'package:cmp_vpn/features/connection/domain/xray_config.dart';
import 'package:cmp_vpn/features/connection/data/device_access.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cmp_vpn/features/connection/presentation/device_access_card.dart';

class AccessFixture extends DeviceAccessTransport {
  String status = 'pending';
  bool acknowledged = false;
  final calls = <String>[];
  @override
  Future<Map<String, dynamic>> request(
    VlessProfile profile,
    String action, {
    String? version,
  }) async {
    calls.add(action);
    if (action == 'identity') {
      return {'fingerprint': List.filled(64, 'a').join()};
    }
    if (action == 'notice') {
      return {
        'enabled': true,
        'version': 'v1',
        'textEn': 'Disclosed monitoring',
        'textMy': 'အသိပေးချက်',
        'retentionDays': 7,
      };
    }
    if (action == 'acknowledge') {
      expect(version, 'v1');
      acknowledged = true;
      status = 'approved';
      return {'status': 'acknowledged'};
    }
    return {'status': status};
  }
}

const managedLink =
    'vless://11111111-2222-4333-8444-555555555555@vpn.example.com:443?security=tls&type=tcp&encryption=none&dms=1#Work';

void main() {
  testWidgets(
    'notice is visible before consent and cancel never acknowledges',
    (tester) async {
      final transport = AccessFixture()..status = 'notice_required';
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            deviceAccessTransportProvider.overrideWithValue(transport),
          ],
          child: MaterialApp(
            home: Scaffold(
              body: SingleChildScrollView(
                child: DeviceAccessCard(
                  profile: VlessProfile.parse(managedLink),
                  active: false,
                ),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('Check access'));
      await tester.pumpAndSettle();
      expect(transport.acknowledged, isFalse);
      await tester.tap(find.text('Read notice'));
      await tester.pumpAndSettle();
      expect(find.text('Disclosed monitoring'), findsOneWidget);
      await tester.tap(find.text('Cancel'));
      await tester.pumpAndSettle();
      expect(transport.acknowledged, isFalse);
      await tester.tap(find.text('Read notice'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('I understand and agree'));
      await tester.pumpAndSettle();
      expect(transport.acknowledged, isTrue);
      expect(find.text('Device approved'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  test(
    'approval and notice states fail closed; acknowledgement requires an explicit action',
    () async {
      final transport = AccessFixture();
      final container = ProviderContainer(
        overrides: [deviceAccessTransportProvider.overrideWithValue(transport)],
      );
      addTearDown(container.dispose);
      final controller = container.read(deviceAccessProvider.notifier);
      final profile = VlessProfile.parse(managedLink);
      for (final status in [
        'pending',
        'rejected',
        'revoked',
        'suspended',
        'unassigned',
        'unexpected',
      ]) {
        transport.status = status;
        expect(await controller.check(profile), isFalse);
      }
      transport.status = 'notice_required';
      expect(await controller.check(profile), isFalse);
      expect(transport.acknowledged, isFalse);
      await controller.acknowledge(profile, 'wrong-version');
      expect(transport.acknowledged, isFalse);
      await controller.acknowledge(profile, 'v1');
      expect(transport.acknowledged, isTrue);
      expect(container.read(deviceAccessProvider).status, 'approved');
    },
  );
  test('managed TLS invite is eligible, never REALITY or Vision', () {
    final profile = VlessProfile.parse(managedLink);
    expect(profile.managed, isTrue);
    expect(profile.baselineEligible, isTrue);
    for (final link in [
      managedLink.replaceFirst('tls', 'reality'),
      '$managedLink&flow=xtls-rprx-vision',
    ]) {
      // Parameters belong before the fragment.
      final input = link.replaceFirst('#Work&', '&').replaceFirst('#Work', '');
      expect(() => VlessProfile.parse(input), throwsA(isA<AppFailure>()));
    }
    expect(
      () => VlessProfile.parse(managedLink.replaceFirst('dms=1', 'dms=0')),
      throwsA(isA<AppFailure>()),
    );
  });
  test('managed transport cannot fall through to an ordinary TLS outbound', () {
    final profile = VlessProfile.parse(managedLink);
    expect(
      () => buildXrayConfig(profile, 10808, 10809),
      throwsA(isA<AppFailure>()),
    );
    final config =
        jsonDecode(buildXrayConfig(profile, 10808, 10809, android: true))
            as Map;
    expect(config['dmsGateway']['uuid'], profile.uuid);
    expect(config['outbounds'].single['streamSettings']['security'], 'none');
    expect(
      config['outbounds'].single['settings']['vnext'].single['address'],
      '127.0.0.1',
    );
    expect(config['outbounds'].single['settings']['vnext'].single['port'], 0);
  });
}
