import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/connection/data/connection_bridge.dart';
import 'package:cmp_vpn/features/connection/domain/connection_status.dart';
import 'package:cmp_vpn/features/connection/domain/xray_config.dart';
import 'package:cmp_vpn/features/connection/domain/traffic_sample.dart';
import 'package:cmp_vpn/features/connection/presentation/connection_controller.dart';
import 'package:cmp_vpn/features/profiles/domain/vless_profile.dart';
import 'package:cmp_vpn/features/profiles/presentation/catalog_controller.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'support.dart';

class TestBridge implements ConnectionBridge {
  String message = 'disconnected|Ready to connect.|0';
  bool started = false, stopped = false;
  int starts = 0;
  String? config;
  @override
  Future<String> status() async => message;
  @override
  Future<void> start(String value, int h, int s, String probe) async {
    started = true;
    starts++;
    config = value;
    message = 'connecting|Checking HTTPS through the selected server.|0';
  }

  @override
  Future<void> stop() async {
    stopped = true;
    message = 'disconnected|Previous proxy settings restored.|0';
  }
}

void main() {
  test(
    'traffic uses native elapsed time, ignores duplicate samples and resets safely',
    () {
      final first = TrafficSample.parse(
        'connected|OK|1|100|200|1000'.split('|'),
        null,
      )!;
      expect(first.uploadRate, isNull);
      final next = TrafficSample.parse(
        'connected|OK|1|300|1000|3000'.split('|'),
        first,
      )!;
      expect(next.uploadRate, 100);
      expect(next.downloadRate, 400);
      expect(
        TrafficSample.parse('connected|OK|1|300|1000|3000'.split('|'), next),
        same(next),
      );
      expect(
        TrafficSample.parse(
          'connected|OK|1|1|2|4000'.split('|'),
          next,
        )!.downloadRate,
        isNull,
      );
      expect(
        TrafficSample.parse('connected|OK|1|-1|2|4000'.split('|'), next),
        isNull,
      );
      expect(TrafficSample.parse('connected|OK|1'.split('|'), next), isNull);
    },
  );

  Future<(ProviderContainer, TestBridge, ConnectionController)> session({
    TargetPlatform platform = TargetPlatform.windows,
  }) async {
    final bridge = TestBridge();
    final c = ProviderContainer(
      overrides: [
        nativePlatformProvider.overrideWithValue(platform),
        connectionBridgeProvider.overrideWithValue(bridge),
        vaultStorageProvider.overrideWithValue(MemoryVault()),
        reconnectDelaysProvider.overrideWithValue(const [
          Duration(milliseconds: 80),
          Duration(milliseconds: 80),
        ]),
      ],
    );
    addTearDown(c.dispose);
    c.read(tunModeProvider.notifier).set(false);
    await c.read(catalogProvider.future);
    await c.read(catalogProvider.notifier).importLink(testLink);
    final ctrl = c.read(connectionProvider.notifier);
    await Future<void>.delayed(Duration.zero);
    await ctrl.poll();
    await ctrl.connect();
    return (c, bridge, ctrl);
  }

  test(
    'iOS uses the packet tunnel without Windows preparation or local proxies',
    () async {
      final (container, bridge, controller) = await session(
        platform: TargetPlatform.iOS,
      );
      expect(bridge.started, isTrue);
      final config = jsonDecode(bridge.config!) as Map;
      expect((config['inbounds'] as List).single['protocol'], 'tun');
      expect((config['outbounds'] as List).single['protocol'], 'vless');
      expect(
        container.read(connectionProvider).status,
        ConnectionStatus.connecting,
      );
      bridge.message = 'connected|HTTPS through VPN verified.|50|100|200|1000';
      await controller.poll();
      expect(container.read(connectionProvider).latency, 50);
      expect(container.read(connectionProvider).traffic!.upload, 100);
      await controller.disconnect();
      expect(bridge.stopped, isTrue);
    },
  );

  test('iOS refuses a Windows TUN plan and mixed native adapters', () {
    expect(
      () => buildXrayConfig(
        VlessProfile.parse(testLink),
        10808,
        10809,
        ios: true,
        android: true,
      ),
      throwsA(isA<AppFailure>()),
    );
    expect(
      () => buildXrayConfig(
        VlessProfile.parse(testLink),
        10808,
        10809,
        ios: true,
        tun: {},
      ),
      throwsA(isA<AppFailure>()),
    );
  });

  test(
    'Android captures both families through one TUN without direct fallback or local proxies',
    () {
      final config =
          jsonDecode(
                buildXrayConfig(
                  VlessProfile.parse(testLink),
                  10808,
                  10809,
                  android: true,
                ),
              )
              as Map;
      final inbounds = config['inbounds'] as List;
      expect(inbounds, hasLength(1));
      expect(inbounds.single['protocol'], 'tun');
      expect(inbounds.single.containsKey('listen'), isFalse);
      final outbounds = config['outbounds'] as List;
      expect(outbounds, hasLength(1));
      expect(outbounds.single['protocol'], 'vless');
      expect(
        outbounds.single['streamSettings'].containsKey('sockopt'),
        isFalse,
      );
      expect(config['log'], {
        'loglevel': 'none',
        'access': 'none',
        'error': 'none',
      });
    },
  );

  test(
    'Android connects without Windows preparation and trusts only native verification',
    () async {
      final (container, bridge, controller) = await session(
        platform: TargetPlatform.android,
      );
      expect(bridge.started, isTrue);
      expect(container.read(autoReconnectProvider), isTrue);
      expect(
        container.read(connectionProvider).status,
        ConnectionStatus.connecting,
      );
      expect(
        (jsonDecode(bridge.config!)['inbounds'] as List).single['protocol'],
        'tun',
      );
      bridge.message =
          'connected|Android VPN connected. HTTPS through the tunnel verified.|81';
      await controller.poll();
      expect(
        container.read(connectionProvider).status,
        ConnectionStatus.connected,
      );
      expect(container.read(connectionProvider).latency, 81);
      expect(container.read(connectionProvider).traffic, isNull);
      await controller.disconnect();
      await controller.poll();
      expect(bridge.stopped, isTrue);
      expect(container.read(connectionProvider).active, isFalse);
    },
  );

  test(
    'retries only a verified session, honors retry limit and does not inflate logs on counters',
    () async {
      final (c, bridge, ctrl) = await session();
      bridge.message = 'connected|Verified|10|10|20|1000';
      await ctrl.poll();
      final count = c.read(connectionProvider).events.length;
      bridge.message = 'connected|Verified|10|20|50|2000';
      await ctrl.poll();
      expect(c.read(connectionProvider).events.length, count);
      expect(c.read(connectionProvider).traffic!.downloadRate, 30);
      for (var i = 0; i < 2; i++) {
        bridge.message = 'failed|Xray stopped unexpectedly.|0';
        await ctrl.poll();
        expect(
          c.read(connectionProvider).status,
          ConnectionStatus.reconnecting,
        );
        await ctrl
            .poll(); // Duplicate native failures must not schedule more timers.
        await Future<void>.delayed(const Duration(milliseconds: 160));
        expect(bridge.starts, i + 2);
      }
      bridge.message = 'failed|Xray stopped unexpectedly.|0';
      await ctrl.poll();
      await Future<void>.delayed(const Duration(milliseconds: 160));
      expect(bridge.starts, 3);
      expect(c.read(connectionProvider).status, ConnectionStatus.failed);
    },
  );

  for (final action in ['disconnect', 'disable', 'profile']) {
    test('$action cancels a queued retry', () async {
      final (c, bridge, ctrl) = await session();
      bridge.message = 'connected|Verified|10';
      await ctrl.poll();
      bridge.message = 'failed|Xray stopped unexpectedly.|0';
      await ctrl.poll();
      if (action == 'disconnect') {
        await ctrl.disconnect();
      } else if (action == 'disable') {
        c.read(autoReconnectProvider.notifier).set(false);
      } else {
        await c
            .read(catalogProvider.notifier)
            .importLink(
              testLink.replaceFirst('server.invalid', 'other.invalid'),
            );
        await c
            .read(catalogProvider.notifier)
            .select(c.read(catalogProvider).requireValue.profiles.last.key);
      }
      await Future<void>.delayed(const Duration(milliseconds: 180));
      expect(bridge.starts, 1);
      expect(
        c.read(connectionProvider).status,
        isNot(ConnectionStatus.reconnecting),
      );
    });
  }

  test('reenabling reconnect arms an unchanged live session', () async {
    final (c, bridge, ctrl) = await session();
    bridge.message = 'connected|Verified|10';
    await ctrl.poll();
    c.read(autoReconnectProvider.notifier).set(false);
    c.read(autoReconnectProvider.notifier).set(true);
    bridge.message = 'failed|Xray stopped unexpectedly.|0';
    await ctrl.poll();
    expect(c.read(connectionProvider).status, ConnectionStatus.reconnecting);
    await ctrl.disconnect();
  });

  test(
    'certificate failure and first connection failure never auto-retry',
    () async {
      final (c, bridge, ctrl) = await session();
      bridge.message = 'failed|HTTPS through the selected server timed out.|0';
      await ctrl.poll();
      await Future<void>.delayed(const Duration(milliseconds: 160));
      expect(bridge.starts, 1);
      await ctrl.connect();
      bridge.message = 'connected|Verified|10';
      await ctrl.poll();
      bridge.message =
          'failed|HTTPS certificate validation failed through the selected server.|0';
      await ctrl.poll();
      await Future<void>.delayed(const Duration(milliseconds: 160));
      expect(bridge.starts, 2);
      expect(c.read(connectionProvider).status, ConnectionStatus.failed);
    },
  );
  test(
    'TUN captures TCP/UDP and pins only the upstream to the physical adapter',
    () {
      final config = jsonDecode(
        buildXrayConfig(
          VlessProfile.parse(testLink),
          30001,
          30002,
          tun: {
            'address': '203.0.113.8',
            'interface': 'Wi-Fi',
            'name': 'CMP VPN-abcdef12-1234',
          },
        ),
      );
      expect(config['inbounds'][0]['protocol'], 'tun');
      expect(config['inbounds'][0]['settings']['MTU'], 1400);
      expect(config['inbounds'][2]['settings']['udp'], true);
      expect(config['outbounds'].length, 1);
      expect(
        config['outbounds'][0]['settings']['vnext'][0]['address'],
        '203.0.113.8',
      );
      expect(
        config['outbounds'][0]['streamSettings']['sockopt']['interface'],
        'Wi-Fi',
      );
      expect(
        () => buildXrayConfig(
          VlessProfile.parse(testLink),
          30001,
          30002,
          tun: {},
        ),
        throwsA(isA<AppFailure>()),
      );
    },
  );
  test(
    'runtime maps REALITY fields with no direct fallback and loopback listeners',
    () {
      final config =
          jsonDecode(
                buildXrayConfig(VlessProfile.parse(testLink), 30001, 30002),
              )
              as Map<String, dynamic>;
      expect((config['outbounds'] as List).length, 1);
      final outbound = config['outbounds'][0];
      expect(outbound['protocol'], 'vless');
      expect(outbound['settings']['vnext'][0]['users'][0]['id'], testUuid);
      expect(
        outbound['streamSettings']['realitySettings']['password'],
        testKey,
      );
      expect(outbound['streamSettings']['network'], 'raw');
      for (final inbound in config['inbounds']) {
        expect(inbound['listen'], '127.0.0.1');
      }
      expect(config['log']['loglevel'], 'none');
    },
  );
  test(
    'unsupported fields and transports fail instead of being silently dropped',
    () {
      for (final link in [
        testLink.replaceFirst('#', '&unknown=secret#'),
        testLink.replaceFirst('security=reality', 'security=tls'),
        testLink
            .replaceFirst('type=tcp', 'type=xhttp')
            .replaceFirst('flow=xtls-rprx-vision&', ''),
      ]) {
        expect(
          () => buildXrayConfig(VlessProfile.parse(link), 30001, 30002),
          throwsA(isA<AppFailure>()),
        );
      }
      expect(
        () => buildXrayConfig(VlessProfile.parse(testLink), 30001, 30001),
        throwsA(isA<AppFailure>()),
      );
    },
  );
  test(
    'starting runtime is not Connected; only authoritative verified event enables it',
    () async {
      final bridge = TestBridge();
      final container = ProviderContainer(
        overrides: [
          connectionBridgeProvider.overrideWithValue(bridge),
          vaultStorageProvider.overrideWithValue(MemoryVault()),
        ],
      );
      addTearDown(container.dispose);
      container.read(tunModeProvider.notifier).set(false);
      await container.read(catalogProvider.future);
      await container.read(catalogProvider.notifier).importLink(testLink);
      final controller = container.read(connectionProvider.notifier);
      await Future<void>.delayed(Duration.zero);
      await controller.poll();
      await controller.connect();
      await controller.poll();
      expect(bridge.started, isTrue);
      expect(
        container.read(connectionProvider).status,
        ConnectionStatus.connecting,
      );
      bridge.message = 'failed|HTTPS could not be verified.|0';
      await controller.poll();
      expect(
        container.read(connectionProvider).status,
        ConnectionStatus.failed,
      );
      await controller.connect();
      bridge.message = 'connected|HTTPS verified; system proxy installed.|125';
      await controller.poll();
      final view = container.read(connectionProvider);
      expect(view.status, ConnectionStatus.connected);
      expect(view.latency, 125);
      expect(view.since, isNotNull);
      expect(view.events.join(), isNot(contains(testUuid)));
      await controller.disconnect();
      await controller.poll();
      expect(bridge.stopped, isTrue);
      expect(
        container.read(connectionProvider).status,
        ConnectionStatus.disconnected,
      );
    },
  );
  test('probe URL rejects insecure URLs and embedded credentials', () {
    final c = ProviderContainer();
    addTearDown(c.dispose);
    for (final value in [
      'http://example.invalid/',
      'https://u:p@example.invalid/',
      'https://example.invalid/#x',
    ]) {
      expect(
        () => c.read(probeUrlProvider.notifier).set(value),
        throwsA(isA<AppFailure>()),
      );
    }
    c.read(probeUrlProvider.notifier).set('https://operator.invalid/health');
    expect(c.read(probeUrlProvider), 'https://operator.invalid/health');
  });
}
