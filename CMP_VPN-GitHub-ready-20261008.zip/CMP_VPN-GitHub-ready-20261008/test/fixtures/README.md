# Local TLS test fixture

This disposable self-signed localhost certificate and key are synthetic test material. They do not identify a server or user and must never be deployed. The test injects an isolated SecurityContext that trusts this certificate only. Production uses platform trust and never disables certificate validation. Regenerate after expiry with the OpenSSL command in docs/phase-03.md.
