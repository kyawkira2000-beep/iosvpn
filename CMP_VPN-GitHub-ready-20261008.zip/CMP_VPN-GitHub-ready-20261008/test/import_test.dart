import 'dart:convert';
import 'dart:typed_data';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/profiles/data/catalog_repository.dart';
import 'package:cmp_vpn/features/profiles/data/qr_decoder.dart';
import 'package:cmp_vpn/features/profiles/domain/catalog.dart';
import 'package:cmp_vpn/features/profiles/domain/vless_profile.dart';
import 'package:cmp_vpn/features/subscriptions/data/subscription_client.dart';
import 'package:cmp_vpn/features/subscriptions/domain/subscription_feed.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:zxing2/qrcode.dart';
import 'support.dart';

void main() {
  group('VLESS', () {
    test('REALITY fields, Unicode name and exact export round trip', () {
      final original =
          '$testLink%20%E1%80%99%E1%80%BC%E1%80%94%E1%80%BA%E1%80%99%E1%80%AC';
      final p = VlessProfile.parse(original);
      expect(p.uuid, testUuid);
      expect(p.host, 'server.invalid');
      expect(p.port, 443);
      expect(p.name, 'Test Server မြန်မာ');
      expect(p.value('pbk'), testKey);
      expect(p.value('flow'), 'xtls-rprx-vision');
      expect(p.baselineEligible, isTrue);
      expect(p.link, original);
    });
    test('IPv6, empty short ID and encoded transport parameters', () {
      final p = VlessProfile.parse(
        testLink
            .replaceFirst('server.invalid', '[2001:db8::1]')
            .replaceFirst(
              'sid=abcd',
              'sid=&spx=%2Fhello%3Fx%3D1&alpn=h2%2Chttp%2F1.1',
            ),
      );
      expect(p.host, '2001:db8::1');
      expect(p.value('sid'), '');
      expect(p.value('spx'), '/hello?x=1');
      expect(p.value('alpn'), 'h2,http/1.1');
    });
    test('TLS websocket retained but marked for later runtime testing', () {
      final link =
          'vless://$testUuid@server.invalid:443?security=tls&type=ws&path=%2Fws%3Fed%3D2048&host=front.invalid&alpn=h2%2Chttp%2F1.1#TLS';
      final p = VlessProfile.parse(link);
      expect(p.value('path'), '/ws?ed=2048');
      expect(p.baselineEligible, isFalse);
      expect(p.link, link);
    });
    test(
      'unknown duplicate parameters preserved, identity independent of label/order',
      () {
        final p = VlessProfile.parse(
          testLink.replaceFirst('#', '&future=one&future=two#'),
        );
        expect(p.parameters['future'], ['one', 'two']);
        expect(p.warnings, isNotEmpty);
        final uri = Uri.parse(testLink);
        final reordered = uri.replace(
          queryParameters: Map.fromEntries(
            uri.queryParameters.entries.toList().reversed,
          ),
          fragment: 'Other',
        );
        expect(
          VlessProfile.parse(reordered.toString()).id,
          VlessProfile.parse(testLink).id,
        );
      },
    );
    final invalid = <String, String>{
      'scheme': testLink.replaceFirst('vless:', 'vmess:'),
      'UUID': testLink.replaceFirst(testUuid, 'bad-secret'),
      'port zero': testLink.replaceFirst(':443?', ':0?'),
      'port overflow': testLink.replaceFirst(':443?', ':65536?'),
      'port absent': testLink.replaceFirst(':443?', '?'),
      'missing SNI': testLink.replaceFirst('sni=cover.invalid&', ''),
      'missing fingerprint': testLink.replaceFirst('fp=chrome&', ''),
      'missing short ID': testLink.replaceFirst('&sid=abcd', ''),
      'odd short ID': testLink.replaceFirst('sid=abcd', 'sid=abc'),
      'invalid public key': testLink.replaceFirst(testKey, 'bad'),
      'duplicate security': testLink.replaceFirst('#', '&security=tls#'),
      'insecure': testLink.replaceFirst('#', '&allowInsecure=true#'),
      'private key': testLink.replaceFirst('#', '&privateKey=secret#'),
      'malformed percent': testLink.replaceFirst('#', '&spx=%QQ#'),
      'control character': testLink.replaceFirst('#', '&spx=%0A#'),
      'Vision with websocket': testLink.replaceFirst('type=tcp', 'type=ws'),
      'wrong encryption': testLink.replaceFirst(
        'encryption=none',
        'encryption=auto',
      ),
      'no security': testLink.replaceFirst('security=reality', 'security=none'),
      'oversize': 'vless://${'x' * 17000}',
    };
    for (final entry in invalid.entries) {
      test('rejects ${entry.key} without echoing credentials', () {
        expect(
          () => VlessProfile.parse(entry.value),
          throwsA(
            isA<AppFailure>().having(
              (e) => e.message.contains(testUuid),
              'no UUID leak',
              false,
            ),
          ),
        );
      });
    }
  });
  group('subscriptions', () {
    test('plain/base64/base64url, duplicate and unsupported lines', () {
      final text = 'vmess://unsupported\r\n$testLink\r\n$testLink\ninvalid';
      for (final body in [
        text,
        base64.encode(utf8.encode(text)),
        base64Url.encode(utf8.encode(text)).replaceAll('=', ''),
      ]) {
        final feed = SubscriptionFeed.parse(utf8.encode(body));
        expect(feed.profiles.length, 1);
        expect(feed.rejected, 2);
      }
    });
    test('usage, expiry and invalid metadata bounds', () {
      final feed = SubscriptionFeed.parse(
        utf8.encode(testLink),
        userInfo: 'upload=4; download=5; total=8; expire=1',
      );
      final sub = SavedSubscription(
        id: 'test',
        name: 'Test',
        url: 'https://test.invalid/',
        updated: 0,
        upload: feed.upload,
        download: feed.download,
        total: feed.total,
        expiry: feed.expiry,
      );
      expect(sub.expired, isTrue);
      expect(sub.exhausted, isTrue);
      final invalid = SubscriptionFeed.parse(
        utf8.encode(testLink),
        userInfo: 'upload=-1;download=no;total=0;expire=9007199254740991',
      );
      expect(invalid.upload, isNull);
      expect(invalid.download, isNull);
      expect(invalid.total, 0);
      expect(invalid.expiry, isNull);
    });
    for (final body in [
      '',
      'bad!!!',
      '{"link":"$testLink"}',
      '[]',
      'vless://invalid',
      base64.encode([255, 255]),
      List.filled(501, testLink).join('\n'),
    ]) {
      test('rejects unsupported/corrupt/oversized feed ${body.length}', () {
        expect(
          () => SubscriptionFeed.parse(utf8.encode(body)),
          throwsA(isA<AppFailure>()),
        );
      });
    }
    test(
      '2 MB body limit',
      () => expect(
        () => SubscriptionFeed.parse(
          List.filled(SubscriptionFeed.maxBytes + 1, 0),
        ),
        throwsA(isA<AppFailure>()),
      ),
    );
    test('HTTPS URL restrictions', () {
      expect(
        validateSubscriptionUrl(
          'https://provider.invalid:8443/sub/token?q=1',
        ).port,
        8443,
      );
      for (final url in [
        'http://provider.invalid/x',
        'https://user:secret@provider.invalid/x',
        'https://provider.invalid/x#token',
        'https://provider.invalid:0/',
        'not-url',
      ]) {
        expect(() => validateSubscriptionUrl(url), throwsA(isA<AppFailure>()));
      }
    });
  });
  group('vault repository', () {
    test('reopens original links and selection', () async {
      final vault = MemoryVault();
      final repo = CatalogRepository(vault);
      await repo.load();
      final saved = SavedProfile(VlessProfile.parse(testLink));
      await repo.save(Catalog(profiles: [saved], selected: saved.key));
      final reopened = await CatalogRepository(vault).load();
      expect(reopened.selectedProfile!.profile.link, testLink);
    });
    test('corrupt data is retained and cannot be overwritten', () async {
      final vault = MemoryVault()..content = 'broken';
      final repo = CatalogRepository(vault);
      await expectLater(repo.load(), throwsA(isA<AppFailure>()));
      await expectLater(repo.save(const Catalog()), throwsA(isA<AppFailure>()));
      expect(vault.content, 'broken');
      expect(vault.writes, 0);
    });
    test('conflicting instance cannot overwrite newer library', () async {
      final vault = MemoryVault();
      final a = CatalogRepository(vault), b = CatalogRepository(vault);
      await a.load();
      await b.load();
      await a.save(const Catalog());
      await expectLater(
        b.save(const Catalog()),
        throwsA(
          isA<AppFailure>().having(
            (e) => e.message,
            'conflict',
            contains('Another app instance'),
          ),
        ),
      );
      expect(vault.writes, 1);
    });
  });
  group('QR image decoding', () {
    img.Image qr(String content) {
      final matrix = Encoder.encode(content, ErrorCorrectionLevel.m).matrix!;
      const scale = 6, border = 4;
      final image = img.Image(
        width: (matrix.width + border * 2) * scale,
        height: (matrix.height + border * 2) * scale,
      );
      img.fill(image, color: img.ColorRgb8(255, 255, 255));
      for (var y = 0; y < matrix.height; y++) {
        for (var x = 0; x < matrix.width; x++) {
          final c = matrix.get(x, y) == 1 ? 0 : 255;
          img.fillRect(
            image,
            x1: (x + border) * scale,
            y1: (y + border) * scale,
            x2: (x + border + 1) * scale - 1,
            y2: (y + border + 1) * scale - 1,
            color: img.ColorRgb8(c, c, c),
          );
        }
      }
      return image;
    }

    test('PNG, JPEG, rotation and subscription QR', () async {
      final source = qr(testLink);
      expect(
        await decodeQr(Uint8List.fromList(img.encodePng(source))),
        testLink,
      );
      expect(
        decodeQrBytes(
          Uint8List.fromList(
            img.encodeJpg(img.copyRotate(source, angle: 90), quality: 92),
          ),
        ),
        testLink,
      );
      const url = 'https://provider.invalid/sub/synthetic-token';
      expect(decodeQrBytes(Uint8List.fromList(img.encodePng(qr(url)))), url);
    });
    test('rejects malformed image, missing QR, byte and dimension limits', () {
      for (final bytes in [
        Uint8List.fromList([1, 2, 3]),
        Uint8List.fromList(img.encodePng(img.Image(width: 32, height: 32))),
        Uint8List(8 * 1024 * 1024 + 1),
        Uint8List.fromList(img.encodePng(img.Image(width: 4097, height: 1))),
      ]) {
        expect(() => decodeQrBytes(bytes), throwsA(isA<AppFailure>()));
      }
    });
  });
}
