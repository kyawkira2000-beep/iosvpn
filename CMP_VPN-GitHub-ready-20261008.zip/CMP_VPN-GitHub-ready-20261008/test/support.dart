import 'package:cmp_vpn/features/profiles/data/catalog_repository.dart';
import 'package:flutter/services.dart';
// Synthetic test data only. No working server or account credentials.
const testUuid = '12345678-1234-4123-8123-123456789abc';
const testKey = 'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA';
const testLink =
    'vless://$testUuid@server.invalid:443?type=tcp&security=reality&encryption=none&sni=cover.invalid&fp=chrome&flow=xtls-rprx-vision&pbk=$testKey&sid=abcd#Test%20Server';

class MemoryVault implements VaultStorage {
  String? content;
  bool fail = false;
  int writes = 0;
  @override
  Future<String?> read() async => content;
  @override
  Future<void> write(String value, String? expected) async {
    if (fail) throw PlatformException(code: 'storage');
    if (content != expected) throw PlatformException(code: 'conflict');
    content = value;
    writes++;
  }
}
