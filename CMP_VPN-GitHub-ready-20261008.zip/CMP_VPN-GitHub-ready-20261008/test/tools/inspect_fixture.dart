import 'dart:io';

// Diagnostic only. The validation callback always rejects the untrusted peer.
Future<void> main() async {
  final context = SecurityContext()
    ..useCertificateChain('test/fixtures/localhost-cert.pem')
    ..usePrivateKey('test/fixtures/localhost-key.pem');
  final server = await SecureServerSocket.bind(
    InternetAddress.loopbackIPv4,
    0,
    context,
  );
  server.listen((socket) => socket.destroy(), onError: (Object _) {});
  try {
    final socket = await SecureSocket.connect(
      'localhost',
      server.port,
      context: SecurityContext(withTrustedRoots: false)
        ..setTrustedCertificates('test/fixtures/localhost-cert.pem'),
      onBadCertificate: (certificate) {
        stdout.writeln('Fixture peer issuer: ${certificate.issuer}');
        stdout.writeln('Fixture peer subject: ${certificate.subject}');
        return false;
      },
      timeout: const Duration(seconds: 5),
    );
    stdout.writeln('Fixture certificate verified unchanged.');
    socket.destroy();
  } on HandshakeException {
    stdout.writeln('Fixture validation rejected; no TLS bypass was used.');
  } finally {
    await server.close();
  }
}
