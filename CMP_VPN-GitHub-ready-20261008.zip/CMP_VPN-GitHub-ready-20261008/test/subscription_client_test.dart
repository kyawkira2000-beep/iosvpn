import 'dart:convert';
import 'dart:io';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/subscriptions/data/subscription_client.dart';
import 'package:cmp_vpn/features/subscriptions/domain/subscription_feed.dart';
import 'package:flutter_test/flutter_test.dart';
import 'support.dart';

void main() {
  final intercepted =
      Platform.environment['AEROLINK_TLS_FIXTURE_INTERCEPTED'] == '1';
  const skipReason =
      'Local antivirus replaces the fixture TLS certificate. See docs/phase-03-validation.md.';
  late HttpServer server;
  late SubscriptionClient client;
  late String origin;
  setUpAll(() async {
    final context = SecurityContext()
      ..useCertificateChain('test/fixtures/localhost-cert.pem')
      ..usePrivateKey('test/fixtures/localhost-key.pem');
    server = await HttpServer.bindSecure(
      InternetAddress.loopbackIPv4,
      0,
      context,
    );
    origin = 'https://localhost:${server.port}';
    server.listen((request) async {
      final response = request.response;
      try {
        switch (request.uri.path) {
          case '/redirect':
            response.statusCode = 302;
            response.headers.set('location', '/feed');
          case '/cross':
            response.statusCode = 302;
            response.headers.set('location', 'https://other.invalid/stolen');
          case '/loop':
            response.statusCode = 302;
            response.headers.set('location', '/loop');
          case '/http':
            response.statusCode = 302;
            response.headers.set(
              'location',
              'http://localhost:${server.port}/feed',
            );
          case '/denied':
            response.statusCode = 403;
          case '/oversize':
            response.write('x' * (SubscriptionFeed.maxBytes + 1));
          case '/chunked':
            for (var i = 0; i < 33; i++) {
              response.write('x' * 65536);
              await response.flush();
            }
          case '/slow':
            await Future<void>.delayed(const Duration(milliseconds: 400));
          case '/invalid':
            response.write('not a configuration');
          default:
            response.headers.set(
              'subscription-userinfo',
              'upload=10; download=20; total=100; expire=1',
            );
            response.write(base64.encode(utf8.encode(testLink)));
        }
        await response.close();
      } catch (_) {
        /* Clients deliberately abort rejected/oversized responses. */
      }
    });
    client = SubscriptionClient(
      clientFactory: () => HttpClient(
        context: SecurityContext(withTrustedRoots: false)
          ..setTrustedCertificates('test/fixtures/localhost-cert.pem'),
      ),
    );
  });
  tearDownAll(() async => server.close(force: true));
  test('real HTTPS fetch with valid test CA and metadata', () async {
    if (intercepted) {
      markTestSkipped(skipReason);
      return;
    }
    final feed = await client.fetch('$origin/feed');
    expect(feed.profiles.single.link, testLink);
    expect(feed.download, 20);
  });
  test('follows same-origin redirect', () async {
    if (intercepted) {
      markTestSkipped(skipReason);
      return;
    }
    expect((await client.fetch('$origin/redirect')).profiles.length, 1);
  });
  for (final path in [
    'cross',
    'loop',
    'http',
    'denied',
    'oversize',
    'chunked',
    'invalid',
  ]) {
    test('rejects $path with sanitized error', () async {
      if (intercepted) {
        markTestSkipped(skipReason);
        return;
      }
      await expectLater(
        client.fetch('$origin/$path?token=do-not-echo'),
        throwsA(
          isA<AppFailure>()
              .having(
                (e) => e.message,
                'specific cause',
                contains(
                  {
                    'cross': 'Cross-origin',
                    'loop': 'redirect limit',
                    'http': 'valid HTTPS',
                    'denied': 'denied',
                    'oversize': '2 MB',
                    'chunked': '2 MB',
                    'invalid': 'not a VLESS',
                  }[path]!,
                ),
              )
              .having(
                (e) => e.message,
                'sanitized',
                isNot(contains('do-not-echo')),
              ),
        ),
      );
    });
  }
  test('default client rejects untrusted TLS certificate', () async {
    await expectLater(
      SubscriptionClient().fetch('$origin/feed'),
      throwsA(
        isA<AppFailure>().having(
          (e) => e.message,
          'TLS',
          contains('certificate'),
        ),
      ),
    );
  });
  test('total request deadline', () async {
    if (intercepted) {
      markTestSkipped(skipReason);
      return;
    }
    final short = SubscriptionClient(
      clientFactory: () => HttpClient(
        context: SecurityContext(withTrustedRoots: false)
          ..setTrustedCertificates('test/fixtures/localhost-cert.pem'),
      ),
      timeout: const Duration(milliseconds: 100),
    );
    await expectLater(
      short.fetch('$origin/slow'),
      throwsA(
        isA<AppFailure>().having(
          (e) => e.message,
          'deadline',
          contains('timed out'),
        ),
      ),
    );
  });
}
