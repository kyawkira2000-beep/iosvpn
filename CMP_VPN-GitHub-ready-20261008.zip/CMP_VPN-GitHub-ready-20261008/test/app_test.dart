import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cmp_vpn/app/aerolink_app.dart';
import 'package:cmp_vpn/features/profiles/presentation/catalog_controller.dart';
import 'package:cmp_vpn/features/settings/presentation/language_controller.dart';
import 'support.dart';

class MemoryLanguage implements LanguageStore {
  String value = 'en';
  @override
  Future<String?> read() async => value;
  @override
  Future<void> write(String language) async {
    value = language;
  }
}

void main() {
  testWidgets(
    'CMP mobile navigation, empty vault and persistent language selection',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final icons = FontLoader('MaterialIcons')..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'));
    await icons.load();
    final font = FontLoader('Noto Sans Myanmar')
        ..addFont(rootBundle.load('assets/fonts/NotoSansMyanmar.ttf'));
      await font.load();
      final language = MemoryLanguage();
      final container = ProviderContainer(
        overrides: [
          vaultStorageProvider.overrideWithValue(MemoryVault()),
          bundledProfileProvider.overrideWithValue(null),
          languageStoreProvider.overrideWithValue(language),
        ],
      );
      addTearDown(container.dispose);
      await tester.pumpWidget(
        UncontrolledProviderScope(
          container: container,
          child: const RepaintBoundary(
            key: Key('capture'),
            child: AerolinkApp(),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('CMP VPN'), findsOneWidget);
      expect(find.byType(NavigationDestination), findsNWidgets(3));
      expect(
        tester
            .widget<FilledButton>(find.byKey(const Key('connect-button')))
            .onPressed,
        isNull,
      );
      await tester.runAsync(() async {
        await Directory('reports').create(recursive: true);
        final boundary = tester.renderObject<RenderRepaintBoundary>(
          find.byKey(const Key('capture')),
        );
        final image = await boundary.toImage(pixelRatio: 2);
        final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
        await File(
          'reports/cmp-home.png',
        ).writeAsBytes(bytes!.buffer.asUint8List());
        image.dispose();
      });
      await tester.tap(find.text('Configs'));
      await tester.pumpAndSettle();
      expect(find.text('Choose a server'), findsOneWidget);
      await tester.tap(find.byKey(const Key('language-toggle')));
      await tester.pumpAndSettle();
      expect(language.value, 'my');
      expect(find.text('ဆာဗာများ'), findsOneWidget);
      await tester.tap(find.byType(NavigationDestination).at(2));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('language-en')), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
    variant: TargetPlatformVariant.only(TargetPlatform.android),
  );
}
