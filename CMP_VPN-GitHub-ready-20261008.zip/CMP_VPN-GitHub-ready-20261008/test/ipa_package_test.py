import importlib.util
from pathlib import Path
import plistlib
import tempfile
import unittest
import zipfile

spec = importlib.util.spec_from_file_location('package_ipa', Path(__file__).resolve().parents[1] / 'scripts/package_unsigned_ipa.py')
package_ipa = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package_ipa)

class IPAPackageTests(unittest.TestCase):
    def bundle(self, path, identifier, extension=False):
        path.mkdir(parents=True, exist_ok=True)
        info = {'CFBundleIdentifier': identifier, 'CFBundleExecutable': 'Fixture'}
        if extension:
            info['NSExtension'] = {'NSExtensionPointIdentifier': 'com.apple.networkextension.packet-tunnel'}
        with (path / 'Info.plist').open('wb') as output:
            plistlib.dump(info, output)
        (path / 'Fixture').write_bytes(bytes.fromhex('cffaedfe') + b'packaging-test-fixture')

    def test_missing_compiled_app_is_not_packaged(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                package_ipa.package(Path(directory))

    def test_missing_extension_is_not_packaged(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.bundle(root / 'build/ios/iphoneos/Runner.app', 'dev.cmpvpn.client')
            with self.assertRaises(FileNotFoundError):
                package_ipa.package(root)

    def test_payload_contains_both_bundles_and_unsigned_notice(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / 'build/ios/iphoneos/Runner.app'
            self.bundle(app, 'dev.cmpvpn.client')
            self.bundle(app / 'PlugIns/PacketTunnel.appex', 'dev.cmpvpn.client.PacketTunnel', True)
            archive = package_ipa.package(root)
            with zipfile.ZipFile(archive) as source:
                self.assertIn('Payload/Runner.app/Fixture', source.namelist())
                self.assertIn('Payload/Runner.app/PlugIns/PacketTunnel.appex/Fixture', source.namelist())
            self.assertIn('NOT an installable signed release', (archive.parent / 'README.txt').read_text())

    def test_rejects_source_in_place_of_executable(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.bundle(root, 'dev.cmpvpn.client')
            (root / 'Fixture').write_text('import Flutter')
            with self.assertRaises(ValueError):
                package_ipa.validate_bundle(root)

if __name__ == '__main__':
    unittest.main()
