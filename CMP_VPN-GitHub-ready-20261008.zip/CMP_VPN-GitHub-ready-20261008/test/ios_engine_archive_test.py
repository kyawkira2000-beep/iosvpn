import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts/get_ios_engine.py'
spec = importlib.util.spec_from_file_location('engine_fetch', SCRIPT)
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)

class EngineArchiveTests(unittest.TestCase):
    def test_rejects_traversal_and_ignores_unrelated_files(self):
        for path in ('../LibXray.xcframework/lib.a', '/LibXray.xcframework/lib.a', 'LibXray.xcframework/../escape', 'LibXray.xcframework\\escape'):
            with self.assertRaises(ValueError):
                engine.safe_member(path)
        self.assertIsNone(engine.safe_member('README.md'))

    def prepare(self, root):
        cache = root / '.local/ios-engine'
        cache.mkdir(parents=True)
        archive = cache / 'fixture.zip'
        with zipfile.ZipFile(archive, 'w') as output:
            output.writestr('release/LibXray.xcframework/Info.plist', '<plist/>')
            output.writestr('release/LibXray.xcframework/ios-arm64/libXray.a', b'fixture')
        digest = hashlib.sha256(archive.read_bytes()).hexdigest()
        archive.rename(cache / (digest + '.zip'))
        (root / 'native/ios').mkdir(parents=True)
        (root / 'ios').mkdir()
        (root / 'native/ios/manifest.json').write_text(json.dumps({'sha256': digest, 'url': 'https://example.invalid/never-download'}))
        engine.ROOT = root
        return cache / (digest + '.zip')

    def test_extracts_repeats_and_preserves_changed_existing_engine(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.prepare(root)
            engine.main()
            engine.main()
            library = root / 'ios/Frameworks/LibXray.xcframework/ios-arm64/libXray.a'
            library.write_bytes(b'local-modification')
            with self.assertRaises(SystemExit):
                engine.main()
            self.assertEqual(library.read_bytes(), b'local-modification')

    def test_checksum_failure_does_not_install(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive = self.prepare(root)
            archive.write_bytes(b'corrupted')
            with self.assertRaises(SystemExit):
                engine.main()
            self.assertFalse((root / 'ios/Frameworks/LibXray.xcframework').exists())

if __name__ == '__main__':
    unittest.main()
