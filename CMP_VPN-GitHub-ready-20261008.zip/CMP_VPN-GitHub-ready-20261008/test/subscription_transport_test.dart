import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:cmp_vpn/core/domain/app_failure.dart';
import 'package:cmp_vpn/features/subscriptions/data/subscription_client.dart';
import 'package:cmp_vpn/features/subscriptions/domain/subscription_feed.dart';
import 'package:flutter_test/flutter_test.dart';
import 'support.dart';

// Deterministic HTTP boundary tests; the separate HTTPS suite exercises real TLS.
class TestHeaders implements HttpHeaders {
  final values = <String, String>{};
  @override
  void set(String name, Object value, {bool preserveHeaderCase = false}) {
    values[name.toLowerCase()] = value.toString();
  }

  @override
  String? value(String name) => values[name.toLowerCase()];
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class TestResponse extends Stream<List<int>> implements HttpClientResponse {
  TestResponse(this.statusCode, this.chunks, {this.contentLength = -1});
  @override
  final int statusCode, contentLength;
  final Stream<List<int>> chunks;
  @override
  final headers = TestHeaders();
  @override
  StreamSubscription<List<int>> listen(
    void Function(List<int>)? onData, {
    Function? onError,
    void Function()? onDone,
    bool? cancelOnError,
  }) => chunks.listen(
    onData,
    onError: onError,
    onDone: onDone,
    cancelOnError: cancelOnError,
  );
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class TestRequest implements HttpClientRequest {
  TestRequest(this.response);
  final Future<TestResponse> response;
  @override
  bool followRedirects = true;
  @override
  final headers = TestHeaders();
  @override
  Future<HttpClientResponse> close() => response;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

class TestHttpClient implements HttpClient {
  TestHttpClient(this.handler);
  final Future<TestResponse> Function(Uri) handler;
  final urls = <Uri>[];
  final requests = <TestRequest>[];
  bool closed = false;
  @override
  Duration? connectionTimeout;
  @override
  set findProxy(String Function(Uri)? fn) {}
  @override
  Future<HttpClientRequest> getUrl(Uri url) async {
    urls.add(url);
    final request = TestRequest(handler(url));
    requests.add(request);
    return request;
  }

  @override
  void close({bool force = false}) {
    closed = force;
  }

  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  TestResponse feed() =>
      TestResponse(200, Stream.value(utf8.encode(testLink)))
        ..headers.set('subscription-userinfo', 'download=42');
  test(
    'fetch and metadata, same-origin redirect and resource cleanup',
    () async {
      final http = TestHttpClient(
        (uri) async => uri.path == '/start'
            ? (TestResponse(302, const Stream.empty())
                ..headers.set('location', '/feed'))
            : feed(),
      );
      final result = await SubscriptionClient(
        clientFactory: () => http,
      ).fetch('https://provider.invalid/start');
      expect(result.profiles.single.link, testLink);
      expect(result.download, 42);
      expect(http.urls.map((e) => e.path), ['/start', '/feed']);
      expect(http.requests.every((r) => !r.followRedirects), isTrue);
      expect(http.closed, isTrue);
    },
  );
  for (final location in [
    'https://other.invalid/secret',
    'http://provider.invalid/secret',
    'https://user:pass@provider.invalid/secret',
  ]) {
    test('redirect cannot send request to $location', () async {
      final http = TestHttpClient(
        (_) async =>
            TestResponse(302, const Stream.empty())
              ..headers.set('location', location),
      );
      await expectLater(
        SubscriptionClient(
          clientFactory: () => http,
        ).fetch('https://provider.invalid/token'),
        throwsA(isA<AppFailure>()),
      );
      expect(http.urls.length, 1);
      expect(http.closed, isTrue);
    });
  }
  test('redirect cap', () async {
    final http = TestHttpClient(
      (_) async =>
          TestResponse(302, const Stream.empty())
            ..headers.set('location', '/loop'),
    );
    await expectLater(
      SubscriptionClient(
        clientFactory: () => http,
      ).fetch('https://provider.invalid/loop'),
      throwsA(
        isA<AppFailure>().having(
          (e) => e.message,
          'reason',
          contains('redirect limit'),
        ),
      ),
    );
    expect(http.urls.length, 4);
  });
  for (final status in [401, 403, 404, 500]) {
    test('HTTP $status never becomes a profile', () async {
      final http = TestHttpClient(
        (_) async => TestResponse(status, Stream.value(utf8.encode(testLink))),
      );
      await expectLater(
        SubscriptionClient(
          clientFactory: () => http,
        ).fetch('https://provider.invalid/secret'),
        throwsA(
          isA<AppFailure>().having(
            (e) => e.message,
            'message',
            contains(
              status == 401 || status == 403 ? 'denied' : 'HTTP $status',
            ),
          ),
        ),
      );
      expect(http.closed, isTrue);
    });
  }
  test('announced and streamed body limits', () async {
    for (final response in [
      TestResponse(
        200,
        const Stream.empty(),
        contentLength: SubscriptionFeed.maxBytes + 1,
      ),
      TestResponse(
        200,
        Stream.fromIterable(List.generate(33, (_) => List.filled(65536, 120))),
      ),
    ]) {
      final http = TestHttpClient((_) async => response);
      await expectLater(
        SubscriptionClient(
          clientFactory: () => http,
        ).fetch('https://provider.invalid/secret'),
        throwsA(
          isA<AppFailure>().having((e) => e.message, 'size', contains('2 MB')),
        ),
      );
      expect(http.closed, isTrue);
    }
  });
  test('timeout closes client and redacts request URL', () async {
    final http = TestHttpClient((_) => Completer<TestResponse>().future);
    await expectLater(
      SubscriptionClient(
        clientFactory: () => http,
        timeout: const Duration(milliseconds: 10),
      ).fetch('https://provider.invalid/secret'),
      throwsA(
        isA<AppFailure>().having(
          (e) => e.message,
          'timeout',
          contains('timed out'),
        ),
      ),
    );
    expect(http.closed, isTrue);
  });
}
